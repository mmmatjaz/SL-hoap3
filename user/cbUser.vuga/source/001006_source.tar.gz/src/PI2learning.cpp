#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <assert.h>
#include <float.h>

#include "SL.h"
#include "SL_common.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"

#include "matrix.h"
#include "tools.h"

#include "PI2learning.h"

bool is_use_model = true;

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////
class_PI2learning::class_PI2learning()
{
	// read index of last data as trial
	int id = 0;
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &id) == true) id--;
		else                              id = 0;
		fclose(pf);
	}
	
	char source_path[256], cmd[256];
	sprintf(source_path, "./source");
	itoa(log_idx, id, 6);
	sprintf(cmd, "tar fzc %s/%s_source.tar.gz src *.dat",
			source_path, log_idx);
	cout << cmd << ": ";
	cout << system(cmd) << endl;
	printf("source files are saved.\n");
}

class_PI2learning::~class_PI2learning()
{
}

///////////////////////////////////////////////////////////
//
// utilities
//
///////////////////////////////////////////////////////////
CMatrix class_PI2learning::cart2joint(double vel)
{
	SL_DJstate *target;
	SL_OJstate *rest_state;
	target = (SL_DJstate *)my_calloc(n_dofs+1,sizeof(SL_DJstate),MY_STOP);
	rest_state = (SL_OJstate *)my_calloc(n_dofs+1,sizeof(SL_OJstate),MY_STOP);
	
	int *cstatus = my_ivector(1, n_endeffs*6);
	ivec_zero(cstatus);
	
	double *cart= my_vector(1, n_endeffs*6);
	vec_zero(cart);
	
	for(int i = 1; i <= n_dofs; i++){
		target[i].th = joint_des_state[i].th;
		rest_state[i].th = rest_des_th(i);
		rest_state[i].w = 0;
	}
	
	cstatus[(RIGHT_HAND - 1)*6 + _X_] = 1;
	cstatus[(RIGHT_HAND - 1)*6 + _Y_] = 0;
	cstatus[(RIGHT_HAND - 1)*6 + _Z_] = 0;
	
	cart[(RIGHT_HAND - 1)*6 + _X_] = vel;
	inverseKinematics(target, endeff, rest_state, cart, cstatus, dt);
	
	CMatrix ret = zeros(N_DOFS + 1, 1);
	for(int i = 1; i <= n_dofs; i++) ret(i) = target[i].th;
	
	my_free_ivector(cstatus, 1, n_endeffs*6);
	my_free_vector(cart, 1, n_endeffs*6);
	
	return ret;
}

/*
CMatrix class_PI2learning::Jac()
{
	double **joint_cog_mpos   = my_matrix(0, N_DOFS, 1, 3);
	double **joint_axis_pos   = my_matrix(0, N_DOFS, 1, 3);
	double **joint_origin_pos = my_matrix(0, N_DOFS, 1, 3);
	double **link_pos = my_matrix(0, N_LINKS, 1, 3);
	double **Alink[N_LINKS + 1];
	for(int n = 1; n <= N_LINKS; n++) Alink[n] = my_matrix(1, 4, 1, 4);
	
	linkInformation(joint_state, &base_state, &base_orient, endeff,
					joint_cog_mpos, joint_axis_pos, joint_origin_pos,
					link_pos, Alink);
	
	double **Jbase = my_matrix(1,6*n_endeffs,1,2*N_CART);
	baseJacobian(link_pos, joint_origin_pos, joint_axis_pos, Jbase);
	
	//SL_Cstate righthand_cart_des_state;
	//SL_quat righthand_cart_des_orient;
	//for(int i = 1; i <= N_CART; ++i){
	//	righthand_cart_des_state.x[i] = link_pos_des[link2endeffmap[RIGHT_HAND]][i];
	//	linkQuat(Alink_des[link2endeffmap[RIGHT_HAND]], &(righthand_cart_des_orient));
	//}
	
	CMatrix ret;
	return ret;
}
*/

///////////////////////////////////////////////////////////
//
// interfaces
//
///////////////////////////////////////////////////////////
CMatrix class_PI2learning::gyro_sensor_wrapper(void){
	CMatrix ret(6, 1);
	double tmp[6];
	gyro_sensor(tmp);
	for(int i = 0; i < 6; i++) ret(i) = tmp[i];
	return ret;
}

CMatrix class_PI2learning::foot_force_sensor_wrapper(int step, double time){
	CMatrix ret(4, 1);
	double tmp[4];
	foot_force_sensor(step, time, tmp);
	for(int i = 0; i < 4; i++) ret(i) = tmp[i];
	return ret;
}

CMatrix class_PI2learning::joint_th(void){
	CMatrix ret(N_DOFS + 1, 1);
	for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_state[i].th;
	return ret;
}

CMatrix class_PI2learning::joint_thd(void){
	CMatrix ret(N_DOFS + 1, 1);
	for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_state[i].thd;
	return ret;
}

CMatrix class_PI2learning::joint_des_th(void){
	CMatrix ret(N_DOFS + 1, 1);
	for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_des_state[i].th;
	return ret;
}

CMatrix class_PI2learning::joint_des_thd(void){
	CMatrix ret(N_DOFS + 1, 1);
	for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_des_state[i].thd;
	return ret;
}

CMatrix class_PI2learning::get_desired_th(void){
	return des_th;
}

CMatrix class_PI2learning::get_desired_thd(void){
	return des_thd;
}

CMatrix class_PI2learning::get_desired_thdd(void){
	return des_thdd;
}

CMatrix class_PI2learning::get_action(void){
	return action;
}

double class_PI2learning::get_cost_act(void){
	return cost_act;
}


///////////////////////////////////////////////////////////
//
// initializer, tarace, save
//
///////////////////////////////////////////////////////////
bool class_PI2learning::init(const int step_max_, const double dt_, const int trial_)
{
	step_max = step_max_;
	dt = dt_;
	trial = trial_;
	//sgenrand(trial);
	
	// read rest state
	char fname_rest_state[] = "./rest_state_cp.dat";
	rest_des_th = zeros(N_DOFS + 1, 1);
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_rest_state << "\"." << endl;
	for(int n = 1; n < N_DOFS + 1; n++){
		read_parameter(fname_rest_state, joint_names[n], &rest_des_th(n));
	}
	rest_des_th *= PI/(double)180;
	rest_des_th(L_EP) = 0;
	rest_des_th(L_ET) = 0;
	rest_des_th(R_EP) = 0;
	rest_des_th(R_ET) = 0;
	
	// read joint bias
	char fname_joint_bias[] = "./joint_bias.dat";
	CMatrix joint_bias = zeros(N_DOFS + 1, 1);
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_joint_bias << "\"." << endl;
	for(int n = 1; n < N_DOFS + 1; n++){
		read_parameter(fname_joint_bias, joint_names[n], &joint_bias(n));
	}
	rest_des_th += joint_bias*PI/(double)180;
	
	
	des_th = joint_des_th();
	des_thd = zeros(N_DOFS + 1, 1);
	
	// init trace
	trace_buff_size = 5;
	trace_buff = new double[trace_buff_size*step_max];
	
	//
	// init PI2
	//
	
	// extract parameters
	//int mode = 0;
	int basis_max = 10;
	double lowpass_coefficient = 1000;
	double lowpass_leak = 1e-3;
	double basis_scale = 0.5;
	rollout_max = 5;
	action_penalty = 1e4;
	default_noise_std = 0.1;
	
	// init CPI2
	int pid = 0;
	input_dim = 1;
	output_dim = 3;
	pi2 = new CPI2[output_dim];
	for(int d = 0; d < output_dim; d++){
		int D = input_dim; // output dimension of one PI2 module
		pi2[d].init(D, rollout_max, step_max, basis_max, lowpass_coefficient, lowpass_leak, dt);
		pi2[d].set_id(pid, d);
		pi2[d].set_basis_scale(basis_scale);
	}
	
	// set save/load environments
	sprintf(pi2_param_filename_prefix, "test");
	get_string("Enter filename for PI2 learning ...", pi2_param_filename_prefix, pi2_param_filename_prefix);
	int ans = 0;
	get_int("Enter 1 to load parameters of PI2 ...", ans, &ans);
	if(ans == 1){
		for(int d = 0; d < output_dim; d++){
			char fname[256], flag[] = "r";
			sprintf(fname, "%s_%d.dat", pi2_param_filename_prefix, d);
			if(pi2[d].load_param(fname, trial) == false){
				cout << "unable to load parameter" << endl;
				return false;
			}
		}
	}
	
	// forward model
	if(is_use_model == true){
		fm_state_dim = 2*output_dim;
		fm_action_dim = output_dim;
		if(fm.init(fm_state_dim, fm_action_dim, rollout_max*step_max, dt) == false){
			cout << "unable to initialize class_forward_model" << endl;
			return false;
		}
		
		// reward model
		cm_state_dim = fm_state_dim;
		cm_action_dim = fm_action_dim;
		if(cm.init(cm_state_dim, cm_action_dim, rollout_max*step_max) == false){
			cout << "unable to initialize class_reward_model" << endl;
			return false;
		}
	}
	
	rollout = 0;
	
	return true;
}

bool class_PI2learning::trace(const int trial, const int step, const double time, const double cost_state)
{
	//trace_t(0, step) = trial;
	//trace_t(1, step) = step;
	//trace_t(2, step) = time;
	//for(int n = 0; n < state_dim; n++) trace_x(n, step) = x(n);
	//for(int d = 0; d < action_dim; d++) trace_u(d, step) = u(d);
	
	if(step >= step_max){
		cout << "# of step exceeded max_step" << endl;
		return false;
	}
	
	int bias = step*trace_buff_size;
	trace_buff[bias + 0] = trial;
	trace_buff[bias + 1] = step;
	trace_buff[bias + 2] = time;
	trace_buff[bias + 3] = cost_state;
	trace_buff[bias + 4] = cost_act;
	bias += 5;
	
	last_step = step;
	
	//
	// forward model & cost model
	//
	if(is_use_model == true){
		CMatrix state(fm_state_dim, 1);
		static CMatrix pre_state(fm_state_dim, 1), pre_action(fm_action_dim, 1);
		
		if(step > 0){
			if(fm_state_dim == 2){
				state(0) = joint_state[R_HR].th;
				state(1) = joint_state[R_HR].thd;
			}
			else if(fm_state_dim == 6){
				state(0) = joint_state[R_SFE].th;
				state(1) = joint_state[R_SAA].th;
				state(2) = joint_state[R_EB].th;
				state(0 + 3) = joint_state[R_SFE].thd;
				state(1 + 3) = joint_state[R_SAA].thd;
				state(2 + 3) = joint_state[R_EB].thd;
			}
			else if(fm_state_dim == 10){
				state(0) = joint_state[R_SFE].th;
				state(1) = joint_state[R_SAA].th;
				state(2) = joint_state[R_HR].th;
				state(3) = joint_state[R_EB].th;
				state(4) = joint_state[R_WR].th;
				state(0 + 5) = joint_state[R_SFE].thd;
				state(1 + 5) = joint_state[R_SAA].thd;
				state(2 + 5) = joint_state[R_HR].thd;
				state(3 + 5) = joint_state[R_EB].thd;
				state(4 + 5) = joint_state[R_WR].thd;
			}
			
			if(step%1 == 0){
				fm.collect_data(pre_state, pre_action, state);
			}
			//cm.collect_data(state, cost_state, cost_act);
		}
		
		// store
		for(int fm_n = 0; fm_n < fm_state_dim; fm_n++) pre_state(fm_n) = state(fm_n);
		for(int fm_d = 0; fm_d < fm_action_dim; fm_d++) pre_action(fm_d) = action(fm_d);
	}
	
	return true;
}



bool class_PI2learning::done(const int trial, const int step)
{
	cout << "[trial=" << trial << ", rollout=" << rollout << "] is done." << endl;
	cout << endl;
	rollout++;
	
	if(rollout >= rollout_max){
		rollout = 0;
		
		// PI2
		/*
		cout << "updating policy..." << flush;
		for(int d = 0; d < output_dim; d++){
			char fname[256], flag[] = "w";
			if(trial < rollout_max) flag[0] = 'a';
			sprintf(fname, "%s_%d.dat", pi2_param_filename_prefix, d);
			
			pi2[d].update();
			pi2[d].save_param(fname, flag, trial + 1);
		}
		cout << "done" << endl;
		*/
		
		// forward model & cost model
		if(is_use_model == true && (trial + 1)%(rollout_max) == 0){
			//fm.write_trace();
			fm.regression();
			//cm.regression();
			
			offline();
			
			fm.reset();
			//cm.reset();
		}
	}
	
	// write cumlative cost to file
	double cum_cost_state = 0, cum_cost_act = 0;
	for(int s = 0; s < last_step; s++){
		int bias = s*trace_buff_size;
		cum_cost_state = trace_buff[bias + 3];
		cum_cost_act = trace_buff[bias + 4];
	}
	FILE *pF;
	char fname[256];
	if(is_use_model == false) sprintf(fname, "cum_cost.dat");
	else                      sprintf(fname, "cum_cost_off.dat");
	if(trial == 0) pF = fopen(fname, "w");
	else           pF = fopen(fname, "a");
	
	if(pF == NULL){
		cout << "unable to open file" << endl;
		return false;
	}
	
	fprintf(pF, "%d %e %e\n", trial, cum_cost_state, cum_cost_act);
	fclose(pF);
	
	return true;
}

bool class_PI2learning::offline(void)
{
	//for(int d = 0; d < output_dim; d++) pi2[d].set_rho(-1);
	
	FILE *pF = fopen("off.dat", "w");
	
	cout << "start offline" << endl;
	for(int loop = 0; loop < 100; loop++){
		double cum_cost = 0;
		for(int offline_rollout = 0; offline_rollout < rollout_max; offline_rollout++){
			CMatrix x = zeros(fm_state_dim, 1);
			CMatrix pre_x = zeros(fm_state_dim, 1), pre_u = zeros(fm_action_dim, 1);
			double cost_state = 0;
			
			if(fm_state_dim == 6){
				pre_x(1) = -5/(double)180*PI;
				pre_x(3) = 90/(double)180*PI;
				pre_x(4) =  5/(double)180*PI;
			}
			
			for(int step = 0; step < step_max; step++){
				double local_time = dt*step;
				
				// cartpole_controller
				double squared_action = 0;
				double noise_std = default_noise_std*0.1;
				action = zeros(input_dim*output_dim, 1);
				for(int d = 0; d < output_dim; d++){
					CMatrix tmp = pi2[d].get_action(offline_rollout, step, local_time, noise_std);
					
					for(int n = 0; n < input_dim; n++){
						action(input_dim*d + n) = tmp(n);
						squared_action += tmp(n)*tmp(n);
					}
				}
				cost_act = action_penalty*squared_action;
				
				// integrate
				pre_u = action;
				x = fm.predict(pre_x, pre_u);
				
				// cost
				//cost_state = cm.predict(x)
				CMatrix rap = right_arm_pos(x);
				cost_state = cost_function(rap);
				
				
				// do_PI2learning
				double cost = cost_state + cost_act;
				for(int d = 0; d < output_dim; d++){
					pi2[d].set_trace(trial, offline_rollout, step, local_time, cost);
				}
				
				pre_x = x;
				cum_cost += cost;
				
				if(loop == 0) fprintf(pF, "%d %d %e %e %e\n", loop, step, x(0), x(1), pre_u(0));
				
				//cout << trans(x*180/3.14);
			}
			//getchar();
		}
		
		//
		if(loop == 0) cout << "updating policy" << flush;
		cout << "." << flush;
		for(int d = 0; d < output_dim; d++){
			char fname[256], flag[] = "a";
			pi2[d].update();
		}
	}
	fclose(pF);
	cout << "done" << endl;
	//getchar();
	
	//for(int d = 0; d < output_dim; d++) pi2[d].set_rho(1000);
	
	return true;
}




bool class_PI2learning::save_trace(const int trial)
{
	char fname[256];
	sprintf(fname, "./log/%06d.dat", trial);
	FILE *pf = fopen(fname, "w");
	
	fprintf(pf, "%d %d\n", trace_buff_size, last_step);
	//fprintf(pf, "%d %d\n", state_dim, action_dim);
	//fprintf(pf, "%d\n", module_num);
	fprintf(pf, "%f\n", dt);
	if(fwrite(trace_buff, sizeof(double), trace_buff_size*last_step, pf) != (unsigned int)(trace_buff_size*last_step)){
		cout << "cannot fwrite matrix." << endl;
		return false;
	}
	fclose(pf);
	
	cout << "class_PI2learning::save_trace is done." << endl;
	cout << "trial=" << trial << ", last_step = " << last_step << ", trace_buff_size = " << trace_buff_size << endl;
	
	return true;
}

//////////////////////////////////////////////////////////
//
// my controllers
//
//////////////////////////////////////////////////////////
double class_PI2learning::simple_fb(const CMatrix &gyro)
{
	//return -0.2*gyro(1) - 0.1*gyro(1 + 3);
	return 0;
}

bool class_PI2learning::rest_controller(const int step, const double local_time, const double local_time_max)
{
	if(local_time < 0.1) start_des_th = joint_des_th();
	
	double d = local_time/local_time_max;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	CMatrix local_des_th = rest_des_th;
	
	if(d < 1){
		des_th   = start_des_th + (local_des_th - start_des_th)*(10*pow(d, 3) -  15*pow(d, 4) +   6*pow(d, 5));
		des_thd  = start_des_th + (local_des_th - start_des_th)*(30*pow(d, 2) -  60*pow(d, 3) +  30*pow(d, 4))/local_time_max;
	}
	else{
		des_th = local_des_th;
		des_thd = zeros(N_DOFS + 1, 1);
	}
	
	return true;
}

bool class_PI2learning::initial_controller(const int step,
										   const double local_time, const double local_time_max,
										   const CMatrix &gyro)
{
	if(local_time < 0.1) start_des_th = joint_des_th();
	
	double d = local_time/local_time_max;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	CMatrix local_des_th = rest_des_th;
	if(d < 1){
		des_th   = start_des_th + (local_des_th - start_des_th)*(10*pow(d, 3) -  15*pow(d, 4) +   6*pow(d, 5));
		des_thd  = start_des_th + (local_des_th - start_des_th)*(30*pow(d, 2) -  60*pow(d, 3) +  30*pow(d, 4))/local_time_max;
	}
	else{
		des_th = local_des_th;
		des_thd = zeros(N_DOFS + 1, 1);
	}
	
	// simple fb
	double alpha = -2*pow(d, 3) + 3*pow(d, 2);
	des_th(L_AFE) += simple_fb(gyro)*alpha;
	des_th(R_AFE) += simple_fb(gyro)*alpha;
	
	return true;
}

bool class_PI2learning::cartpole_controller(const int step, const double local_time, const CMatrix &gyro)
{
	double squared_action = 0;
	double noise_std = default_noise_std;
	action = zeros(input_dim*output_dim, 1);
	for(int d = 0; d < output_dim; d++){
		CMatrix tmp = pi2[d].get_action(rollout, step, local_time, noise_std);
		
		for(int n = 0; n < input_dim; n++){
			action(input_dim*d + n) = tmp(n);
			squared_action += tmp(n)*tmp(n);
		}
	}
	cost_act = action_penalty*squared_action;
	
	//if(step == 0) initial_cart_des_state = cart_des_state[RIGHT_HAND].x[_X_];
	//double target_x = action(0), current_x = cart_des_state[RIGHT_HAND].x[_X_] - initial_cart_des_state;
	//des_th = cart2joint((target_x - current_x)/dt);
	//return true;
	
	//
	des_th = rest_des_th;
	if(output_dim == 1){
		des_th(R_HR)  += action(0);
	}
	else if(output_dim == 3){
		des_th(R_SFE) += action(0);
		des_th(R_SAA) += action(1);
		des_th(R_EB)  += action(2);
	}
	else if(output_dim == 5){
		des_th(R_SFE) += action(0);
		des_th(R_SAA) += action(1);
		des_th(R_HR)  += action(2);
		des_th(R_EB)  += action(3);
		des_th(R_WR)  += action(4);
	}
	else if(output_dim == 7){
		des_th(R_SFE) += action(0);
		des_th(R_SAA) += action(1);
		des_th(R_HR)  += action(2);
		des_th(R_EB)  += action(3);
		des_th(R_WR)  += action(4);
		des_th(R_WFE) += action(5);
		des_th(R_WAA) += action(6);
	}
	
	// simple fb
	des_th(L_AFE) += simple_fb(gyro);
	des_th(R_AFE) += simple_fb(gyro);
	
	return true;
}

bool class_PI2learning::finish_controller(const int step, const double local_time, const double local_time_max,
										  const CMatrix &gyro)
{
	if(local_time < 0.1) start_des_th = joint_des_th();
	
	double d = local_time/local_time_max;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	CMatrix local_des_th = rest_des_th;
	if(d < 1){
		des_th  = start_des_th + (local_des_th - start_des_th)*(10*pow(d, 3) - 15*pow(d, 4) +  6*pow(d, 5));
		des_thd = start_des_th + (local_des_th - start_des_th)*(30*pow(d, 2) - 60*pow(d, 3) + 30*pow(d, 4))/local_time_max;
	}
	else{
		des_th = local_des_th;
		des_thd = zeros(N_DOFS + 1, 1);
	}
	
	// simple fb
	double alpha = -2*pow(d, 3) + 3*pow(d, 2);
	des_th(L_AFE) += simple_fb(gyro)*(1 - alpha);
	des_th(R_AFE) += simple_fb(gyro)*(1 - alpha);
	
	return true;
}

CMatrix class_PI2learning::make_traj(const double time_)
{
	CMatrix ret_des_th = rest_des_th;
	
	/*
	// HFE: -30  90
	// KFE:   0 120
	// AFE: -30  30
	
	double wave = (-cos(phase_) + 1)/(double)2;
	
	ret_des_th(L_HFE) = rest_des_th(L_HFE) + wave*15/(double)180*PI;
	ret_des_th(L_KFE) = rest_des_th(L_KFE) + wave*30/(double)180*PI;
	ret_des_th(L_AFE) = rest_des_th(L_AFE) + wave*15/(double)180*PI;
	
	ret_des_th(R_HFE) = rest_des_th(R_HFE) + wave*15/(double)180*PI;
	ret_des_th(R_KFE) = rest_des_th(R_KFE) + wave*30/(double)180*PI;
	ret_des_th(R_AFE) = rest_des_th(R_AFE) + wave*15/(double)180*PI;
	*/
	
	return ret_des_th;
}


///////////////////////////////////////////////////////////
//
// PI2 learning
//
///////////////////////////////////////////////////////////
bool class_PI2learning::do_PI2learning(const int trial, const int step, const double local_time,
									   const double cost_state)
{
	double cost = cost_state + cost_act;
	//CMatrix x(2, 1);
	//x(0) = joint_state[R_HR].th;
	//x(1) = joint_state[R_HR].thd;
	//double cost = cm.predict(x) + cost_act;
	for(int d = 0; d < output_dim; d++){
		pi2[d].set_trace(trial, rollout, step, local_time, cost);
	}
	
	return true;
}
