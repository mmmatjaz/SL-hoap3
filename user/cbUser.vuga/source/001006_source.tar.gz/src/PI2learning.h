/*!=============================================================================
  ==============================================================================

  \file    PI2learning.h

  \author  Norikazu Sugimoto
  \date    Jan. 2012

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _PI2_LEARNING_H_
#define _PI2_LEARNING_H_

#include "SL.h"
#include "SL_user.h"

#include "matrix.h"
#include "tools.h"
#include "my_utility.h"
#include "PI2.h"
#include "forward_model.h"
#include "cost_model.h"

#ifndef PI
#define PI 3.14159
#endif

class class_PI2learning{
	//
	// member valiables
	//
  private:
	int step_max;
	double dt;
	int trial;
	char log_idx[256];
	char result_file_path[256];
	
	CMatrix rest_des_th, start_des_th;
	CMatrix des_th, des_thd, des_thdd;
	
	double initial_cart_des_state;
	
	// trace
	int trace_buff_size, last_step;
	double *trace_buff;
	
	// for PI2
	CPI2 *pi2;
	char pi2_param_filename_prefix[256];
	int rollout_max, rollout;
	double noise_std;
	double cost_act;
	double action_penalty, default_noise_std;
	CMatrix action;
	
	int input_dim, output_dim;
	
	// forward model
	class_forward_model fm;
	int fm_state_dim, fm_action_dim;
	
	// cost model
	class_cost_model cm;
	int cm_state_dim, cm_action_dim;
	
	//
	// member functions
	//
	
  public:
	class_PI2learning();
	~class_PI2learning();
	
  public:
	CMatrix cart2joint(double vel);
	//CMatrix Jac();
	
	
  public:
	CMatrix gyro_sensor_wrapper(void);
	CMatrix foot_force_sensor_wrapper(int step, double time);
	CMatrix joint_th(void);
	CMatrix joint_thd(void);
	CMatrix joint_des_th(void);
	CMatrix joint_des_thd(void);
	CMatrix get_desired_th(void);
	CMatrix get_desired_thd(void);
	CMatrix get_desired_thdd(void);
	CMatrix get_action(void);
	double get_cost_act(void);
	
  public:
	bool init(const int step_max_, const double _dt, const int _trial);
	bool trace(const int trial, const int step, const double time, const double cost_state);
	bool done(const int trial, const int step);
	bool offline(void);
	//static void *save_trace(void *arg);
	bool save_trace(const int trial);
	
	double simple_fb(const CMatrix &gyro);
	bool rest_controller(const int step, const double local_time, const double local_time_max);
	bool initial_controller(const int step, const double local_time, const double local_time_max, const CMatrix &gyro);
	bool cartpole_controller(const int step, const double local_time, const CMatrix &gyro);
	bool finish_controller(const int step, const double local_time, const double local_time_max, const CMatrix &gyro);
	CMatrix make_traj(double phase_);
	
	//
	bool do_PI2learning(const int trial, const int step, const double local_time, const double cost_state);
};



#endif // end of _PI2_LEARNING_H_
