#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <assert.h>
#include <float.h>

#include "cost_model.h"

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////

class_cost_model::class_cost_model()
{
	
}

class_cost_model::~class_cost_model()
{
}

///////////////////////////////////////////////////////////
//
// menber functions
//
///////////////////////////////////////////////////////////

bool class_cost_model::init(const int state_dim, const int action_dim, const int data_num_max_)
{
	N = state_dim;
	D = action_dim;
	data_num_max = data_num_max_;
	
	// trace
	data_num = 0;
	trace_cost_state = zeros(1, data_num_max);
	trace_cost_act = zeros(1, data_num_max);
	trace_x = zeros(N, data_num_max);
	
	return true;
}

bool class_cost_model::write_trace(void)
{
	FILE *pF = fopen("rm.dat", "w");
	
	if(pF == NULL){
		cout << "unable to open" << endl;
		getchar();
		return false;
	}
	
	for(int s = 0; s < data_num; s++){
		fprintf(pF, "%d", s);
	}
	fclose(pF);
	
	cout << "bool class_cost_model::write_trace(void)" << endl;
	
	return true;
}

bool class_cost_model::reset(void)
{
	double cum_cost_state = 0, cum_cost_act = 0;
	for(int s = 0; s < data_num; s++){
		cum_cost_state += trace_cost_state(s);
		cum_cost_state += trace_cost_act(s);
	}
	
	FILE *pF = fopen("cum_cost2.dat", "a");
	fprintf(pF, "%e %e\n", cum_cost_state, cum_cost_act);
	fclose(pF);
	
	//
	data_num = 0;
	trace_cost_state = zeros(1, data_num_max);
	trace_cost_act = zeros(1, data_num_max);
	trace_x = zeros(N, data_num_max);
	
	return true;
}

bool class_cost_model::collect_data(CMatrix state, double cost_state, double cost_act)
{
	CMatrix x = state;
	trace_cost_state(data_num) = cost_state;
	trace_cost_act(data_num) = cost_act;
	for(int n = 0; n < N; n++){
		trace_x(n, data_num) = x(n);
	}
	
	
	data_num++;
	
	return true;
}

bool class_cost_model::regression(void)
{
	
	return true;
}

double class_cost_model::predict(CMatrix state)
{
	CMatrix x = state;
	
	//double vel = x(1);
	//double target_vel = 0.2;
	//double cost_state = pow(fabs(vel) - target_vel, 2);
	
	double target = 30/(double)180*PI;
	double diff = x(0) - target;
	double cost_state = pow(diff, 2)*1e6;
	
	
	
	
	return cost_state;
}
