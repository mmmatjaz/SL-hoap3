/*!=============================================================================
  ==============================================================================

  \file    cost_model.h

  \author  Norikazu Sugimoto
  \date    Feb. 2012

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _COST_MODEL_H_
#define _COST_MODEL_H_

#include "matrix.h"
#include "tools.h"

#ifndef PI
#define PI 3.14159
#endif

class class_cost_model
{
	//
	// menber variables
	//
	int N, D, data_num_max;
	//CMatrix A, B, c;
	
	int data_num;
	
	CMatrix trace_cost_state, trace_cost_act, trace_x;
	//CMatrix W;
	
	//
	// member functions
	//
  public:
	class_cost_model();
	~class_cost_model();
	
	bool init(const int N_, const int D_, const int data_num_max_);
	bool write_trace(void);
	bool reset(void);
	
	bool collect_data(CMatrix state, double cost_state, double cost_act);
	bool regression(void);
	double predict(CMatrix state);
};


#endif // end of _COST_MODEL_H_

