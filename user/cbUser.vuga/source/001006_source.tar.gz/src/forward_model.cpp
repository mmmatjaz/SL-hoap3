#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <assert.h>
#include <float.h>

#include "forward_model.h"

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////

class_forward_model::class_forward_model()
{
}

class_forward_model::~class_forward_model()
{
}

///////////////////////////////////////////////////////////
//
// menber functions
//
///////////////////////////////////////////////////////////

bool is_linear = false;

bool class_forward_model::init(const int state_dim, const int action_dim, const int data_num_max_, const double dt_)
{
	N = state_dim;
	D = action_dim;
	data_num_max = data_num_max_;
	dt = dt_;
	
	if(is_linear == true){
		data_num = 0;
		
		// trace
		trace_x = zeros(N, data_num_max);
		trace_u = zeros(D, data_num_max);
		trace_y = zeros(N/2, data_num_max);
		
		// linear regression: y = A*x + B*u + x = W*[x; z; 1]
		W = zeros(N/2, N + D + 1);
	}
	else{
		// spgp
		spgp.init(N + D, N/2, data_num_max);
		spgp.reset_collection();
	}
	
	return true;
}

bool class_forward_model::write_trace(void)
{
	/*
	FILE *pF = fopen("fm.dat", "w");
	
	if(pF == NULL){
		cout << "unable to open" << endl;
		getchar();
		return false;
	}
	
	for(int s = 0; s < data_num; s++){
		fprintf(pF, "%d", s);
		for(int n = 0; n < N; n++) fprintf(pF, " %e", trace_y(n, s));
		for(int n = 0; n < N; n++) fprintf(pF, " %e", trace_x(n, s));
		for(int d = 0; d < D; d++) fprintf(pF, " %e", trace_u(d, s));
		fprintf(pF, "\n");
	}
	fclose(pF);
	*/
	
	return true;
}

bool class_forward_model::reset(void)
{
	if(is_linear == true){
		trace_x = zeros(N, data_num_max);
		trace_u = zeros(D, data_num_max);
		trace_y = zeros(N/2, data_num_max);
		data_num = 0;
	}
	else{
		spgp.reset_collection();
	}
	
	return true;
}


bool class_forward_model::collect_data(CMatrix pre_state, CMatrix pre_action, CMatrix state)
{
	if(is_linear == true){
		for(int n = 0; n < N;   n++) trace_x(n, data_num) = pre_state(n);
		for(int d = 0; d < D;   d++) trace_u(d, data_num) = pre_action(d);
		for(int n = 0; n < N/2; n++) trace_y(n, data_num) = state(n + N/2);
		data_num++;
	}
	else{
		// spgp
		CMatrix spgp_input(N + D, 1), spgp_output(N/2, 1);
		for(int n = 0; n < N; n++) spgp_input(n) = pre_state(n);
		for(int d = 0; d < D; d++) spgp_input(N + d) = pre_action(d);
		for(int n = 0; n < N/2; n++) spgp_output(n) = state(n + N/2);
		spgp.collect_data(spgp_input, spgp_output);
	}
	
	
	return true;
}

bool class_forward_model::regression(void)
{
	if(is_linear == true){
		// linear regression
		CMatrix Z = zeros(N + D + 1, data_num);
		CMatrix Y = zeros(N/2, data_num);
		//CMatrix Z = zeros(N + D, data_num);
		for(int s = 0; s < data_num; s++){
			for(int n = 0; n < N;   n++) Z(n, s)     = trace_x(n, s);
			for(int d = 0; d < D;   d++) Z(N + d, s) = trace_u(d, s);
			Z(N + D, s) = 1;
			for(int n = 0; n < N/2; n++) Y(n, s)     = trace_y(n, s);
		}
		W = Y*trans(Z)*inv(Z*trans(Z));
		cout << "data_num=" << data_num << endl;
		cout << "W=" << W << endl;
	}
	else{
		// spgp
		// optimize hyper parameters
		cout << "optimize hyper parameters..." << endl;
		spgp.optimize_hyper_parameters();
		cout << "done" << endl;
	}
	
	return true;
}

CMatrix class_forward_model::predict(CMatrix &pre_state, CMatrix &pre_action)
{
	CMatrix state(N, 1);
	if(is_linear == true){
		CMatrix x = pre_state;
		CMatrix u = pre_action;
		CMatrix z = zeros(N + D + 1, 1);
		//CMatrix z = zeros(N + D, 1);
		
		// set z as input
		for(int n = 0; n < N; n++) z(n) = x(n);
		for(int d = 0; d < D; d++) z(N + d) = u(d);
		z(N + D) = 1;
		
		CMatrix y = W*z;
		
		for(int n = 0; n < N/2; n++){
			state(n) = x(n) + dt*x(n + N/2);
			state(n + N/2) = y(n);
		}
		cout << trans(state);
	}
	else{
		// spgp
		CMatrix spgp_input(N + D, 1), spgp_output(N/2, 1), spgp_variance(N/2, 1);
		for(int n = 0; n < N; n++) spgp_input(n) = pre_state(n);
		for(int d = 0; d < D; d++) spgp_input(N + d) = pre_action(d);
		spgp.pred(spgp_input, spgp_output, spgp_variance);
		
		for(int n = 0; n < N/2; n++){
			state(n) = pre_state(n) + dt*pre_state(n + N/2);
			state(n + N/2) = spgp_output(n);
		}
	}
	
	return state;
}
