/*!=============================================================================
  ==============================================================================

  \file    forward_model.h

  \author  Norikazu Sugimoto
  \date    Feb. 2012

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _FORWARD_MODEL_H_
#define _FORWARD_MODEL_H_

#include "matrix.h"
#include "tools.h"

#include "spgp.h"

#ifndef PI
#define PI 3.14159
#endif

class class_forward_model
{
	//
	// menber variables
	//
	int N, D, data_num_max;
	double dt;
	
	int data_num;
	
	CMatrix trace_x, trace_u, trace_y;
	
	// linear regression
	CMatrix W;
	
	// spgp
	class_spgp spgp;
	
	//
	// member functions
	//
  public:
	class_forward_model();
	~class_forward_model();
	
	bool init(const int N_, const int D_, const int data_num_max_, const double dt_);
	bool write_trace(void);
	bool reset(void);
	
	bool collect_data(CMatrix pre_state, CMatrix pre_action, CMatrix state);
	bool regression(void);
	CMatrix predict(CMatrix &pre_state, CMatrix &pre_action);
};


#endif // end of _FORWARD_MODEL_H_

