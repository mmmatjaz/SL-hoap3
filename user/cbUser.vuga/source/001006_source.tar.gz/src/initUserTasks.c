/*============================================================================
==============================================================================
                      
                              initUserTasks.c
 
==============================================================================
Remarks:

         Functions needed to initialize and link user tasks for the
         simulation

============================================================================*/

// system headers
#include "SL_system_headers.h"

// local headers
#include "SL.h"
#include "SL_user.h"
#include "SL_task_servo.h"
#include "SL_integrate.h"
#include "SL_common.h"
#include "SL_dynamics.h"
//#include "SL_collect_data.h"

// global variables

// local variables
static int user_tasks_initialized = FALSE;

// external functions
extern void toggleSimulatedBaseState(void);


/*****************************************************************************
******************************************************************************
Function Name	: initUserTasks
Date			: June 1999
   
Remarks:

      initialize tasks that are not permanently linked in the simulation
      This replaces the <ltask facility in vxworks -- just that we cannot
      do on-line linking in C.

******************************************************************************
Paramters:  (i/o = input/output)

  none   

*****************************************************************************/
void
initUserTasks(void)
{
	//extern void add_sample_task();
	extern void add_sample_task_cpp();
	extern void add_my_test_task_cpp();
        extern void add_kinect_task_cpp();	

	// use the true base state from the simulation servo
	toggleSimulatedBaseState();
	
	freeze_base_pos[_X_] = 0;
	freeze_base_pos[_Y_] = 0;
	freeze_base_pos[_Z_] = 0.05;
	freezeBase(TRUE);
	
	//setTaskByName("stopcd");
	stopcd();
	//add_sample_task();
	add_sample_task_cpp();
	//add_my_test_task_cpp();
	//add_my_go0_task_cpp();
	//add_my_walk_task_cpp();
	//add_joint_min_max_cpp();
	
	//add_my_camera_test_cpp();
	//add_my_left_eye_pan_test_cpp();
	
	// add_my_sway_task_go_cpp();
	// add_my_sway_task_cpp();
	// add_my_sway_task_save_cpp();
	
	//add_my_NN_revise_task_go_cpp();
	//add_my_NN_revise_task_sampling_cpp();
	//add_my_NN_revise_task_cpp();
	//add_my_NN_revise_task_save_cpp();
	
	// add_my_cartpole_task_rest_cpp();
	// add_my_cartpole_task_cpp();
	// add_my_cartpole_task_save_cpp();
        add_kinect_task_cpp();
}
