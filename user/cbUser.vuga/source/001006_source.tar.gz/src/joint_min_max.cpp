/*============================================================================
==============================================================================

                            joint_min_max.cpp
 
==============================================================================
Remarks:

      sekeleton to create the sample C++ task

============================================================================*/

#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_common.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"

// local includes
#include "joint_min_max.h"


///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////
joint_min_max::joint_min_max(){
}

joint_min_max::~joint_min_max(){
}


///////////////////////////////////////////////////////////
//
// public functions
//
///////////////////////////////////////////////////////////
const char joint_name[][8] = {
	"NULL", // 00
	"L_SFE", // 01
	"L_SAA", // 02
	"L_HR",  // 03
	"L_EB",  // 04 
	"L_WR",  // 05
	"L_WFE", // 06 
	"L_WAA", // 07
	
	"R_SFE", // 08
	"R_SAA", // 09 
	"R_HR",  // 10
	"R_EB",  // 11
	"R_WR",  // 12
	"R_WFE", // 13
	"R_WAA", // 14
	
	"L_HFE", // 15
	"L_HAA", // 16
	"L_HFR", // 17
	"L_KFE", // 18
	"L_AR",  // 19
	"L_AFE", // 20
	"L_AAA", // 21
	
	"R_HFE", // 22
	"R_HAA", // 23
	"R_HFR", // 24
	"R_KFE", // 25
	"R_AR",  // 26
	"R_AFE", // 27
	"R_AAA", // 28
	
	"B_TR",  // 29
	"B_TAA", // 30
	"B_TFE", // 31
	
	"B_HN",  // 32
	"B_HT",  // 33
	"B_HR",  // 34
	
	"R_EP",  // 35
	"R_ET",  // 36
	"L_EP",  // 37
	"L_ET",  // 38
};

int joint_min_max::init(){
	
	joint_min = zeros(N_DOFS + 1, 1);
	joint_max = zeros(N_DOFS + 1, 1);
	for(int i = 1; i <= N_DOFS; i++){
		joint_min(i) = joint_state[i].th;
		joint_max(i) = joint_state[i].th;
	}
	
	start_time = task_servo_time;
	next_time = 1;
	
	return TRUE;
}

int joint_min_max::run(){
	const double time = task_servo_time - start_time;
	
	for(int i = 1; i <= N_DOFS; i++){
		if(joint_min(i) > joint_state[i].th) joint_min(i) = joint_state[i].th;
		if(joint_max(i) < joint_state[i].th) joint_max(i) = joint_state[i].th;
	}
	
	if(time > next_time){
		next_time += 1.0;
		cout << "time=" << time << endl;
	}
	
	
	if(time > 120){
		FILE *pf = fopen("minmax.dat", "w");
		for(int i = 1; i <= N_DOFS; i++){
			cout << joint_name[i] << ":\t"
				 << joint_min(i)*180/PI << "\t"
				 << joint_max(i)*180/PI << endl;
			fprintf(pf, "%-8s %12.6f %12.6f\n", joint_name[i], joint_min(i)*180/PI, joint_max(i)*180/PI);
		}
		fclose(pf);
		freeze();
		return FALSE;
	}
	
	return TRUE;
}

int joint_min_max::change()
{
	return TRUE;
}
