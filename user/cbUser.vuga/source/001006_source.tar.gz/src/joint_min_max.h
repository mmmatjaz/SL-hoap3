/*!=============================================================================
  ==============================================================================

  \file    joint_min_max.h

  \author  Norikazu Sugimoto
  \date    Dec. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _JOINT_MIN_MAX__
#define _JOINT_MIN_MAX__

#include "SL.h"
#include "SL_user.h"
#include "mosaic.h"
#include "matrix.h"
#include "tools.h"

#ifndef PI
#define PI 3.14159
#endif

class joint_min_max{
	//
	// member variables
	//
  public:
	
  private:
	int step;
	double start_time, next_time;
	CMatrix joint_min, joint_max;
	
	//
	// member functions
	//
  private:
	
  public:
	joint_min_max();
	~joint_min_max();
	
	int init();
	int run();
	int change();
};

#endif // end of _JOINT_MIN_MAX__


