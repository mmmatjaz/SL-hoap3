/*============================================================================
==============================================================================

                              joint_min_max_wrapper.cpp
 
==============================================================================
Remarks:

  sekeleton that wrappes a "my test task" written in C++

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"

// local includes
#include "joint_min_max.h"

extern "C" {
	// global function
	void add_joint_min_max_cpp();
	
	// local functions
	static int init_joint_min_max(void);
	static int run_joint_min_max(void);
	static int change_joint_min_max(void);
}


//////////////////////////////////////////////////////////////////////////////
static joint_min_max joint_min_max;
void add_joint_min_max_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "joint min max");
	addTask(task_name,
			init_joint_min_max,
			run_joint_min_max,
			change_joint_min_max);
}

//
static int init_joint_min_max(void)
{
	return joint_min_max.init();
}
static int run_joint_min_max(void)
{
	return joint_min_max.run();
}
static int change_joint_min_max(void)
{
	return joint_min_max.change();
}
