/*============================================================================
==============================================================================
                      
                              kinect_task.cpp
 
==============================================================================
Remarks:

      Implements mimicking human movement estimated by Kinect

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"

// Local includes
#include "kinect_task.h"

#include <fcntl.h>
#include <arpa/inet.h>
// #include <sys/socket.h>

static int servo_rate = SERVO_BASE_RATE / TASK_SERVO_RATIO;
static char DMP_file_name[] = PREFS "DMP_param.txt";
static char example_file_name[] = PREFS "traj_example.txt";

extern "C" {
  void init_smooth_pursuit(void);
  int run_smooth_pursuit_task(void);
}

#define MAX_BUFFER  10000
#define KINECT_PORT 8992
int sockfd = 0;
struct sockaddr_in serv_addr;

kinect_task::kinect_task() : start_time_(0), previous_time_(0)
{
  task_servo_steps = 0;
  packet_count = 0;
  use_vision = 0;
  track = 1;
}

kinect_task::~kinect_task()
{
  if (sockfd != 0)
    close(sockfd);
  sockfd = 0;
}

int kinect_task::initialize()
{
int i, ans, iof;
double joint_initial_configuration[N_DOFS+1]; // N_DOFS = 38 for CB-i

  /* check whether any other task is running */
  if (strcmp(current_task_name, NO_TASK) != 0)
  {
    printf("New task can only be run if no other task is running!\n");
    return FALSE;
  }
    
  /* open socket to receive data from Kinect */
  if (sockfd != 0)
    close(sockfd);
  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0)
  { 
    printf("Error opening socket!\n");
    sockfd = 0;
    return FALSE;
  }
  if ((iof = fcntl(sockfd, F_GETFL, 0)) != -1)
    fcntl(sockfd, F_SETFL, iof | O_NONBLOCK);
  memset((char *) &serv_addr, 0, sizeof(serv_addr));
  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(KINECT_PORT);
  serv_addr.sin_addr.s_addr = INADDR_ANY; // inet_addr("192.168.6.100");
  if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
  {
    printf("Error on binding!\n");
    return FALSE;
  }
  printf("Kinect socket connected! Local %s: %d\n",
         inet_ntoa(serv_addr.sin_addr), ntohs(serv_addr.sin_port));
    
  printf("Servo rate: %d, servo base rate: %d, ratio: %d.\n", servo_rate,
         SERVO_BASE_RATE, TASK_SERVO_RATIO);

  /* do
  {
    get_int(const_cast<char*>("Enter 1 if you want to use vision, else 0"),
            use_vision, &use_vision);
  } while ((use_vision != 0) && (use_vision != 1)); */


  // prepare going to the initial posture
  bzero((char *)&(target_[1]),N_DOFS*sizeof(target_[1]));
  for (i = 1; i <= N_DOFS; i++)
    target_[i] = joint_default_state[i];

  // ready to go
  ans = 0;
  while (ans != 1)
  {
    if (!get_int(const_cast<char*>("Enter 1 to start or 'q' to abort ..."), ans, &ans))
    {
      return FALSE;
    }
  }

  previous_time_ = start_time_ = task_servo_time;
  printf("start time = %.3f, task_servo_time = %.3f\n", start_time_, task_servo_time);

  // go to the target
  bool there = true;
  for (i = 1; i <= B_HR; i++)
    if (fabs(target_[i].th - joint_des_state[i].th) > 1.0e-3)
    {
      there = false;
      break;
    }
  if (!there)
    if (!go_target_wait_ID(target_))
    {
      return FALSE;
    }

  // initialize smooth pursuit
  if (use_vision == 1)
    init_smooth_pursuit();

  // set the current desired joint position equal to the current position
  for (i = 1; i <= N_DOFS; i++)
  {
    joint_des_state[i].th = target_[i].th;
    joint_des_state[i].thd = 0; // joint_state[i].thd;
    joint_des_state[i].thdd = 0; // joint_state[i].thdd;
  }

  return TRUE;
}

int kinect_task::run()
{
double task_time = task_servo_time - start_time_;
int n, n_last;
char buffer[MAX_BUFFER], last_buffer[MAX_BUFFER], *buffer_pt;

  if (use_vision == 1)
    run_smooth_pursuit_task();

  if (track == 1 && sockfd > 0)
  {
    // Receive data
    n = 0;
    do
    {
      n_last = recvfrom(sockfd, last_buffer, MAX_BUFFER, 0, NULL, 0);
      if (n_last > 0)
      {
        n = n_last;
        memcpy(buffer, last_buffer, n);
        packet_count++;
      }
    } while (n_last > 0);
    if ((task__servo_steps % 500) == 0)
    {
      printf("time: %lf, number of packets: %d\n", task_servo_time, packet_count);
    }

    // Data received
    if (n > 0)
    {
      buffer_pt = &(buffer[0]);
      //joint_des_state[R_HFR].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[R_HAA].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[R_HFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[R_KFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[R_AFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[R_AAA].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[R_SFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[R_SAA].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[R_HR].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[R_EB].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[L_HFR].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[L_HAA].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[L_HFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[L_KFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[L_AFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      //joint_des_state[L_AAA].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[L_SFE].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[L_SAA].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[L_HR].th = ((double *) buffer_pt)[0];
      buffer_pt += 8;
      joint_des_state[L_EB].th = ((double *) buffer_pt)[0];
    }
  }

  task_servo_steps++;
  previous_time_ = task_time;

  return TRUE;
}

int kinect_task::changeParameters()
{
  
  track = (track + 1) % 2;

  return TRUE;
}


