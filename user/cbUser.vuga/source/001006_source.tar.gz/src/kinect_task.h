/*!=============================================================================
  ==============================================================================

  \file    kinect_task.h

  \author  Ales Ude
  \date    July 2012

  ==============================================================================
  \remarks

  ============================================================================*/

#ifndef KINECT_TASK_H_
#define KINECT_TASK_H_

#include "DMPstructure.h"

class kinect_task {

public:

  /*!
   */
  kinect_task();
  ~kinect_task();

  /*!
   */
  int initialize();
  int run();
  int changeParameters();

private:

  /*!
   */
  double start_time_, previous_time_;
  SL_DJstate target_[N_DOFS+1];

  unsigned int count;

  int use_vision;
  int track;
};

#endif // KINECT_TASK_H_
