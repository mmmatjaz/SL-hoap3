/*============================================================================
==============================================================================

                              mosaic.cpp
 
==============================================================================
Remarks:

============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <float.h>
#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// local includes
#include "mosaic.h"
#include "matrix.h"
#include "tools.h"

#define OFFLINE_KALMAN

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////

class_mosaic::class_mosaic()
{
}

class_mosaic::~class_mosaic()
{
	if(A != NULL) delete [] A;
	if(B != NULL) delete [] B;
	if(c != NULL) delete [] c;
	if(K != NULL) delete [] K;
	if(xc != NULL) delete [] xc;
	
	if(kal_xh != NULL) delete [] kal_xh;
	if(kal_z != NULL) delete [] kal_z;
	if(kal_y != NULL) delete [] kal_y;
	if(kal_H != NULL) delete [] kal_H;
	if(kal_S != NULL) delete [] kal_S;
	if(kal_P != NULL) delete [] kal_P;
	if(kal_Q != NULL) delete [] kal_Q;
	if(kal_R != NULL) delete [] kal_R;
	if(kal_K != NULL) delete [] kal_K;
}


///////////////////////////////////////////////////////////
//
// member functions (public)
//
///////////////////////////////////////////////////////////

bool class_mosaic::init(const int _M, const int _N, const int _D, const double _dt)
{
	step = 0;
	
	//max_module_num = _max_module_num;
	
	M = _M;
	N = _N;
	hidden_N = _N;
	D = _D;
	dt = _dt;
	
	lambda = zeros(M, 1);
	
	A  = new CMatrix[M];
	B  = new CMatrix[M];
	c  = new CMatrix[M];
	K  = new CMatrix[M];
	xc = new CMatrix[M];
	prior_mean = new double[M];
	prior_s2 = new double[M];
	
	for(int m = 0; m < M; m++){
		A[m]  = zeros(N, N);
		B[m]  = zeros(N, D);
		c[m]  = zeros(N, 1);
		K[m]  = zeros(D, N);
		xc[m] = zeros(N, 1);
		prior_mean[m] = 0;
		prior_s2[m] = 0;
	}
	
	// for kalman filter
	kal_xh = new CMatrix[M];
	kal_z  = new CMatrix[M];
	kal_y  = new CMatrix[M];
	kal_H  = new CMatrix[M];
	kal_S  = new CMatrix[M];
	kal_P  = new CMatrix[M];
	kal_Q  = new CMatrix[M];
	kal_R  = new CMatrix[M];
	kal_K  = new CMatrix[M];
	for(int m = 0; m < M; m++){
		kal_xh[m] = zeros(N, 1);
		kal_z[m]  = zeros(hidden_N, 1);
		kal_y[m]  = zeros(hidden_N, 1);
		kal_H[m]  = eye(N);
		kal_S[m]  = zeros(hidden_N, hidden_N);
		kal_P[m]  = zeros(N, N);
		kal_Q[m]  = zeros(N, N);
		for(int n = 0; n < N/2; n++){
			// for system noise
			// full state
			//kal_Q[m](n, n)  = pow(0.02, 2);
			//kal_Q[m](n + N/2, n + N/2) = pow(0.02, 2);
			
			// pend model
			kal_Q[m](n, n)  = pow(0.02, 2);
			kal_Q[m](n + N/2, n + N/2) = pow(0.02, 2);
		}
		kal_R[m]  = zeros(hidden_N, hidden_N);
		for(int n = 0; n < hidden_N/2; n++){
			// for observation noise
			// full state
			//kal_R[m](n, n)  = pow(0.002, 2);
			//kal_R[m](n + hidden_N/2, n + hidden_N/2) = pow(0.1, 2);
			
			// pend model
			kal_R[m](n, n)  = pow(0.002, 2);
			kal_R[m](n + hidden_N/2, n + hidden_N/2) = pow(0.1, 2);
		}
		
		kal_K[m]  = zeros(hidden_N, N);
	}
	
	if(load() == false){
		cout << "error!" << endl;
		return false;
	}
	
	return true;
}

bool class_mosaic::done(void)
{
	step = 0;
	lambda = zeros(M, 1);
	
	return true;
}

bool class_mosaic::load(void)
{
	/*{
		char fname[256], idx_str[256];
		FILE *pf;
		sprintf(fname, "./matlab/module_num.dat", idx_str);
		pf = fopen(fname, "r");
		if(pf == NULL){
			cout << "can't open " << fname << "." << endl;
			return false;
		}
		fscanf(pf, "%d", &M);
		cout << "# of modules = " << M << endl;
		
		if(M > max_module_num){
			cout << "number of modules is exceeded " << max_module_num << ".";
			cout << "push return, then exit." << endl;
			getchar();
		}
	}*/
	
	for(int m = 0; m < M; m++){
		
		char fname[256], idx_str[256];
		FILE *pf;
		//itoa(idx_str, m, 6);
		itoa(idx_str, m, 6);
		
		// load W
		sprintf(fname, "./matlab/M%02d_W_%s.dat", M, idx_str);
		pf = fopen(fname, "r");
		if(pf == NULL){
			cout << "can't open " << fname << "." << endl;
			return false;
		}
		for(int i = 0; i < N; i++){
			for(int j = 0; j < N; j++) fscanf(pf, "%le", &A[m](i, j));
			for(int j = 0; j < D; j++) fscanf(pf, "%le", &B[m](i, j));
			fscanf(pf, "%le", &c[m](i));
		}
		fclose(pf);
		cout << fname << " is loaded." << endl;
		
		
		// load K
		sprintf(fname, "./matlab/M%02d_K_%s.dat", M, idx_str);
		pf = fopen(fname, "r");
		if(pf == NULL){
			cout << "can't open " << fname << "." << endl;
			return false;
		}
		for(int i = 0; i < D; i++){
			for(int j = 0; j < N; j++) fscanf(pf, "%le", &K[m](i, j));
		}
		fclose(pf);
		cout << fname << " is loaded." << endl;
		
		// load xc
		sprintf(fname, "./matlab/M%02d_xc_%s.dat", M, idx_str);
		pf = fopen(fname, "r");
		if(pf == NULL){
			cout << "can't open " << fname << "." << endl;
			return false;
		}
		for(int i = 0; i < N; i++) fscanf(pf, "%le", &xc[m](i));
		fclose(pf);
		cout << fname << " is loaded." << endl;
		
		// load prior
		//sprintf(fname, "./matlab/M%02d_prior_%s.dat", M, idx_str);
		//pf = fopen(fname, "r");
		//if(pf == NULL){
		//	cout << "can't open " << fname << "." << endl;
		//	return false;
		//}
		//fscanf(pf, "%le %le", &prior_mean[m], &prior_s2[m]);
		//fclose(pf);
		//cout << fname << " is loaded." << endl;
	}
	
#ifdef OFFLINE_KALMAN
	cout << "!!OFFLINE_KALMAN is defined!!" << endl;
	for(int m = 0; m < M; m++){
		CMatrix u = zeros(D, 1), pre_K = kal_K[m];
		kal_xh[m] = zeros(N, 1);
		for(int s = 0; s < 1000; s++){
			// observation
			kal_z[m] = kal_H[m]*zeros(N, 1);
			
			// prediction
			kal_xh[m] = A[m]*kal_xh[m] + B[m]*u + c[m];
			kal_P[m] = A[m]*kal_P[m]*trans(A[m]) + kal_Q[m];
			
			// update
			kal_y[m]  = kal_z[m] - kal_xh[m];
			kal_S[m]  = kal_P[m] + kal_R[m];
			kal_K[m]  = kal_P[m]*inv(kal_S[m]);
			kal_xh[m] = kal_xh[m] + kal_K[m]*kal_y[m];
			kal_P[m]  = (eye(N) - kal_K[m])*kal_P[m];
			
			//kal_y[m]  = kal_z[m] - kal_H[m]*kal_xh[m];
			//kal_S[m]  = kal_H[m]*kal_P[m]*trans(kal_H[m]) + kal_R[m];
			//kal_K[m]  = kal_P[m]*trans(kal_H[m])*inv(kal_S[m]);
			//kal_xh[m] = kal_xh[m] + kal_K[m]*kal_y[m];
			//kal_P[m]  = (eye(N) - kal_K[m]*kal_H[m])*kal_P[m];
			
			CMatrix diff = max(pow(kal_K[m] - pre_K, 2));
			if(diff(0) < 1e-8) break;
			pre_K = kal_K[m];
		}
		cout << m << "/" << M << endl;
	}
#endif // OFFLINE_KALMAN
	
	return true;
}

CMatrix class_mosaic::output(const int step_, CMatrix &x, CMatrix &pre_u, double phase)
{
	step = step_;
	
	kalman(x, pre_u);
	resp(x, pre_u, phase);
	CMatrix u = zeros(D, 1);
	for(int m = 0; m < M; m++){
		//CMatrix um = -K[m]*(x - xc[m]);
		CMatrix um = -K[m]*(kal_xh[m] - xc[m]);
		u = u + lambda(m)*um;
	}
	
	return u;
}

bool class_mosaic::kalman(CMatrix &x, CMatrix &u)
{
	if(step < 10){
		for(int m = 0; m < M; m++) kal_xh[m] = x;
	}
	
	for(int m = 0; m < M; m++){
#ifdef OFFLINE_KALMAN
		// observe
		kal_z[m] = kal_H[m]*x;
		
		// prediction
		kal_xh[m] = A[m]*kal_xh[m] + B[m]*u + c[m];
		
		// update
		kal_y[m]  = kal_z[m] - kal_xh[m];
		kal_xh[m] = kal_xh[m] + kal_K[m]*kal_y[m];
#else
		// observe
		kal_z[m] = x;
		//kal_z[m] = kal_H[m]*x;
		
		// prediction
		kal_xh[m] = A[m]*kal_xh[m] + B[m]*u + c[m];
		kal_P[m] = A[m]*kal_P[m]*trans(A[m]) + kal_Q[m];
		
		// update
		kal_y[m]  = kal_z[m] - kal_xh[m];
		kal_S[m]  = kal_P[m] + kal_R[m];
		kal_K[m]  = kal_P[m]*inv(kal_S[m]);
		kal_xh[m] = kal_xh[m] + kal_K[m]*kal_y[m];
		kal_P[m]  = (eye(N) - kal_K[m])*kal_P[m];
		
		//kal_y[m]  = kal_z[m] - kal_H[m]*kal_xh[m];
		//kal_S[m]  = kal_H[m]*kal_P[m]*trans(kal_H[m]) + kal_R[m];
		//kal_K[m]  = kal_P[m]*trans(kal_H[m])*inv(kal_S[m]);
		//kal_xh[m] = kal_xh[m] + kal_K[m]*kal_y[m];
		//kal_P[m]  = (eye(N) - kal_K[m]*kal_H[m])*kal_P[m];
#endif // OFFLINE_KALMAN
	}
	
	return true;
}

bool class_mosaic::resp(CMatrix &x, CMatrix &u, double phase)
{
	double max_exp_arg = 0;
	CMatrix exp_arg(M, 1);
	for(int m = 0; m < M; m++){
		//double d = pdiff(prior_mean[m], phase);
		//double log_prior = -d*d/(double)(2*prior_s2[m])*0;
		
		CMatrix tmp = -0.5*trans(kal_y[m])*kal_S[m]*kal_y[m];
		exp_arg(m) = tmp(0);// + log_prior;
		
		if(max_exp_arg < exp_arg(m) || m == 0) max_exp_arg = exp_arg(m);
	}
	
	double deno = 0;
	lambda = zeros(M, 1);
	for(int m = 0; m < M; m++){
		exp_arg(m) = exp_arg(m) - max_exp_arg;
		lambda(m) = exp(exp_arg(m));
		deno += lambda(m);
	}
	lambda /= deno;
	
	return true;
}


