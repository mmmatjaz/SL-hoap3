/*!=============================================================================
  ==============================================================================

  \file    mosaic.h

  \author  Norikazu Sugimoto
  \date    Dec. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/


#ifndef _MOSAIC_H_
#define _MOSAIC_H_

#include "matrix.h"
#include "tools.h"

#ifndef PI
#define PI 3.14159
#endif


class class_mosaic{
	//
	// constructor & destructor
	//
  public:
	class_mosaic();
	~class_mosaic();
	
	//
	// member valiables
	//
  private:
	int step;
	int max_module_num;
	int M, N, hidden_N, D;
	double dt;
	CMatrix *A, *B, *c, *K, *xc;
	CMatrix lambda;
	double *prior_mean, *prior_s2;
	
	// variables for Kalman filter
	double sys_sigma2, obs_sigma2;
	CMatrix *kal_xh, *kal_z, *kal_y;
	CMatrix *kal_H, *kal_S, *kal_P, *kal_Q, *kal_R, *kal_K;
	
	//
	// member functions
	//
  public:
	bool init(const int _M, const int _N, const int _D, double _dt);
	bool done(void);
	bool load(void);
	CMatrix output(const int step_, CMatrix &x, CMatrix &pre_u, double phase);
	bool kalman(CMatrix &x, CMatrix &u);
	bool resp(CMatrix &x, CMatrix &u, double phase);
	
	//bool get_lambda(CMatrix &_lambda){_lambda = lambda; return true;};
	int get_module_num(void){
		return M;
	}
	CMatrix get_internal_state(const int m){
		CMatrix _kal_xh = kal_xh[m];
		return _kal_xh;
	}
	CMatrix get_pred_err(void){
		CMatrix ret(M, 1);
		for(int m = 0; m < M; m++){
			CMatrix tmp = trans(kal_y[m])*kal_y[m];
			ret(m) = tmp(0);
		}
		return ret;
	}
	CMatrix get_lambda(void){
		CMatrix _lambda = lambda;
		return _lambda;
	}
	
	
};



#endif // end of _MOSAIC_H_
