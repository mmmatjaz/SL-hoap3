#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <assert.h>
#include <float.h>

#include "SL.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"

#include "matrix.h"
#include "tools.h"

#include "mosaic_learning.h"

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////
class_mosaic_learning::class_mosaic_learning()
{
	isinit = false;
	
	// read index of last data as trial
	int id = 0;
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &id) == true) id--;
		else                              id = 0;
		fclose(pf);
	}
	
	char source_path[256], cmd[256];
	sprintf(source_path, "./source");
	itoa(log_idx, id, 6);
	sprintf(cmd, "tar fzc %s/%s_source.tar.gz src *.dat",
			source_path, log_idx);
	cout << cmd << endl;
	system(cmd);
	printf("source files are saved.\n");
}

class_mosaic_learning::~class_mosaic_learning()
{
}

///////////////////////////////////////////////////////////
//
//
//
///////////////////////////////////////////////////////////
bool class_mosaic_learning::init(const int _max_step, const double _dt, const int _trial)
{
	max_step = _max_step;
	dt = _dt;
	trial = _trial;
	sgenrand(trial);
	
	// read rest state
	char fname_rest_state[] = "./rest_state.dat";
	rest_des_th = zeros(N_DOFS + 1, 1);
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_rest_state << "\"." << endl;
	for(int n = 1; n < N_DOFS + 1; n++){
		read_parameter(fname_rest_state, joint_names[n], &rest_des_th(n));
	}
	rest_des_th *= PI/(double)180;
	
	rest_des_th(L_EP) = 0;
	rest_des_th(L_ET) = 0;
	rest_des_th(R_EP) = 0;
	rest_des_th(R_ET) = 0;
	
	// read joint bias
	char fname_joint_bias[] = "./joint_bias.dat";
	CMatrix joint_bias = zeros(N_DOFS + 1, 1);
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_joint_bias << "\"." << endl;
	for(int n = 1; n < N_DOFS + 1; n++){
		read_parameter(fname_joint_bias, joint_names[n], &joint_bias(n));
	}
	rest_des_th += joint_bias*PI/(double)180;
	
	// read initial posture
	char fname_init_pos[] = "./init_pos.dat";
	double xstance = 0.0, ystance = 0.1;
	double xbias = 0.0, ybias = -0.0, zbias = -0.70;
	double l_rol = 0.0, l_pit = 0.0, l_yaw = 0.0;
	double r_rol = 0.0, r_pit = 0.0, r_yaw = 0.0;
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_init_pos << "\"." << endl;
	read_parameter(fname_init_pos, "xstance", &xstance);
	read_parameter(fname_init_pos, "ystance", &ystance);
	read_parameter(fname_init_pos, "xbias", &xbias);
	read_parameter(fname_init_pos, "ybias", &ybias);
	read_parameter(fname_init_pos, "zbias", &zbias);
	read_parameter(fname_init_pos, "l_rol", &l_rol);
	read_parameter(fname_init_pos, "l_pit", &l_pit);
	read_parameter(fname_init_pos, "l_yaw", &l_yaw);
	read_parameter(fname_init_pos, "r_rol", &r_rol);
	read_parameter(fname_init_pos, "r_pit", &r_pit);
	read_parameter(fname_init_pos, "r_yaw", &r_yaw);
	
	// set initial state
	init_p[0] = zeros(3, 1);
	init_p[1] = zeros(3, 1);
	init_r[0] = zeros(3, 1);
	init_r[1] = zeros(3, 1);
	
	init_p[0](0) = -xstance + xbias; init_p[0](1) =  ystance + ybias; init_p[0](2) = zbias;
	init_p[1](0) =  xstance + xbias; init_p[1](1) = -ystance + ybias; init_p[1](2) = zbias;
	init_r[0](0) = l_rol/(double)180*PI; init_r[0](1) = l_pit/(double)180*PI; init_r[0](2) = l_yaw/(double)180*PI;
	init_r[1](0) = r_rol/(double)180*PI; init_r[1](1) = r_pit/(double)180*PI; init_r[1](2) = r_yaw/(double)180*PI;
	
	// read j_delta, sway_period, sway_xamp, sway_yamp, sway_zamp
	char fname_my_params[] = "./my_params.dat";
	j_delta = 0.0;
	explore= 0;
	dist_amp = 0;
	dist_freq = 0.1;
	module_num = 0;
	cycle = 0;
	period = 0;
	y_amplitude = 0;
	z_amplitude = 0;
	
	btfe_amp = 20;
	btr_amp = 15;
	sfe_amp = 70;
	saa_amp = -40;
	hr_amp = 35;
	eb_amp = 80;
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_my_params << "\"." << endl;
	read_parameter(fname_my_params, "j_delta", &j_delta);
	read_parameter(fname_my_params, "explore", (int*)&explore);
	read_parameter(fname_my_params, "dist_amp", &dist_amp);
	read_parameter(fname_my_params, "dist_freq", &dist_freq);
	read_parameter(fname_my_params, "module_num", &module_num);
	read_parameter(fname_my_params, "cycle", &cycle);
	read_parameter(fname_my_params, "period", &period);
	read_parameter(fname_my_params, "y_amplitude", &y_amplitude);
	read_parameter(fname_my_params, "z_amplitude", &z_amplitude);
	read_parameter(fname_my_params, "btfe_amp", &btfe_amp);
	read_parameter(fname_my_params, "btr_amp", &btr_amp);
	
	/*
	j_delta = 0.0;
	isdist = 0;
	dist_amp = 0;
	dist_freq = 0.1;
	sway_times = 0;
	sway_period = 1;
	sway_xamp = 0;
	sway_yamp = 0;
	sway_zamp = 0;
	pf = fopen("./my_params.dat", "r");
	if(pf != NULL){
		char tmp[256];
		fscanf(pf, "%s %lf", tmp, &j_delta);
		fscanf(pf, "%s %ld", tmp, &isdist);
		fscanf(pf, "%s %lf", tmp, &dist_amp);
		fscanf(pf, "%s %lf", tmp, &dist_freq);
		fscanf(pf, "%s %lf", tmp, &sway_times);
		fscanf(pf, "%s %lf", tmp, &sway_period);
		fscanf(pf, "%s %lf", tmp, &sway_xamp);
		fscanf(pf, "%s %lf", tmp, &sway_yamp);
		fscanf(pf, "%s %lf", tmp, &sway_zamp);
		fclose(pf);
		
		cout << "-- read my_params.dat --" << endl;
		cout << "j_delta=" << j_delta << endl;
		cout << "isdist=" << isdist << endl;
		cout << "dist_amp=" << dist_amp << endl;
		cout << "dist_freq=" << dist_freq << endl;
		cout << "sway_period=" << sway_period << endl;
		cout << "sway_xamp=" << sway_xamp << endl;
		cout << "sway_yamp=" << sway_yamp << endl;
		cout << "sway_zamp=" << sway_zamp << endl;
		cout << "-----------------------" << endl;
	}
	*/
	
	if(cycle*period/dt > max_step){
		cout << "======================================================" << endl;
		cout << "cycle*period/dt is exceeded max_step (=" << max_step << ")" << endl;
		cout << "======================================================" << endl;
	}
	
	start_des_th = joint_des_th();
	des_th = joint_des_th();
	des_thd = zeros(N_DOFS + 1, 1);
	
	// init mosaic
	if(mos.init(module_num, state_dim, action_dim, dt) == true){
		cout << "MOSAIC is initialized!" << endl;
		module_num = mos.get_module_num();
	}
	else{
		cout << "MOSAIC initialization is failed." << endl;
		return false;
	}
	
	// init trace
	// trial, step, time
	// x, u0, u
	// lambda, pred_err
	trace_buff_size = 4 + state_dim + 2*action_dim + 2*module_num + module_num*state_dim;
	trace_buff = new double[trace_buff_size*max_step];
	
	return true;
}

bool class_mosaic_learning::trace(const int trial, const int step, const double time)
{
	//trace_t(0, step) = trial;
	//trace_t(1, step) = step;
	//trace_t(2, step) = time;
	//for(int n = 0; n < state_dim; n++) trace_x(n, step) = x(n);
	//for(int d = 0; d < action_dim; d++) trace_u(d, step) = u(d);
	
	if(step >= max_step){
		cout << "# of step exceeded max_step" << endl;
		return false;
	}
	
	CMatrix lambda = mos.get_lambda();
	CMatrix perr = mos.get_pred_err();
	
	int bias = step*trace_buff_size;
	trace_buff[bias + 0] = trial;
	trace_buff[bias + 1] = step;
	trace_buff[bias + 2] = time;
	trace_buff[bias + 3] = phase;
	bias += 4;
	// state
	for(int n = 0; n <  state_dim; n++) trace_buff[bias + n] = x(n);
	bias += state_dim;
	// output of spg
	for(int d = 0; d < action_dim; d++) trace_buff[bias + d] = u0(d);
	bias += action_dim;
	// output of mosaic
	for(int d = 0; d < action_dim; d++) trace_buff[bias + d] = u(d);
	bias += action_dim;
	// responsibility
	for(int m = 0; m < module_num; m++) trace_buff[bias + m] = lambda(m);
	bias += module_num;
	// prediction error
	for(int m = 0; m < module_num; m++) trace_buff[bias + m] = perr(m);
	bias += module_num;
	// internal state
	for(int m = 0; m < module_num; m++){
		CMatrix kal_xh = mos.get_internal_state(m);
		for(int n = 0; n < state_dim; n++) trace_buff[bias + n] = kal_xh(n);
		bias += state_dim;
	}
	
	last_step = step;
	
	return true;
}



bool class_mosaic_learning::done(const int trial, const int step)
{
	double rol_err = 0, pit_err = 0;
	for(int s = 0; s < step; s += 10){
		int bias = s*trace_buff_size + 4;
		rol_err += dt*pow(trace_buff[bias + 0], 2); // rol
		pit_err += dt*pow(trace_buff[bias + 1], 2); // pit
	}
	cout << "rol_err=" << rol_err << ", pit_err=" << pit_err << endl;
	
	return true;
}

bool class_mosaic_learning::save_trace(const int trial)
{
	char fname[256];
	sprintf(fname, "./log/%06d.dat", trial);
	FILE *pf = fopen(fname, "w");
	
	fprintf(pf, "%d %d\n", trace_buff_size, last_step);
	fprintf(pf, "%d %d\n", state_dim, action_dim);
	fprintf(pf, "%d\n", module_num);
	fprintf(pf, "%f\n", dt);
	if(fwrite(trace_buff, sizeof(double), trace_buff_size*last_step, pf) != (unsigned int)(trace_buff_size*last_step)){
		cout << "cannot fwrite matrix." << endl;
		return false;
	}
	fclose(pf);
	
	cout << "class_mosaic_learning::save_trace is done." << endl;
	cout << "trial=" << trial << ", last_step = " << last_step << ", trace_buff_size = " << trace_buff_size << endl;
	
	return true;
}


//////////////////////////////////////////////////////////
//
// my controllers
//
//////////////////////////////////////////////////////////

bool class_mosaic_learning::go0_controller(const int trial, const int step, const double time)
{
	CMatrix local_des_th = zeros(N_DOFS + 1, 1);
	
	double local_time = time;
	double d = 1.5;
	double td = local_time/(double)d;
	if(td < 1){
		des_th   = start_des_th + (local_des_th - start_des_th)*(10*pow(td, 3) -  15*pow(td, 4) +   6*pow(td, 5));
		des_thd  = start_des_th + (local_des_th - start_des_th)*(30*pow(td, 2) -  60*pow(td, 3) +  30*pow(td, 4))/d;
	}
	else{
		des_th = local_des_th;
		des_thd = zeros(N_DOFS + 1, 1);
	}
	
	return true;
}

bool class_mosaic_learning::rest_controller(const int trial, const int step, const double time)
{
	//CMatrix local_des_th = compute_desired_joint_state(init_p, init_r);
	CMatrix local_des_th = make_traj_jacobian(0);
	
	double local_time = time;
	double d = 1.5;
	double td = local_time/(double)d;
	if(0 <= td && td < 1){
		des_th   = start_des_th + (local_des_th - start_des_th)*(10*pow(td, 3) -  15*pow(td, 4) +   6*pow(td, 5));
		des_thd  =                (local_des_th - start_des_th)*(30*pow(td, 2) -  60*pow(td, 3) +  30*pow(td, 4))/d;
		//des_thd = zeros(N_DOFS + 1, 1);
	}
	else{
		//CMatrix j_th = joint_th();
		des_th = local_des_th;
		//des_thd = (local_des_th - j_th)/dt;
		des_thd = zeros(N_DOFS + 1, 1);
	}
	return true;
}

bool class_mosaic_learning::init_controller(const int trial, const int step, const double time, const double time_max,
											CMatrix &gyro, CMatrix &ff)
{
	// blending ratio
	double w = time_max*0.8;
	double d = time/w;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	double alpha = -2*pow(d, 3) + 3*pow(d, 2);
	
	//
	CMatrix local_des_th = make_traj_jacobian(0);
	des_th = alpha*local_des_th + (1 - alpha)*start_des_th;
	des_thd = zeros(N_DOFS + 1, 1);
	
	// simple fb
	des_th(L_AFE) += simple_fb(gyro)*alpha;
	des_th(R_AFE) += simple_fb(gyro)*alpha;
	
	mosaic_controller(trial, step, time, alpha, gyro, ff);
	
	return true;
}

bool class_mosaic_learning::finish_controller(const int trial, const int step, const double time, const double time_max,
											  CMatrix &gyro, CMatrix &ff)
{
	// blending ratio
	double w = time_max*0.8;
	double d = 1 - time/w;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	double alpha = -2*pow(d, 3) + 3*pow(d, 2);
	
	//
	CMatrix local_des_th = make_traj_jacobian(0);
	des_th = local_des_th;
	des_thd = zeros(N_DOFS + 1, 1);
	
	// simple fb
	des_th(L_AFE) += simple_fb(gyro)*alpha;
	des_th(R_AFE) += simple_fb(gyro)*alpha;
	
	mosaic_controller(trial, step, time, alpha, gyro, ff);
	
	if(time > w) return false;
	return true;
}

bool class_mosaic_learning::sway_controller(const int trial, const int step, const double time, CMatrix &gyro, CMatrix &ff)
{
	double local_time = time;
	
	// make nominal trajctory of sway movement
	phase = fmod(2*PI*local_time/period, 2*PI);
	CMatrix local_des_th = make_traj_jacobian(phase);
	
	des_th = local_des_th;
	des_thd = zeros(N_DOFS + 1, 1);
	
	// simple fb
	des_th(L_AFE) += simple_fb(gyro);
	des_th(R_AFE) += simple_fb(gyro);
	
	// mosaic
	mosaic_controller(trial, step, time, 1, gyro, ff);
	
	if(cycle*period < local_time) return false;
	return true;
}

CMatrix class_mosaic_learning::make_traj(const double phase_)
{
	CMatrix ret_des_th = rest_des_th;
	
	// HFE: -30  90
	// KFE:   0 120
	// AFE: -30  30
	
	double wave = (-cos(phase_) + 1)/(double)2;
	
	ret_des_th(L_HFE) = rest_des_th(L_HFE) + wave*15/(double)180*PI;
	ret_des_th(L_KFE) = rest_des_th(L_KFE) + wave*30/(double)180*PI;
	ret_des_th(L_AFE) = rest_des_th(L_AFE) + wave*15/(double)180*PI;
	
	ret_des_th(R_HFE) = rest_des_th(R_HFE) + wave*15/(double)180*PI;
	ret_des_th(R_KFE) = rest_des_th(R_KFE) + wave*30/(double)180*PI;
	ret_des_th(R_AFE) = rest_des_th(R_AFE) + wave*15/(double)180*PI;
	
	return ret_des_th;
}

CMatrix class_mosaic_learning::make_traj_jacobian(const double phi_)
{
	CMatrix p[2];
	double phi = phi_;
	double wave = 0.5*(cos(phi + PI) + 1);
	for(int lr = 0; lr < 2; lr++){
		p[lr] = init_p[lr];
		p[lr](1) = init_p[lr](1) + wave*y_amplitude;
		p[lr](2) = init_p[lr](2) + wave*z_amplitude;
	}
	
	CMatrix ret_des_th = compute_desired_joint_state(p, init_r);
	
	// 
	double wave0 = 0.5*(cos(phi + PI) + 1);
	double wave1 = 0.5*(cos(phi) + 1);
	double wave2 = sin(phi);
	//double btfe_amp = 20, btr_amp = 15;
	//double sfe_amp = 100, saa_amp = 30, hr_amp = 40, eb_amp = 70;
	
	// torso
	double pre = ret_des_th(B_TFE);
	ret_des_th(B_TFE) += wave0*btfe_amp*PI/(double)180;
	ret_des_th(B_TR)  += wave2*btr_amp*PI/(double)180;
	//cout << ret_des_th(B_TFE) << " = " << pre << " + " << wave0 << "*" << btfe_amp << "*" << PI/(double)180 << endl;
	//getchar();
	
	// arm
	ret_des_th(L_SFE) += wave0*sfe_amp*PI/(double)180;
	ret_des_th(R_SFE) += wave0*sfe_amp*PI/(double)180;
	
	ret_des_th(L_SAA) += wave0*saa_amp*PI/(double)180;
	ret_des_th(R_SAA) += wave0*saa_amp*PI/(double)180;
	
	ret_des_th(L_HR) += wave0*hr_amp*PI/(double)180;
	ret_des_th(R_HR) += wave0*hr_amp*PI/(double)180;
	
	ret_des_th(L_EB) += wave0*eb_amp*PI/(double)180;
	ret_des_th(R_EB) += wave0*eb_amp*PI/(double)180;
	
	// head
	ret_des_th(B_HN) += 0.5*(cos(phi + PI) + 1)*25*PI/(double)180;
	
	return ret_des_th;
	
}

double class_mosaic_learning::simple_fb(CMatrix &gyro)
{
	return -0.2*gyro(1) - 0.1*gyro(1 + 3);
}

bool class_mosaic_learning::mosaic_controller(const int trial, const int step, const double time, const double alpha,
											  CMatrix &gyro, CMatrix &ff)
{
	double local_time = time;
	
	//
#ifdef USE_ARM
	int action_idx[] = {L_SFE/* 0*/, L_SAA/* 1*/, L_HR /* 2*/, L_EB /* 3*/, L_WR/* 4*/, L_WFE/* 5*/, L_WAA/* 6*/,
						R_SFE/* 7*/, R_SAA/* 8*/, R_HR /* 9*/, R_EB /*10*/, R_WR/*11*/, R_WFE/*12*/, R_WAA/*13*/,
						B_TFE/*14*/, B_TAA/*15*/,
						L_HFE/*16*/, L_HAA/*17*/, L_HFR/*18*/, L_KFE/*19*/, L_AR/*20*/, L_AFE/*21*/, L_AAA/*22*/,
						R_HFE/*23*/, R_HAA/*24*/, R_HFR/*25*/, R_KFE/*26*/, R_AR/*27*/, R_AFE/*28*/, R_AAA/*29*/};
	double amp_noise[] = {1, 1, 1, 1, 0, 0, 0,
						  1, 1, 1, 1, 0, 0, 0,
						  1, 1,
						  1, 1, 1, 1, 1, 1, 1,
						  1, 1, 1, 1, 1, 1, 1};
#else
	int action_idx[] = {B_TFE/* 0*/, B_TAA/* 1*/,
						L_HFE/* 2*/, L_HAA/* 3*/, L_HFR/* 4*/, L_KFE/* 5*/, L_AR/* 6*/, L_AFE/* 7*/, L_AAA/* 8*/,
						R_HFE/* 9*/, R_HAA/*10*/, R_HFR/*11*/, R_KFE/*12*/, R_AR/*13*/, R_AFE/*14*/, R_AAA/*15*/};
	double amp_noise[] = {1, 1,
						  1, 1, 1, 1, 0, 1, 1,
						  1, 1, 1, 1, 0, 1, 1};
#endif // USE_ARM
	
	u0 = zeros(action_dim, 1);
	for(int d = 0; d < action_dim; d++){
		u0(d) = des_th(action_idx[d]);
	}
	
	//
	CMatrix j_th = joint_th(), j_thd = joint_thd();
	x = conv_mosaic_state(j_th, j_thd, gyro, ff);
	
	
	// disturbance
	if(explore == true){
		if(step == 0) u = zeros(action_dim, 1);
		for(int d = 0; d < action_dim; d++){
			double rho = exp(-dt*dist_freq);
			double noise = dist_amp*randn()*amp_noise[d]/(double)180*PI;
			u(d) = noise/rho*dt + rho*u(d);
		}
		double gain = 0.01;
#ifdef USE_ARM
		double diff_sfe = u(0) - u(7);
		double diff_saa = u(1) - u(8);
		u(0) -= gain*diff_sfe;
		u(7) += gain*diff_sfe;
		u(1) -= gain*diff_saa;
		u(8) -= gain*diff_saa;
		
		double diff_afe = u(21) - u(28);
		double diff_aaa = u(22) + u(29);
		u(21) -= gain*diff_afe;
		u(28) += gain*diff_afe;
		u(22) -= gain*diff_aaa;
		u(29) -= gain*diff_aaa;
#else
		double diff_afe = u(7) - u(14);
		double diff_aaa = u(8) + u(15);
		u( 7) -= gain*diff_afe;
		u(14) += gain*diff_afe;
		u( 8) -= gain*diff_aaa;
		u(15) -= gain*diff_aaa;
#endif // USE_ARM
		
		u -= 0.01*u;
		
		for(int d = 0; d < action_dim; d++){
			// apply u into des_x
			des_th(action_idx[d]) += u(d);
		}
		
		return true;
	}
	
	
	static CMatrix pre_x(state_dim, 1), pre_u(action_dim, 1);
	CMatrix xd(state_dim, 1);
	
	if(step == 0){
		pre_x = x;
		pre_u = zeros(action_dim, 1);
	}
	
	// alpha = blending ratio
	u = alpha*mos.output(step, x, pre_u, phase);
	//u = zeros(action_dim, 1);
	
	double limit = 10.0/(double)180*PI;
	for(int d = 0; d < action_dim; d++){
		if(u(d) < -limit) u(d) = -limit;
		if(u(d) >  limit) u(d) =  limit;
		des_th(action_idx[d]) += u(d);
	}
	
	// store
	pre_x = x;
	pre_u = u;
	
	return true;
}




