/*!=============================================================================
  ==============================================================================

  \file    mosaic_learning.h

  \author  Norikazu Sugimoto
  \date    Dec. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _MOSAIC_LEARNING_H_
#define _MOSAIC_LEARNING_H_

#include "SL.h"
#include "SL_user.h"
#include "mosaic.h"
#include "matrix.h"
#include "tools.h"

#ifndef PI
#define PI 3.14159
#endif

#define DOF_LEG 7
#define DOF_ARM 7

#define USE_ARM

class class_mosaic_learning{
	//
	// constructor & destructor
	//
  public:
	class_mosaic_learning();
	~class_mosaic_learning();
	
	//
	// member valiables
	//
  private:
#ifdef USE_ARM
	static const int state_dim = 2*(2 + 2*DOF_ARM + 2 + 2*DOF_LEG), action_dim = 2*DOF_ARM + 2 + 2*DOF_LEG;
#else
	static const int state_dim = 2*(2 + 2 + 2*DOF_LEG), action_dim = 2 + 2*DOF_LEG;
#endif //USE_ARM
	static const double l3 = 15.43*2.54*0.01, l5 = 15*2.54*0.01; // sum is 77.2922*0.01
	//int state_idx[state_dim], action_idx[action_dim];
	
	int max_step;
	double dt;
	int trial;
	double rest_xd[256];
	char log_idx[256];
	char result_file_path[256];
	bool isinit;
	
	CMatrix rest_des_th;
	
	CMatrix init_p[2], init_r[2]; // rest positions
	
	CMatrix start_th, start_des_th;
	double time0;
	CMatrix des_th, des_thd, des_thdd;
	double j_delta;
	
	// for sway movement
	bool explore;
	double dist_amp, dist_freq;
	double phase;
	double cycle, period, y_amplitude, z_amplitude;
	double btfe_amp, btr_amp;
	double sfe_amp, saa_amp, hr_amp, eb_amp;
	
	//double sway_times;
	//double sway_period, sway_xamp, sway_yamp, sway_zamp;
	
	// for mosaic
	class_mosaic mos;
	int module_num;
	static const int max_module_num = 100;
	CMatrix x, u0, u;
	
	// trace
	//CMatrix trace_t, trace_x, trace_u;
	int trace_buff_size, last_step;
	double *trace_buff;
	
	//
	// member functions
	//
  public:
	bool init(const int _max_step, const double _dt, const int _trial);
	bool trace(const int trial, const int step, const double time);
	bool done(const int trial, const int step);
	//static void *save_trace(void *arg);
	bool save_trace(const int trial);
	
	
	bool go0_controller(const int trial, const int step, const double time);
	bool rest_controller(const int trial, const int step, const double time);
	bool init_controller(const int trial, const int step, const double time, const double time_max, CMatrix &gyro, CMatrix &ff);
	bool finish_controller(const int trial, const int step, const double time, const double time_max, CMatrix &gyro, CMatrix &ff);
	bool sway_controller(const int trial, const int step, const double time, CMatrix &gyro, CMatrix &ff);
	CMatrix make_traj(double phase_);
	CMatrix make_traj_jacobian(double phase_);
	double simple_fb(CMatrix &gyro);
	bool mosaic_controller(const int trial, const int step, const double time, const double alpha, CMatrix &gyro, CMatrix &ff);
	
	CMatrix conv_mosaic_state(CMatrix &j_th, CMatrix &j_thd, CMatrix &gyro, CMatrix &ff);
	CMatrix joint_th(void){
		CMatrix ret(N_DOFS + 1, 1);
		for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_state[i].th;
		return ret;
	};
	CMatrix joint_thd(void){
		CMatrix ret(N_DOFS + 1, 1);
		for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_state[i].thd;
		return ret;
	};
	CMatrix joint_des_th(void){
		CMatrix ret(N_DOFS + 1, 1);
		for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_des_state[i].th;
		return ret;
	};
	CMatrix joint_des_thd(void){
		CMatrix ret(N_DOFS + 1, 1);
		for(int i = 1; i <= N_DOFS; i++) ret(i) = joint_des_state[i].thd;
		return ret;
	};
	
	CMatrix get_desired_th(void){return des_th;};
	CMatrix get_desired_thd(void){return des_thd;};
	CMatrix get_desired_thdd(void){return des_thdd;};
	
	//bool set_start_th(const CMatrix &th){start_th = th; return true;};
	//CMatrix get_start_th(void){return start_th;};
	CMatrix get_rest_des_th(void){return rest_des_th;}
	
	CMatrix Jacobian(CMatrix &t);
	CMatrix ankle_pos(CMatrix &t);
	CMatrix ankle_rot(CMatrix &t);
	CMatrix compute_desired_joint_state(CMatrix *p, CMatrix *r);
	CMatrix rot2omega(CMatrix &r);
	CMatrix rodrigues(CMatrix &a, double t);
	
	// for NN revise
	CMatrix make_traj_NN_revise(const double phase_);
	double simple_fb_NN_revise(CMatrix &gyro);
	bool set_state(CMatrix gyro);
	bool init_NN_revise(const int _max_step, const double _dt, const int _trial);
	bool trace_NN_revise(const int trial, const int step, const double time);
	bool done_NN_revise(const int trial, const int step);
	bool save_trace_NN_revise(const int trial);
	bool rest_controller_NN_revise(const int trial, const int step, const double time, const double phase);
	bool rest_controller_NN_revise(const int trial, const int step, const double time);
	bool init_controller_NN_revise(const int trial, const int step, const double time, const double time_max, CMatrix &gyro, CMatrix &ff);
	bool finish_controller_NN_revise(const int trial, const int step, const double time, const double time_max, CMatrix &gyro, CMatrix &ff);
	bool sampling_controller_NN_revise(const int trial, const int step, const double time, CMatrix &gyro, CMatrix &ff);
	bool periodic_controller_NN_revise(const int trial, const int step, const double time, CMatrix &gyro, CMatrix &ff);
	bool mosaic_controller_NN_revise(const int trial, const int step, const double time, const double alpha, CMatrix &gyro, CMatrix &ff);
	
};

inline CMatrix class_mosaic_learning::conv_mosaic_state(CMatrix &j_th, CMatrix &j_thd, CMatrix &gyro, CMatrix &ff)
{
	CMatrix ret(state_dim, 1);
	if(state_dim == 2*(2 + 2*DOF_LEG)){
		ret( 0) = gyro(0); // gyro roll
		ret( 1) = gyro(1); // gyro pitch
		ret( 2) = j_th(L_HFE);
		ret( 3) = j_th(L_HAA);
		ret( 4) = j_th(L_HFR);
		ret( 5) = j_th(L_KFE);
		ret( 6) = j_th(L_AR);
		ret( 7) = j_th(L_AFE);
		ret( 8) = j_th(L_AAA);
		ret( 9) = j_th(R_HFE);
		ret(10) = j_th(R_HAA);
		ret(11) = j_th(R_HFR);
		ret(12) = j_th(R_KFE);
		ret(13) = j_th(R_AR);
		ret(14) = j_th(R_AFE);
		ret(15) = j_th(R_AAA);
		
		ret( 0 + 16) = gyro(3); // gyro roll
		ret( 1 + 16) = gyro(4); // gyro pitch
		ret( 2 + 16) = j_thd(L_HFE);
		ret( 3 + 16) = j_thd(L_HAA);
		ret( 4 + 16) = j_thd(L_HFR);
		ret( 5 + 16) = j_thd(L_KFE);
		ret( 6 + 16) = j_thd(L_AR);
		ret( 7 + 16) = j_thd(L_AFE);
		ret( 8 + 16) = j_thd(L_AAA);
		ret( 9 + 16) = j_thd(R_HFE);
		ret(10 + 16) = j_thd(R_HAA);
		ret(11 + 16) = j_thd(R_HFR);
		ret(12 + 16) = j_thd(R_KFE);
		ret(13 + 16) = j_thd(R_AR);
		ret(14 + 16) = j_thd(R_AFE);
		ret(15 + 16) = j_thd(R_AAA);
	}
	else if(state_dim == 2*(2 + 2 + 2*DOF_LEG)){
		ret( 0) = gyro(0); // gyro roll
		ret( 1) = gyro(1); // gyro pitch
		//ret( 2) = ff(0);   // foot force left
		//ret( 3) = ff(1);   // foot force right
		ret( 2) = j_th(B_TFE); // foot force left
		ret( 3) = j_th(B_TAA); // foot force right
		ret( 4) = j_th(L_HFE);
		ret( 5) = j_th(L_HAA);
		ret( 6) = j_th(L_HFR);
		ret( 7) = j_th(L_KFE);
		ret( 8) = j_th(L_AR);
		ret( 9) = j_th(L_AFE);
		ret(10) = j_th(L_AAA);
		ret(11) = j_th(R_HFE);
		ret(12) = j_th(R_HAA);
		ret(13) = j_th(R_HFR);
		ret(14) = j_th(R_KFE);
		ret(15) = j_th(R_AR);
		ret(16) = j_th(R_AFE);
		ret(17) = j_th(R_AAA);
		
		ret( 0 + 18) = gyro(3); // gyro roll
		ret( 1 + 18) = gyro(4); // gyro pitch
		//ret( 2 + 18) = ff(2);   // foot force left
		//ret( 3 + 18) = ff(3);   // foot force right
		ret( 2 + 18) = j_thd(B_TFE); // foot force left
		ret( 3 + 18) = j_thd(B_TAA); // foot force right
		ret( 4 + 18) = j_thd(L_HFE);
		ret( 5 + 18) = j_thd(L_HAA);
		ret( 6 + 18) = j_thd(L_HFR);
		ret( 7 + 18) = j_thd(L_KFE);
		ret( 8 + 18) = j_thd(L_AR);
		ret( 9 + 18) = j_thd(L_AFE);
		ret(10 + 18) = j_thd(L_AAA);
		ret(11 + 18) = j_thd(R_HFE);
		ret(12 + 18) = j_thd(R_HAA);
		ret(13 + 18) = j_thd(R_HFR);
		ret(14 + 18) = j_thd(R_KFE);
		ret(15 + 18) = j_thd(R_AR);
		ret(16 + 18) = j_thd(R_AFE);
		ret(17 + 18) = j_thd(R_AAA);
	}
	else if(state_dim == 2*(2 + 2*DOF_ARM + 2 + 2*DOF_LEG)){
		// pos
		ret( 0) = gyro(0); // gyro roll
		ret( 1) = gyro(1); // gyro pitch
		
		ret( 2) = j_th(L_SFE);
		ret( 3) = j_th(L_SAA);
		ret( 4) = j_th(L_HR);
		ret( 5) = j_th(L_EB);
		ret( 6) = j_th(L_WR);
		ret( 7) = j_th(L_WFE);
		ret( 8) = j_th(L_WAA);
		
		ret( 9) = j_th(R_SFE);
		ret(10) = j_th(R_SAA);
		ret(11) = j_th(R_HR);
		ret(12) = j_th(R_EB);
		ret(13) = j_th(R_WR);
		ret(14) = j_th(R_WFE);
		ret(15) = j_th(R_WAA);
		
		ret(16) = j_th(B_TFE);
		ret(17) = j_th(B_TAA);
		
		ret(18) = j_th(L_HFE);
		ret(19) = j_th(L_HAA);
		ret(20) = j_th(L_HFR);
		ret(21) = j_th(L_KFE);
		ret(22) = j_th(L_AR);
		ret(23) = j_th(L_AFE);
		ret(24) = j_th(L_AAA);
		
		ret(25) = j_th(R_HFE);
		ret(26) = j_th(R_HAA);
		ret(27) = j_th(R_HFR);
		ret(28) = j_th(R_KFE);
		ret(29) = j_th(R_AR);
		ret(30) = j_th(R_AFE);
		ret(31) = j_th(R_AAA);
		
		// vel
		ret( 0 + 32) = gyro(3); // gyro roll
		ret( 1 + 32) = gyro(4); // gyro pitch
		
		ret( 2 + 32) = j_thd(L_SFE);
		ret( 3 + 32) = j_thd(L_SAA);
		ret( 4 + 32) = j_thd(L_HR);
		ret( 5 + 32) = j_thd(L_EB);
		ret( 6 + 32) = j_thd(L_WR);
		ret( 7 + 32) = j_thd(L_WFE);
		ret( 8 + 32) = j_thd(L_WAA);
		
		ret( 9 + 32) = j_thd(R_SFE);
		ret(10 + 32) = j_thd(R_SAA);
		ret(11 + 32) = j_thd(R_HR);
		ret(12 + 32) = j_thd(R_EB);
		ret(13 + 32) = j_thd(R_WR);
		ret(14 + 32) = j_thd(R_WFE);
		ret(15 + 32) = j_thd(R_WAA);
		
		ret(16 + 32) = j_thd(B_TFE);
		ret(17 + 32) = j_thd(B_TAA);
		
		ret(18 + 32) = j_thd(L_HFE);
		ret(19 + 32) = j_thd(L_HAA);
		ret(20 + 32) = j_thd(L_HFR);
		ret(21 + 32) = j_thd(L_KFE);
		ret(22 + 32) = j_thd(L_AR);
		ret(23 + 32) = j_thd(L_AFE);
		ret(24 + 32) = j_thd(L_AAA);
		
		ret(25 + 32) = j_thd(R_HFE);
		ret(26 + 32) = j_thd(R_HAA);
		ret(27 + 32) = j_thd(R_HFR);
		ret(28 + 32) = j_thd(R_KFE);
		ret(29 + 32) = j_thd(R_AR);
		ret(30 + 32) = j_thd(R_AFE);
		ret(31 + 32) = j_thd(R_AAA);
	}
	
	return ret;
}


inline CMatrix class_mosaic_learning::Jacobian(CMatrix &t)
{
	CMatrix J(6, 7);
	double S0 = sin(t(0)), S1 = sin(t(1)), S2 = sin(t(2)), S3 = sin(t(3)), S4 = sin(t(4)), S5 = sin(t(5)), S6 = sin(t(6));
	double C0 = cos(t(0)), C1 = cos(t(1)), C2 = cos(t(2)), C3 = cos(t(3)), C4 = cos(t(4)), C5 = cos(t(5)), C6 = cos(t(6));
	
	J(0, 0) = 0;
	J(1, 0) = C0*C1*l3-l5*S3*C0*S1*S2-l5*S3*S0*C2+l5*C0*C1*C3;
	J(2, 0) = S0*C1*l3-l5*S3*S0*S1*S2+l5*S3*C0*C2+l5*S0*C1*C3;
	J(3, 0) = 1;
	J(4, 0) = 0;
	J(5, 0) = 0;
	
	J(0, 1) = -C1*l3+l5*S3*S1*S2-l5*C1*C3;
	J(1, 1) = -S0*(S1*l3+l5*C1*S2*S3+l5*S1*C3);
	J(2, 1) = C0*(S1*l3+l5*C1*S2*S3+l5*S1*C3);
	J(3, 1) = 0;
	J(4, 1) = C0;
	J(5, 1) = S0;
	
	J(0, 2) = -C1*l5*S3*C2;
	J(1, 2) = -S3*(S0*S1*C2+C0*S2)*l5;
	J(2, 2) = S3*(-S0*S2+C0*S1*C2)*l5;
	J(3, 2) = S1;
	J(4, 2) = -S0*C1;
	J(5, 2) = C0*C1;
	
	J(0, 3) = -l5*(-S1*S3+C1*S2*C3);
	J(1, 3) = l5*(C0*C2*C3-S0*C1*S3-S0*S2*S1*C3);
	J(2, 3) = l5*(C0*C1*S3+C0*S2*S1*C3+S0*C2*C3);
	J(3, 3) = C1*C2;
	J(4, 3) = S0*S1*C2+C0*S2;
	J(5, 3) = -C0*S1*C2+S0*S2;
	J(0, 4) = 0;
	
	J(1, 4) = 0;
	J(2, 4) = 0;
	J(3, 4) = C1*S2*S3+S1*C3;
	J(4, 4) = S3*S0*S1*S2-S3*C0*C2-S0*C1*C3;
	J(5, 4) = -S3*C0*S1*S2-S3*S0*C2+C0*C1*C3;
	
	J(0, 5) = 0;
	J(1, 5) = 0;
	J(2, 5) = 0;
	J(3, 5) = C1*C2*C4-S4*S2*C1*C3+S4*S3*S1;
	J(4, 5) = C4*C0*S2+C4*S1*S0*C2+S4*C0*C2*C3-S4*S0*C1*S3-S4*S0*S2*S1*C3;
	J(5, 5) = -C4*S1*C0*C2+C4*S0*S2+S4*C0*C1*S3+S4*C0*S2*S1*C3+S4*S0*C2*C3;
	
	J(0, 6) = 0;
	J(1, 6) = 0;
	J(2, 6) = 0;
	J(3, 6) = -C5*C1*C2*S4-C5*C4*S2*C1*C3+C5*C4*S3*S1+S5*C1*S2*S3+S5*S1*C3;
	J(4, 6) = -C5*S4*C0*S2-C5*S4*S1*S0*C2+C5*C4*C0*C2*C3-C5*C4*S0*C1*S3-C5*C4*S0*S2*S1*C3+S5*S3*S0*S1*S2-S5*S3*C0*C2-S5*S0*C1*C3;
	J(5, 6) = C5*S4*S1*C0*C2-C5*S4*S0*S2+C5*C4*C0*C1*S3+C5*C4*C0*S2*S1*C3+C5*C4*S0*C2*C3-S5*S3*C0*S1*S2-S5*S3*S0*C2+S5*C0*C1*C3;
	
	return J;
}

inline CMatrix class_mosaic_learning::ankle_pos(CMatrix &t)
{
	CMatrix p(3, 1);
	double S0 = sin(t(0)), S1 = sin(t(1)), S2 = sin(t(2)), S3 = sin(t(3)), S4 = sin(t(4)), S5 = sin(t(5)), S6 = sin(t(6));
	double C0 = cos(t(0)), C1 = cos(t(1)), C2 = cos(t(2)), C3 = cos(t(3)), C4 = cos(t(4)), C5 = cos(t(5)), C6 = cos(t(6));
	
	p(0) = -S1*l3-(C1*S2*S3+S1*C3)*l5;
	p(1) = S0*C1*l3-(-(-S0*S1*S2+C0*C2)*S3-S0*C1*C3)*l5;
	p(2) = -C0*C1*l3-(-(C0*S1*S2+S0*C2)*S3+C0*C1*C3)*l5;
	
	return p;
}

inline CMatrix class_mosaic_learning::ankle_rot(CMatrix &t)
{
	CMatrix R(3, 3);
	double S0 = sin(t(0)), S1 = sin(t(1)), S2 = sin(t(2)), S3 = sin(t(3)), S4 = sin(t(4)), S5 = sin(t(5)), S6 = sin(t(6));
	double C0 = cos(t(0)), C1 = cos(t(1)), C2 = cos(t(2)), C3 = cos(t(3)), C4 = cos(t(4)), C5 = cos(t(5)), C6 = cos(t(6));
	
	R(0, 0) = (C1*C2*C4+(-C1*S2*C3+S1*S3)*S4)*C6-(-(-C1*C2*S4+(-C1*S2*C3+S1*S3)*C4)*S5+(C1*S2*S3+S1*C3)*C5)*S6;
	R(0, 1) = (-C1*C2*S4+(-C1*S2*C3+S1*S3)*C4)*C5+(C1*S2*S3+S1*C3)*S5;
	R(0, 2) = (C1*C2*C4+(-C1*S2*C3+S1*S3)*S4)*S6+(-(-C1*C2*S4+(-C1*S2*C3+S1*S3)*C4)*S5+(C1*S2*S3+S1*C3)*C5)*C6;
	
	R(1, 0) = ((S0*S1*C2+C0*S2)*C4+((-S0*S1*S2+C0*C2)*C3-S0*C1*S3)*S4)*C6-
		(-(-(S0*S1*C2+C0*S2)*S4+((-S0*S1*S2+C0*C2)*C3-S0*C1*S3)*C4)*S5+(-(-S0*S1*S2+C0*C2)*S3-S0*C1*C3)*C5)*S6;
	R(1, 1) = (-(S0*S1*C2+C0*S2)*S4+((-S0*S1*S2+C0*C2)*C3-S0*C1*S3)*C4)*C5+(-(-S0*S1*S2+C0*C2)*S3-S0*C1*C3)*S5;
	R(1, 2) = ((S0*S1*C2+C0*S2)*C4+((-S0*S1*S2+C0*C2)*C3-S0*C1*S3)*S4)*S6+
		(-(-(S0*S1*C2+C0*S2)*S4+((-S0*S1*S2+C0*C2)*C3-S0*C1*S3)*C4)*S5+(-(-S0*S1*S2+C0*C2)*S3-S0*C1*C3)*C5)*C6;
	
	R(2, 0) = ((-C0*S1*C2+S0*S2)*C4+((C0*S1*S2+S0*C2)*C3+C0*C1*S3)*S4)*C6-
		(-(-(-C0*S1*C2+S0*S2)*S4+((C0*S1*S2+S0*C2)*C3+C0*C1*S3)*C4)*S5+(-(C0*S1*S2+S0*C2)*S3+C0*C1*C3)*C5)*S6;
	R(2, 1) = (-(-C0*S1*C2+S0*S2)*S4+((C0*S1*S2+S0*C2)*C3+C0*C1*S3)*C4)*C5+(-(C0*S1*S2+S0*C2)*S3+C0*C1*C3)*S5;
	R(2, 2) = ((-C0*S1*C2+S0*S2)*C4+((C0*S1*S2+S0*C2)*C3+C0*C1*S3)*S4)*S6+
		(-(-(-C0*S1*C2+S0*S2)*S4+((C0*S1*S2+S0*C2)*C3+C0*C1*S3)*C4)*S5+(-(C0*S1*S2+S0*C2)*S3+C0*C1*C3)*C5)*C6;
	
	return R;
}

inline CMatrix class_mosaic_learning::compute_desired_joint_state(CMatrix *p, CMatrix *r)
{
	CMatrix t[2];
	CMatrix j_th = joint_th();
	double s[2][DOF_LEG] = {{ 1, -1,  1, -1,  1,  1, -1},
							{ 1,  1, -1, -1, -1,  1,  1}};
	
	t[0] = zeros(DOF_LEG, 1);
	t[0](0) = j_th(L_HFE);
	t[0](1) = j_th(L_HAA);
	t[0](2) = j_th(L_HFR);
	t[0](3) = j_th(L_KFE);
	t[0](4) = j_th(L_AR);
	t[0](5) = j_th(L_AFE);
	t[0](6) = j_th(L_AAA);
	
	t[1] = zeros(DOF_LEG, 1);
	t[1](0) = j_th(R_HFE);
	t[1](1) = j_th(R_HAA);
	t[1](2) = j_th(R_HFR);
	t[1](3) = j_th(R_KFE);
	t[1](4) = j_th(R_AR);
	t[1](5) = j_th(R_AFE);
	t[1](6) = j_th(R_AAA);
	for(int n = 0; n < DOF_LEG; n++) t[0](n) *= s[0][n];
	for(int n = 0; n < DOF_LEG; n++) t[1](n) *= s[1][n];
	
	CMatrix des_t[2];
	double max_qd = 0;
	for(int lr = 0; lr < 2; lr++) des_t[lr] = t[lr];
		
	for(int lr = 0; lr < 2; lr++){
		int loop_max = 5; // don't exceed 10
		CMatrix a_r(3, 1), a_p(3, 1), a_y(3, 1);
		CMatrix r_r, r_p, r_y;
		a_r(0) =  0; a_r(1) = 1; a_r(2) = 0;
		a_p(0) = -1; a_p(1) = 0; a_p(2) = 0;
		a_y(0) =  0; a_y(1) = 0; a_y(2) = 1;
		r_r = rodrigues(a_r, r[lr](0));
		r_p = rodrigues(a_p, r[lr](1));
		r_y = rodrigues(a_y, r[lr](2));
		
		CMatrix R = r_r*r_p*r_y;
		for(int l = 0; l < loop_max; l++){
			CMatrix J = Jacobian(des_t[lr]);
			CMatrix JJ = J*trans(J);
			CMatrix invJ = trans(J)*inv(JJ);
			
			//
			CMatrix perr  = p[lr] - ankle_pos(des_t[lr]);
			CMatrix cR   = ankle_rot(des_t[lr]); // current rotation matrix
			CMatrix Rerr  = inv(cR)*R;
			CMatrix werr = R*rot2omega(Rerr);
			
			CMatrix err = combine_ud(perr, werr);
			CMatrix qd = (j_delta/(double)loop_max)*invJ*err;
			qd(4) = 0;
			
			des_t[lr] = des_t[lr] + qd;
		}
	}
	
	// limiter
	double w = 20*PI; // rad/sec
	for(int lr = 0; lr < 2; lr++){
		for(int n = 0; n < DOF_LEG; n++){
			if(des_t[lr](n) > t[lr](n) + w*dt){
				des_t[lr](n) = t[lr](n) + w*dt;
				//cout << lr << ", " << n << endl;
			}
			if(des_t[lr](n) < t[lr](n) - w*dt){
				des_t[lr](n) = t[lr](n) - w*dt;
				//cout << lr << ", " << n << endl;
			}
		}
	}
	
	//
	CMatrix ret = rest_des_th;
	for(int n = 0; n < DOF_LEG; n++) des_t[0](n) *= s[0][n];
	for(int n = 0; n < DOF_LEG; n++) des_t[1](n) *= s[1][n];
	
	ret(L_HFE) = des_t[0](0);
	ret(L_HAA) = des_t[0](1);
	ret(L_HFR) = des_t[0](2);
	ret(L_KFE) = des_t[0](3);
	//ret(L_AR)  = des_t[0](4);
	ret(L_AFE) = des_t[0](5);
	ret(L_AAA) = des_t[0](6);
	
	ret(R_HFE) = des_t[1](0);
	ret(R_HAA) = des_t[1](1);
	ret(R_HFR) = des_t[1](2);
	ret(R_KFE) = des_t[1](3);
	//ret(R_AR)  = des_t[1](4);
	ret(R_AFE) = des_t[1](5);
	ret(R_AAA) = des_t[1](6);
	
	return ret;
}

inline CMatrix class_mosaic_learning::rot2omega(CMatrix &r)
{
	CMatrix ret(3, 1);
	double a = (r(0, 0) + r(1, 1) + r(2, 2))/(double)3;
	if(fabs(a - 1) < 1e-6){
		ret(0) = 0;
		ret(1) = 0;
		ret(2) = 0;
	}
	else{
		double s = acos(a);
		double b = 0.5*s/sin(s);
		ret(0) = b*(r(2, 1) - r(1, 2));
		ret(1) = b*(r(0, 2) - r(2, 0));
		ret(2) = b*(r(1, 0) - r(0, 1));
	}
	return ret;
}
inline CMatrix class_mosaic_learning::rodrigues(CMatrix &a, double t)
{
	CMatrix ret, ah(3, 3);
	ah(0, 0) =     0; ah(0, 1) = -a(2); ah(0, 2) =  a(1);
	ah(1, 0) =  a(2); ah(1, 1) =     0; ah(1, 2) = -a(0);
	ah(2, 0) = -a(1); ah(2, 1) =  a(0); ah(2, 2) =     0;
	ret = eye(3) + ah*sin(t) + ah*ah*(1 - cos(t));
	
	return ret;
}

#endif // end of _MOSAIC_LEARNING_H_
