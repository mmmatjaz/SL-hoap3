#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <assert.h>
#include <float.h>

#include "SL.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"

#include "matrix.h"
#include "tools.h"

#include "mosaic_learning.h"

enum{
	SQUATTING,
	LIFTING
};
#define TASK SQUATTING

// utilities
CMatrix class_mosaic_learning::make_traj_NN_revise(const double phase_)
{
	CMatrix ret_des_th = rest_des_th;
	
	double wave = (1 - cos(phase_))/(double)2;
	double amp = 15/(double)180*PI;
	
	ret_des_th(L_HFE) = rest_des_th(L_HFE) +   wave*amp;
	ret_des_th(L_KFE) = rest_des_th(L_KFE) + 2*wave*amp;
	ret_des_th(L_AFE) = rest_des_th(L_AFE) +   wave*amp;
	
	ret_des_th(R_HFE) = rest_des_th(R_HFE) +   wave*amp;
	ret_des_th(R_KFE) = rest_des_th(R_KFE) + 2*wave*amp;
	ret_des_th(R_AFE) = rest_des_th(R_AFE) +   wave*amp;
	
	return ret_des_th;
}

double class_mosaic_learning::simple_fb_NN_revise(CMatrix &gyro)
{
	return -(0.0*gyro(1) + 0.0*gyro(1 + 3));
}

bool class_mosaic_learning::set_state(CMatrix gyro)
{
	x = zeros(6, 1);
	x(0) = joint_state[B_TFE].th;
	x(1) = joint_state[R_AFE].th;
	x(2) = gyro(1);
	x(3) = joint_state[B_TFE].thd;
	x(4) = joint_state[R_AFE].thd;
	x(5) = gyro(1 + 3);
	
	return true;
}

// initializer
bool class_mosaic_learning::init_NN_revise(const int _max_step, const double _dt, const int _trial)
{
	max_step = _max_step;
	dt = _dt;
	trial = _trial;
	sgenrand(trial);
	
	cycle =  5;
	period = 4;
	
	// read rest state
	char fname_rest_state[256];
	if(TASK == SQUATTING){
		module_num = 3;
		sprintf(fname_rest_state, "./rest_state_squatting.dat");
	}
	else if(TASK == LIFTING){
		module_num = 2;
		sprintf(fname_rest_state, "./rest_state_lifting.dat");
	}
	rest_des_th = zeros(N_DOFS + 1, 1);
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_rest_state << "\"." << endl;
	for(int n = 1; n < N_DOFS + 1; n++){
		read_parameter(fname_rest_state, joint_names[n], &rest_des_th(n));
	}
	rest_des_th *= PI/(double)180;
	
	// read joint bias
	char fname_joint_bias[] = "./joint_bias.dat";
	CMatrix joint_bias = zeros(N_DOFS + 1, 1);
	
	cout << "========================================================" << endl;
	cout << "read \"" << fname_joint_bias << "\"." << endl;
	for(int n = 1; n < N_DOFS + 1; n++){
		read_parameter(fname_joint_bias, joint_names[n], &joint_bias(n));
	}
	rest_des_th += joint_bias*PI/(double)180;
	
	// read task setting
	char fname_task_setting[] = "./task_setting.dat";
	cout << "read \"" << fname_task_setting << "\"." << endl;
	read_parameter(fname_task_setting, "cycle", &cycle);
	read_parameter(fname_task_setting, "period", &period);
	
	//
	start_des_th = joint_des_th();
	des_th = joint_des_th();
	des_thd = zeros(N_DOFS + 1, 1);
	
	// init mosaic
	if(mos.init(module_num, 6, 2, dt) == true){
		cout << "MOSAIC is initialized!" << endl;
		module_num = mos.get_module_num();
	}
	else{
		cout << "MOSAIC initialization is failed." << endl;
		return false;
	}
	
	// trace
	trace_buff_size
		= 4 // trial, step, time, phase
		+ 6 // AFE, TFE, GYRO_PIT, D_AFE, D_TFE, D_GYRO_PIT
		+ 2 // AFE_DES, TFE_DES
		+ module_num; // RS
	trace_buff = new double[trace_buff_size*max_step];
	
	return true;
}

// trace
bool class_mosaic_learning::trace_NN_revise(const int trial, const int step, const double time)
{
	if(step >= max_step){
		cout << "# of step exceeded max_step" << endl;
		return false;
	}
	
	CMatrix lambda = mos.get_lambda();
	CMatrix perr = mos.get_pred_err();
	
	int bias = step*trace_buff_size;
	trace_buff[bias + 0] = trial;
	trace_buff[bias + 1] = step;
	trace_buff[bias + 2] = time;
	trace_buff[bias + 3] = phase;
	bias += 4;
	
	for(int n = 0; n < 6; n++) trace_buff[bias + n] = x(n);
	bias += 6;
	for(int d = 0; d < 2; d++) trace_buff[bias + d] = u(d);
	bias += 2;
	for(int m = 0; m < module_num; m++) trace_buff[bias + m] = lambda(m);
	bias += module_num;
	
	last_step = step;
	
	return true;
}

//
bool class_mosaic_learning::done_NN_revise(const int trial, const int step)
{
	return true;
}

//
bool class_mosaic_learning::save_trace_NN_revise(const int trial)
{
	char fname[256];
	sprintf(fname, "./log/%06d.dat", trial);
	FILE *pf = fopen(fname, "w");
	
	fprintf(pf, "%d %d\n", trace_buff_size, last_step);
	fprintf(pf, "%d %d\n", 6, 2);
	fprintf(pf, "%d\n", module_num);
	fprintf(pf, "%f\n", dt);
	if(fwrite(trace_buff, sizeof(double), trace_buff_size*last_step, pf) != (unsigned int)(trace_buff_size*last_step)){
		cout << "cannot fwrite matrix." << endl;
		return false;
	}
	fclose(pf);
	
	cout << "class_mosaic_learning::save_trace is done." << endl;
	cout << "trial=" << trial << ", last_step = " << last_step << ", trace_buff_size = " << trace_buff_size << endl;
	
	return true;
}

//
// controllers
//
bool class_mosaic_learning::rest_controller_NN_revise(const int trial, const int step, const double time)
{
	return rest_controller_NN_revise(trial, step, time, 0);
}

bool class_mosaic_learning::rest_controller_NN_revise(const int trial, const int step, const double time, const double phase_)
{
	CMatrix local_des_th = make_traj_NN_revise(phase_);
	
	double local_time = time;
	double d = 3;
	double td = local_time/(double)d;
	if(0 <= td && td < 1){
		des_th   = start_des_th + (local_des_th - start_des_th)*(10*pow(td, 3) -  15*pow(td, 4) +   6*pow(td, 5));
		des_thd  =                (local_des_th - start_des_th)*(30*pow(td, 2) -  60*pow(td, 3) +  30*pow(td, 4))/d;
	}
	else{
		des_th = local_des_th;
		des_thd = zeros(N_DOFS + 1, 1);
	}
	
	return true;
}

bool class_mosaic_learning::init_controller_NN_revise(const int trial, const int step, const double time, const double time_max,
													  CMatrix &gyro, CMatrix &ff)
{
	// blending ratio
	double w = time_max*0.8;
	double d = time/w;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	double alpha = -2*pow(d, 3) + 3*pow(d, 2);
	
	//
	CMatrix local_des_th = make_traj_NN_revise(0);
	des_th = alpha*local_des_th + (1 - alpha)*start_des_th;
	des_thd = zeros(N_DOFS + 1, 1);
	
	// simple fb
	des_th(L_AFE) += simple_fb_NN_revise(gyro)*alpha;
	des_th(R_AFE) += simple_fb_NN_revise(gyro)*alpha;
	
	mosaic_controller_NN_revise(trial, step, time, alpha, gyro, ff);
	
	return true;
}

bool class_mosaic_learning::finish_controller_NN_revise(const int trial, const int step, const double time, const double time_max,
														CMatrix &gyro, CMatrix &ff)
{
	// blending ratio
	double w = time_max*0.8;
	double d = 1 - time/w;
	if(d < 0) d = 0;
	if(d > 1) d = 1;
	
	double alpha = -2*pow(d, 3) + 3*pow(d, 2);
	
	//
	CMatrix local_des_th = make_traj_NN_revise(0);
	des_th = local_des_th;
	des_thd = zeros(N_DOFS + 1, 1);
	
	// simple fb
	des_th(L_AFE) += simple_fb_NN_revise(gyro)*alpha;
	des_th(R_AFE) += simple_fb_NN_revise(gyro)*alpha;
	
	mosaic_controller_NN_revise(trial, step, time, alpha, gyro, ff);
	
	if(time > time_max) return false;
	return true;
}

bool class_mosaic_learning::sampling_controller_NN_revise(const int trial, const int step, const double time, CMatrix &gyro, CMatrix &ff)
{
	//
	static int sampling_step = 0;
	static int sampling_state_index = 0;
	
	double max_time0 = 10, max_time = 50;
	int m = sampling_state_index;
	phase = m/(double)(module_num - 1)*PI;
	
	if(sampling_step == 0){
		if(m == 0) cout << endl << endl;
		cout << "m=" << m << ": sampling start" << flush;
	}
	if(sampling_step*dt < max_time0){
		rest_controller_NN_revise(trial, step, sampling_step*dt, phase);
		u = zeros(2, 1);
		u(0) += simple_fb_NN_revise(gyro);
		sampling_step++;
		if(sampling_step%(int)floor(1/dt) == 0) cout << "+" << flush;
	}
	else{
		CMatrix local_des_th = make_traj_NN_revise(phase);
		des_th = local_des_th;
		des_thd = zeros(N_DOFS + 1, 1);
		
		double dist_freq = 50.0;
		double rho = exp(-dt*dist_freq);
		static CMatrix noise = zeros(2, 1);
		noise(0) = randn()*1.0/(double)180*PI*dt + rho*noise(0);
		noise(1) = randn()*1.0/(double)180*PI*dt + rho*noise(1);
		u = noise;
		//u += -0.001*u;
		u(0) += simple_fb_NN_revise(gyro);
		
		des_th(L_AFE) += u(0);
		des_th(R_AFE) += u(0);
		des_th(B_TFE) += u(1);
		
		sampling_step++;
		if(sampling_step%(int)floor(1/dt) == 0) cout << "." << flush;
		
		if(sampling_step*dt > max_time0 + max_time){
			sampling_step = 0;
			sampling_state_index++;
			start_des_th = joint_des_th();
			noise = zeros(2, 1);
			if(sampling_step == 0) cout << "finished!" << endl;
			if(sampling_state_index >= module_num){
				sampling_state_index = 0;
				return false;
			}
		}
	}
	
	return true;
}

bool class_mosaic_learning::periodic_controller_NN_revise(const int trial, const int step, const double time, CMatrix &gyro, CMatrix &ff)
{
	double local_time = time;
	
	// make nominal trajctory of sway movement
	phase = fmod(2*PI*local_time/period, 2*PI);
	CMatrix local_des_th = make_traj_NN_revise(phase);
	
	des_th = local_des_th;
	des_thd = zeros(N_DOFS + 1, 1);
	
	// simple fb
	des_th(L_AFE) += simple_fb_NN_revise(gyro);
	des_th(R_AFE) += simple_fb_NN_revise(gyro);
	
	// mosaic
	mosaic_controller_NN_revise(trial, step, time, 1, gyro, ff);
	
	if(cycle*period < local_time) return false;
	return true;
}


bool class_mosaic_learning::mosaic_controller_NN_revise(const int trial, const int step, const double time, const double alpha,
											  CMatrix &gyro, CMatrix &ff)
{
	double local_time = time;
	
	
	//u0 = zeros(action_dim, 1);
	//for(int d = 0; d < action_dim; d++){
	//	u0(d) = des_th(action_idx[d]);
	//}
	
	//
	//CMatrix j_th = joint_th(), j_thd = joint_thd();
	//x = conv_mosaic_state(j_th, j_thd, gyro, ff);
	
	static CMatrix pre_x(6, 1), pre_u(2, 1);
	CMatrix xd(6, 1);
	
	if(step == 0){
		pre_x = x;
		pre_u = zeros(2, 1);
	}
	
	// alpha = blending ratio
	//u = alpha*mos.output(step, x, pre_u, phase);
	u = 0*mos.output(step, x, pre_u, phase);
	
	double limit = 10.0/(double)180*PI;
	for(int d = 0; d < 2; d++){
		if(u(d) < -limit) u(d) = -limit;
		if(u(d) >  limit) u(d) =  limit;
	}
	des_th(L_AFE) += u(0);
	des_th(R_AFE) += u(0);
	des_th(B_TFE) += u(1);
	
	// store
	pre_x = x;
	pre_u = u;
	
	return true;
}




