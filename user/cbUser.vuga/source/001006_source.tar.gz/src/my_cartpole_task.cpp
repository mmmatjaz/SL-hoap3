/*============================================================================
==============================================================================

                              my_cartpole_task.cpp
 
==============================================================================
Remarks:

      sekeleton to create the sample C++ task

============================================================================*/

#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_common.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
//#include "SL_shared_memory.h"
//#include "SL_man.h"
//#include "SL_user_sensor_proc_xeno.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>

#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

// local includes
#include "my_cartpole_task.h"
#include "PI2learning.h"
#include "my_utility.h"

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////
my_cartpole_task::my_cartpole_task()
{
	double tmp = servo_base_rate/(double)task_servo_ratio;
	dt_global = 1/tmp;
	per_step = 5;
	dt_learning = dt_global*per_step*task_servo_ratio;
	cout << "dt global   = " << dt_global << endl;
	cout << "dt learning = " << dt_learning << endl;
	
	is_init_pi2 = false;
	init_duration = 0.5;
	task_duration = 2;
	finish_duration = 0.5;
}

my_cartpole_task::~my_cartpole_task(){
}

///////////////////////////////////////////////////////////
//
// private functions
//
///////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////
//
// public functions
//
///////////////////////////////////////////////////////////

/////////////////////////////////////////
//
// rest
//
/////////////////////////////////////////

int my_cartpole_task::init_rest()
{
	//trial = 0;
	//step = 0;
	//step_global = 0;
	//max_trial_time = 5;
	//state_index = 0;
	
	
	if(is_init_pi2 == false){
		pi2learning.init((int)floor(task_duration/dt_learning) + 1, dt_learning, trial);
		is_init_pi2 = true;
	}
	
	scd();
	start_time = task_servo_time;
	
	return TRUE;
}

int my_cartpole_task::run_rest()
{
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	if(step_global%per_step == 0){
		// state machine
		const double time0 = 2;
		
		if(time < time0){
			pi2learning.rest_controller(step, time, time0);
		}
		else{
			cout << endl;
			cout << time << ": rest finished" << endl;
			freeze();
			stopcd();
			return FALSE;
		}
		step++;
	}
	
	// get desired: joint_desired(t)
	CMatrix j_des_th   = pi2learning.get_desired_th();
	CMatrix j_des_thd  = pi2learning.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].th   = j_des_th(i);
		joint_des_state[i].thd  = j_des_thd(i);
		joint_des_state[i].thdd = 0;
	}
	
	//
	step_global++;
	
	return TRUE;
}

int my_cartpole_task::change_rest()
{
	return TRUE;
}

/////////////////////////////////////////
//
// cartpole task
//
/////////////////////////////////////////

int my_cartpole_task::init()
{
	// read index of last data as trial
	/*
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	*/
	
	//
	step = 0;
	step_global = 0;
	state_index = 0;
	isfinished = false;
	
	if(is_init_pi2 == false){
		pi2learning.init((int)floor(task_duration/dt_learning) + 1, dt_learning, trial);
		is_init_pi2 = true;
	}
	one_shot = 0;
	
	//
	scd();
	start_time = task_servo_time;
	
	return TRUE;
}

int my_cartpole_task::run()
{
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	const bool is_use_wii_server = false;
	static double init_cart_state = 0;
	if(step_global%per_step == 0){
		stop_watch();
		CMatrix gyro = gyro_sensor_wrapper();
		//CMatrix ff = foot_force_sensor(step, time);
		
		// state machine
		const double time0 = init_duration;
		const double time1 = init_duration + task_duration;
		const double time2 = init_duration + task_duration + finish_duration;
		if(time < time0){
			if(state_index != STATE_INDEX_INIT){
				state_index = STATE_INDEX_INIT;
				printf("t=%06.3f: initial controller\n", time);
			}
			pi2learning.initial_controller(step, time, time0, gyro);
		}
		else if(time0 <= time && time < time1){
			if(state_index != STATE_INDEX_TASK){
				state_index = STATE_INDEX_TASK;
				printf("t=%06.3f: task controller\n", time);
				
				// open shared memory
				if(is_use_wii_server == true){
					if(open_shared_memory() == FALSE){
						cout << "exit task" << endl; getchar();
						freeze();
						stopcd();
						return FALSE;
					}
					p_sm->status = 1;
					//init_cart_state = cart_state[RIGHT_HAND].x[_X_];
				}
			}
			double local_time = time - time0;
			
			pi2learning.cartpole_controller(step, local_time, gyro);
			
			double cost_state;
			if(is_use_wii_server == true){
				cost_state = (double)(p_sm->cost_state);
			}
			else{
				//double vel = cart_orient[RIGHT_HAND].ad[_A_];
				//double target_vel = 0.2;
				//cost_state = pow(fabs(vel) - target_vel, 2);
				
				//double cx = cart_state[RIGHT_HAND].x[_X_];
				//double cy = cart_state[RIGHT_HAND].x[_Y_];
				//double cz = cart_state[RIGHT_HAND].x[_Z_];
				//double dist2 = pow(cx - 0.5, 2) + pow(cy - 0.5, 2) + pow(cz - 0.5, 2);
				//cost_state = dist2*1e6;
				
				CMatrix th = pi2learning.joint_th();
				CMatrix rap = right_arm_pos(th);
				cost_state = cost_function(rap);
				//FILE *pF = fopen("tmp.dat", "a");
				//fprintf(pF, "%e %e %e %e %e %e\n", cx, cy, cz, rap(0), rap(1), rap(2));
				//fclose(pF);
			}
			pi2learning.do_PI2learning(trial, step, local_time, cost_state);
			pi2learning.trace(trial, step, local_time, cost_state);
			
			if(is_use_wii_server == true){
				p_sm->step = step;
				p_sm->time = local_time;
				p_sm->cost_act = pi2learning.get_cost_act();
				p_sm->act = cart_orient[RIGHT_HAND].ad[_A_]*20;
			}
			
			step++;
		}
		else if(time1 <= time && time < time2){
			if(state_index != STATE_INDEX_FINISH){
				if(is_use_wii_server == true){
					p_sm->status = 2;
					close_shared_memory();
				}
				state_index = STATE_INDEX_FINISH;
				printf("t=%06.3f: finish controller\n", time);
			}
			pi2learning.finish_controller(step, time - time1, time2 - time1, gyro);
		}
		else{
			pi2learning.done(trial, step);
			trial++;
			
			if(one_shot < 10000){
				step = 0;
				step_global = 0;
				state_index = 0;
				isfinished = false;
				start_time = task_servo_time;
				one_shot++;
				return TRUE;
			}
			else{
				cout << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
				freeze();
				stopcd();
				one_shot = 0;
				return FALSE;
			}
		}
	}
	
	// get desired: joint_desired(t)
	CMatrix j_des_th  = pi2learning.get_desired_th();
	CMatrix j_des_thd = pi2learning.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].th   = j_des_th(i);
		joint_des_state[i].thd  = j_des_thd(i);
		joint_des_state[i].thdd = 0;
	}
	step_global++;
	
	return TRUE;
}

int my_cartpole_task::change()
{
	
	return TRUE;
}

/////////////////////////////////////////
//
// save trace
//
/////////////////////////////////////////
int my_cartpole_task::init_save(){
	// read index of last data as trial
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	
	//
	step = 0;
	//pi2learning.save_trace(trial);
	//saveData();
	
	return TRUE;
}


int my_cartpole_task::run_save(){
	freeze();
	return FALSE;
}

int my_cartpole_task::change_save()
{
	return TRUE;
}
