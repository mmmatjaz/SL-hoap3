/*!=============================================================================
  ==============================================================================

  \file    my_cartpole_task.h

  \author  Norikazu Sugimoto
  \date    Jan. 2012

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _MY_CARTPOLE_TASK_H_
#define _MY_CARTPOLE_TASK_H_

#ifndef PI
#define PI 3.14159
#endif

#include "PI2learning.h"
#include "connect_wii_server.h"

enum state_index_list{
	STATE_INDEX_REST = 0,
	STATE_INDEX_INIT,
	STATE_INDEX_TASK,
	STATE_INDEX_FINISH,
};

class my_cartpole_task{
	//
	// member variables
	//
  public:
	
  private:
	int trial, step, step_global, per_step;
	double start_time, dt_learning, dt_global, next_time;
	int state_index;
	int go_target;
	bool isfinished;
	
	//
	class_PI2learning pi2learning;
	bool is_init_pi2;
	int one_shot;
	double init_duration, task_duration, finish_duration;
	
	//
	//class_connect_wii_server ws;
	
	//
	sm_cartpole *p_sm;
	int fd_sm;
	
	//
	// member functions
	//
	
  private:
	CMatrix gyro_sensor_wrapper(void){
		CMatrix ret(6, 1);
		double tmp[6];
		gyro_sensor(tmp);
		for(int i = 0; i < 6; i++) ret(i) = tmp[i];
		return ret;
	}
	CMatrix foot_force_sensor_wrapper(int step, double time){
		CMatrix ret(4, 1);
		double tmp[4];
		foot_force_sensor(step, time, tmp);
		for(int i = 0; i < 4; i++) ret(i) = tmp[i];
		return ret;
	}
	bool open_shared_memory(void){
		fd_sm = shm_open(SHM_CARTPOLE_NAME, O_CREAT | O_RDWR, 0777);
		if(fd_sm < 0){
			cout << "unable to open " << SHM_CARTPOLE_NAME << endl;
			return FALSE;
		}
		if(ftruncate(fd_sm, sizeof(*p_sm)) < 0){
			cout << "error in ftruncate()" << endl;
			return FALSE;
		}
		
		p_sm = (sm_cartpole*)mmap(NULL, sizeof(p_sm), PROT_READ|PROT_WRITE, MAP_SHARED, fd_sm, 0);
		bzero(p_sm, sizeof(*p_sm));
		return TRUE;
	}
	bool close_shared_memory(void){
		close(fd_sm);
		return TRUE;
	}
	
  public:
	my_cartpole_task();
	~my_cartpole_task();
	
	int init_rest();
	int run_rest();
	int change_rest();
	
	int init();
	int run();
	int change();
	
	int init_save();
	int run_save();
	int change_save();
};

#endif // end of _MY_SWAY_TASK_H_


