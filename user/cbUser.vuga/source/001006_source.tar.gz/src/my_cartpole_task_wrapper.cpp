/*============================================================================
==============================================================================

                              my_cartpole_task_wrapper.cpp
 
==============================================================================
Remarks:

  sekeleton that wrappes a "my test task" written in C++

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"

// local includes
#include "my_cartpole_task.h"

extern "C" {
	// global function
	void add_my_cartpole_task_rest_cpp();
	void add_my_cartpole_task_cpp();
	void add_my_cartpole_task_save_cpp();
	
	// local functions
	static int init_my_cartpole_task_rest(void);
	static int run_my_cartpole_task_rest(void);
	static int change_my_cartpole_task_rest(void);
	
	static int init_my_cartpole_task(void);
	static int run_my_cartpole_task(void);
	static int change_my_cartpole_task(void);
	
	static int init_my_cartpole_task_save(void);
	static int run_my_cartpole_task_save(void);
	static int change_my_cartpole_task_save(void);
}


//////////////////////////////////////////////////////////////////////////////
static my_cartpole_task my_cartpole_task;
void add_my_cartpole_task_rest_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My cartpole task (rest)");
	addTask(task_name,
			init_my_cartpole_task_rest,
			run_my_cartpole_task_rest,
			change_my_cartpole_task_rest);
}

void add_my_cartpole_task_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "");
	addTask(task_name,
			init_my_cartpole_task,
			run_my_cartpole_task,
			change_my_cartpole_task);
}

void add_my_cartpole_task_save_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My cartpole task (save)");
	addTask(task_name,
			init_my_cartpole_task_save,
			run_my_cartpole_task_save,
			change_my_cartpole_task_save);
}


//
static int init_my_cartpole_task_rest(void)
{
	return my_cartpole_task.init_rest();
}
static int run_my_cartpole_task_rest(void)
{
	return my_cartpole_task.run_rest();
}
static int change_my_cartpole_task_rest(void)
{
	return my_cartpole_task.change_rest();
}


//
static int init_my_cartpole_task(void)
{
	return my_cartpole_task.init();
}
static int run_my_cartpole_task(void)
{
	return my_cartpole_task.run();
}
static int change_my_cartpole_task(void)
{
	return my_cartpole_task.change();
}


//
static int init_my_cartpole_task_save(void)
{
	return my_cartpole_task.init_save();
}
static int run_my_cartpole_task_save(void)
{
	return my_cartpole_task.run_save();
}
static int change_my_cartpole_task_save(void)
{
	return my_cartpole_task.change_save();
}
