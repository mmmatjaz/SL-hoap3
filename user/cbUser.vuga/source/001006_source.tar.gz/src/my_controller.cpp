#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"
#include "SL_motor_servo.h"

// local includes
#include "my_walk_task.h"
#include "my_utility.h"

void class_my_walk_task::initial_controller(double *xt, double *xd)
{
	detect_physical_phase();
	
	set_phase_coordination();
	
	if(ncycle < 2){
		set_coupling(0.0, 0.0, 0.0, 0.0);
	}
	else{
		set_coupling(K_c, K_c, 0.0, 0.0);
	}
	
	// phase
	double coupling_term[2*NCONTROL];
	phi[PHYS_PHASE] = zmp_phi;
	for(int i = 0; i < 2*NCONTROL; i++){
		coupling_term[i]  = 0.0;
		for(int j = 0; j < 2*NCONTROL + 1; j++){
			coupling_term[i] += K_couple[i][j]*sin(phi[j] - phi[i] + phi_diff[i][j]);
		}
		phi_dot[i] = natural_freq + coupling_term[i]; 
		
		if(phi_dot[i] < 0.0) phi_dot[i] = 0.0;
		
		phi[i] += phi_dot[i]*STEP_SIZE;
		phi[i]  = fmod(phi[i], 2*PI);
	}
	
	// cycle count
	if(nominal_phase_prev > phi[NOMINAL_PHASE] && phi[NOMINAL_PHASE] < 0.1*PI){
		ncycle++;
		cout << "CYCLE #: " << ncycle << endl;
	}
	nominal_phase_prev = phi[NOMINAL_PHASE];
	
	
	// gain settings
	double local_grf_max = 30;
	double linear_r = (foot_force_r_filt/local_grf_max);
	double linear_l = (foot_force_l_filt/local_grf_max);
	linear_r = linear_r < 0 ? 0 : linear_r > 1 ? 1 : linear_r;
	linear_l = linear_l < 0 ? 0 : linear_l > 1 ? 1 : linear_l;
	
	gain_p[R_HFE] =   hip_gain_max*linear_r +   hip_gain_bias;
	gain_p[R_KFE] =  knee_gain_max*linear_r +  knee_gain_bias;
	gain_p[R_AFE] = ankle_gain_max*linear_r + ankle_gain_bias;
	
	gain_p[L_HFE] =   hip_gain_max*linear_l +   hip_gain_bias;
	gain_p[L_KFE] =  knee_gain_max*linear_l +  knee_gain_bias;
	gain_p[L_AFE] = ankle_gain_max*linear_l + ankle_gain_bias;
	
	
	//cout << gain_p[R_HFE] << ", " << gain_p[R_KFE] << ", " << gain_p[R_AFE] << ", "
	//	 << gain_p[L_HFE] << ", " << gain_p[L_KFE] << ", " << gain_p[L_AFE] << endl;
	
	update_gains();
	
	//sdt.controller_gain_tor_p[R_HAA] = r_haa_trq_gain;
	//sdt.controller_gain_tor_p[L_HAA] = l_haa_trq_gain;
	
	// clear buffer
	for(int i = 0; i < NCONTROL; i++){
		xd[i] = joint_home_state[i].th;
		amp[i] = 0.0;
		amp[i + NCONTROL] = 0.0; // note: need?
	}
	
	// select active joint
	amp[L_HAA] = amp0[L_HAA];
	amp[R_HAA] = amp0[R_HAA];
	amp[L_AAA] = amp0[L_AAA];
	amp[R_AAA] = amp0[L_AAA];
	
	double initialize_phase = 0.5*PI;
	if(phi[NOMINAL_PHASE] < initialize_phase){
		for(int i = 0; i < NCONTROL; i++){
			xd[i] += amp[i]*min_jerk(phi[i]);
		}
	}
	else{
		for(int i = 0; i < NCONTROL; i++){
			xd[i] += amp[i]*sin(phi[i]);
		}
	}
	
	
	//high(xt, xd);
}


void class_my_walk_task::finish_controller(double *xt, double *xd)
{
	for(int i = 0; i < NCONTROL; i++){
		xd[i] = finish_xd[i];
	}
	
	// gain settings
	double local_grf_max = 30;
	double linear_r = (foot_force_r_filt/local_grf_max);
	double linear_l = (foot_force_l_filt/local_grf_max);
	linear_r = linear_r < 0 ? 0 : linear_r > 1 ? 1 : linear_r;
	linear_l = linear_l < 0 ? 0 : linear_l > 1 ? 1 : linear_l;
	
	gain_p[R_HFE] =   hip_gain_max*linear_r +   hip_gain_bias;
	gain_p[R_KFE] =  knee_gain_max*linear_r +  knee_gain_bias;
	gain_p[R_AFE] = ankle_gain_max*linear_r + ankle_gain_bias;
	
	gain_p[L_HFE] =   hip_gain_max*linear_l +   hip_gain_bias;
	gain_p[L_KFE] =  knee_gain_max*linear_l +  knee_gain_bias;
	gain_p[L_AFE] = ankle_gain_max*linear_l + ankle_gain_bias;
	
	update_gains();
	
	//sdt.controller_gain_pos_p[R_KFE] = KNEE_GAIN_MAX*linear_r + gain_bias;
	//sdt.controller_gain_pos_p[L_KFE] = KNEE_GAIN_MAX*linear_l + gain_bias;
	
	//sdt.controller_gain_pos_p[R_HFE] = HIP_GAIN_MAX*linear_r + hip_gain_bias;
	//sdt.controller_gain_pos_p[L_HFE] = HIP_GAIN_MAX*linear_l + hip_gain_bias;
	
	//sdt.controller_gain_pos_p[R_HFE] = ANKLE_GAIN_MAX*linear_r + ankle_gain_bias;
	//sdt.controller_gain_pos_p[L_HFE] = ANKLE_GAIN_MAX*linear_l + ankle_gain_bias;
	
	//sdt.controller_gain_tor_p[R_HAA] = r_haa_trq_gain;
	//sdt.controller_gain_tor_p[L_HAA] = l_haa_trq_gain;
	
	//high(xt, xd);
	
}

extern double *controller_gain_th;
extern double *controller_gain_thd;
extern double *controller_gain_int;

void class_my_walk_task::rest_controller(double *xt, double *xd)
{
	// clear buffer
	for(int i = 0; i < NCONTROL; i++){
		xd[i] = joint_home_state[i].th;
		amp[i] = 0.0;
		amp[i + NCONTROL] = 0.0; // note: need?
	}
	
	double local_grf_max = 30;
	double linear_r = (foot_force_r_filt/local_grf_max);
	double linear_l = (foot_force_l_filt/local_grf_max);
	linear_r = linear_r < 0 ? 0 : linear_r > 1 ? 1 : linear_r;
	linear_l = linear_l < 0 ? 0 : linear_l > 1 ? 1 : linear_l;
	
	gain_p[R_HFE] =   hip_gain_max*linear_r +   hip_gain_bias;
	gain_p[R_KFE] =  knee_gain_max*linear_r +  knee_gain_bias;
	gain_p[R_AFE] = ankle_gain_max*linear_r + ankle_gain_bias;
	
	gain_p[L_HFE] =   hip_gain_max*linear_l +   hip_gain_bias;
	gain_p[L_KFE] =  knee_gain_max*linear_l +  knee_gain_bias;
	gain_p[L_AFE] = ankle_gain_max*linear_l + ankle_gain_bias;
	
	update_gains();
	
	//sdt.controller_gain_tor_p[R_HAA] = r_haa_trq_gain;
	//sdt.controller_gain_tor_p[L_HAA] = l_haa_trq_gain;
	
	//high(xt, xd);
	
	
	for(int i = 0; i < 2*NCONTROL + 1; i++) phi[i] = 0.0;
}


void class_my_walk_task::stepping_controller(double *xt, double *xd)
{
	double rhip_desired = 0.0, lhip_desired = 0.0;
	
	detect_physical_phase();
	
	set_phase_coordination();
	
	set_coupling(K_c, K_c, 0.0, 0.0);
	
	phi[PHYS_PHASE] = zmp_phi;
	
	double coupling_term[2*NCONTROL];
	for(int i = 0; i < 2*NCONTROL; i++){
		coupling_term[i]  = 0.0;
		for(int j = 0; j < 2*NCONTROL + 1; j++){
			coupling_term[i] += K_couple[i][j]*sin(phi[j] - phi[i] + phi_diff[i][j]);
		}
		phi_dot[i] = natural_freq + coupling_term[i]; 
		
		if(phi_dot[i] < 0.0) phi_dot[i] = 0.0;
		
		phi[i] += phi_dot[i]*STEP_SIZE;
		phi[i]  = fmod(phi[i], 2*PI);
	}
	
	// cycle count
	if(nominal_phase_prev > phi[NOMINAL_PHASE] && phi[NOMINAL_PHASE] < 0.1*PI){
		ncycle++;
		cout << "CYCLE #: " << ncycle << endl;
	}
	nominal_phase_prev = phi[NOMINAL_PHASE];
	
	// clear buffer
	for(int i = 0; i < NCONTROL; i++){
		xd[i] = joint_home_state[i].th;
		amp[i] = 0.0;
		amp[i + NCONTROL] = 0.0; // note: need?
	}
	
	// set amplitudes of CPG
	amp[L_HAA] = amp0[L_HAA];
	amp[L_AAA] = amp0[L_AAA];
	
	amp[R_HAA] = amp0[R_HAA];
	amp[R_AAA] = amp0[R_AAA];
	
	amp[L_HFE] = amp0[L_HFE];
	amp[L_KFE] = amp0[L_KFE];
	amp[L_AFE] = amp0[L_AFE];
	
	amp[R_HFE] = -amp0[R_HFE];
	amp[R_KFE] = -amp0[R_KFE];
	amp[R_AFE] = -amp0[R_AFE];
	
	for(int i = 0; i < NCONTROL; i++) xd[i] += amp[i]*sin(phi[i]);
	
	// gain settings
	double local_grf_max = 60;
	double linear_l = (foot_force_l_filt/local_grf_max);
	double linear_r = (foot_force_r_filt/local_grf_max);
	linear_l = linear_l < 0 ? 0 : linear_l > 1 ? 1 : linear_l;
	linear_r = linear_r < 0 ? 0 : linear_r > 1 ? 1 : linear_r;
	
	gain_p[R_HFE] =   hip_gain_max*linear_r +   hip_gain_bias;
	gain_p[R_KFE] =  knee_gain_max*linear_r +  knee_gain_bias;
	gain_p[R_AFE] = ankle_gain_max*linear_r + ankle_gain_bias;
	
	gain_p[L_HFE] =   hip_gain_max*linear_l +   hip_gain_bias;
	gain_p[L_KFE] =  knee_gain_max*linear_l +  knee_gain_bias;
	gain_p[L_AFE] = ankle_gain_max*linear_l + ankle_gain_bias;
	
	update_gains();
	
	//sdt.controller_gain_pos_p[R_KFE] = KNEE_GAIN_MAX*linear_r + gain_bias;
	//sdt.controller_gain_pos_p[R_HFE] = HIP_GAIN_MAX*linear_r + hip_gain_bias;
	
	//sdt.controller_gain_pos_p[L_KFE] = KNEE_GAIN_MAX*linear_l + gain_bias;
	//sdt.controller_gain_pos_p[L_HFE] = HIP_GAIN_MAX*linear_l + hip_gain_bias;
	
	//sdt.controller_gain_pos_p[R_HFE] = ANKLE_GAIN_MAX*linear_r + ankle_gain_bias;
	//sdt.controller_gain_pos_p[L_HFE] = ANKLE_GAIN_MAX*linear_l + ankle_gain_bias;
	
	//sdt.controller_gain_tor_p[R_HAA] = r_haa_trq_gain;
	//sdt.controller_gain_tor_p[L_HAA] = l_haa_trq_gain;
	
	//sdt.controller_gain_tor_p[R_KFE] = -gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[R_HFE] = -gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[R_AFE] = -gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	
	//sdt.controller_gain_tor_p[L_KFE] = gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[L_HFE] = gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[L_AFE] = gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	
	
	//high(xt, xd);
}


void class_my_walk_task::walking_controller(double *xt, double *xd)
{
	//double l_hip_pit_d, r_hip_pit_d;
	//extern double r_frc_filt, l_frc_filt;
	//int double_support_flag = 0;
	//FILE *fp;
	//double local_time;
	//static double start_time = 0.0;
	//static int init_flag = 1;
	//  static double rhip_bias = 0.0, lhip_bias = 0.0;
	
	//static double rhip_bias_roll = 0.0, lhip_bias_roll = 0.0;
	//double rhip_desired = 0.0, lhip_desired = 0.0;
	//double rhip_roll_desired = 0.0, lhip_roll_desired = 0.0;
	
	//static double xd_average = 0.0;
	//double af=0.0, bf=0.0, cf=0.0, df=0.0;
	//static double xd_state = 0.0;
	
	//double roll_modified_angle = 0.0;
	//static double coupling_scale = 0.0;
	//extern int monkey_delay;
	
	detect_physical_phase();
	
	set_phase_coordination();
	
	// note: refine and ask morimoto-san
	//set_coupling(K_c, K_c_pit, monkey_couple_coeff*coupling_scale, 0.0);
	set_coupling(K_c, K_c_pit, 0.0, 0.0);
	
	// note: can be moved to foot_switch(void)
	int l_on, r_on;
	double grf_threshold = 5;
	if(foot_force_l_filt > grf_threshold) l_on = 1;
	else                                  l_on = 0;
	
	if(foot_force_r_filt > grf_threshold) r_on = 1;
	else                                  r_on = 0;
	
	int double_support_flag;
	if(l_on && r_on) double_support_flag = 1;
	else             double_support_flag = 0;
	
	// phase
	double coupling_term[2*NCONTROL];
	phi[PHYS_PHASE] = zmp_phi;
	for(int i = 0; i < 2*NCONTROL; i++){
		coupling_term[i]  = 0.0;
		for(int j = 0; j < 2*NCONTROL + 2; j++){ //<----check 10
			coupling_term[i] += K_couple[i][j]*sin(phi[j] - phi[i] + phi_diff[i][j]);
		}
		
		phi_dot[i] = natural_freq + coupling_term[i]; 
		
		if(phi_dot[i] < 0.0) phi_dot[i] = 0.0;
		
		if(i < NCONTROL || !double_support_flag){
			phi[i] += phi_dot[i]*STEP_SIZE;
		}
		
		if(i >= NCONTROL){
			//internal force occering
			//RIGHT STANCE --> LEFT STANCE  right foot going to lift
			if(stance_index == LEFT_STANCE && !r_on && !r_off_flag && phi[i] < 0.5*PI){
				phi[i] = (0.5*PI - phi[i]) + 0.5*PI;
			}
			if(stance_index == RIGHT_STANCE && !l_on && !l_off_flag && phi[i] < 1.5*PI){
				phi[i] = (1.5*PI - phi[i]) + 1.5*PI;
			}
		}
		
		phi[i] = fmod(phi[i], 2*PI);
	}
	
	if(stance_index == LEFT_STANCE && !r_on  && !r_off_flag) r_off_flag = 1;
	if(stance_index == RIGHT_STANCE && !l_on && !l_off_flag) l_off_flag = 1;
	
	// cycle count
	if(nominal_phase_prev > phi[NOMINAL_PHASE] && phi[NOMINAL_PHASE] < 0.1*PI){
		ncycle++;
		cout << "CYCLE #: " << ncycle << endl;
	}
	nominal_phase_prev = phi[NOMINAL_PHASE];
	
	// clear buffer
	for(int i = 0; i < NCONTROL; i++){
		xd[i] = joint_home_state[i].th;
		amp[i] = 0.0;
		amp[i + NCONTROL] = 0.0;
	}
	
	// control scale of amplitude
	if(amp_scale < 1.0 && amp_scale_index == 0)
		amp_scale += (1.0/amp_scale_time)*STEP_SIZE;
	else
		amp_scale_index = 1;
	
	if(amp_scale_index == 1 && ncycle > (max_cycle - 3)){
		if(amp_scale > 0.0)
			amp_scale -= (1.0/amp_scale_time)*STEP_SIZE;
		else
			amp_scale = 0.0;
	}
	
	// ampliture of stepping
	amp[L_HAA] = amp0[L_HAA];
	amp[L_AAA] = amp0[L_AAA];
	
	amp[R_HAA] = amp0[R_HAA];
	amp[R_AAA] = amp0[R_AAA];
	
	amp[B_TAA] = amp0[B_TAA];
	
	amp[L_HFE] = amp0[L_HFE];
	amp[L_KFE] = amp0[L_KFE];
	amp[L_AFE] = amp0[L_AFE];
	
	amp[R_HFE] = -amp0[R_HFE];
	amp[R_KFE] = -amp0[R_KFE];
	amp[R_AFE] = -amp0[R_AFE];
	
	// ampliture of going forward
	amp[L_SFE + NCONTROL] = amp0[L_SFE]*amp_scale;
	amp[R_SFE + NCONTROL] = amp0[R_SFE]*amp_scale;
	
	amp[L_EB + NCONTROL] =  amp0[L_SFE]*amp_scale;
	amp[R_EB + NCONTROL] = -amp0[R_SFE]*amp_scale;
	
	// ampliture of turn motion
	//amp[L_TR + NCONTROL] = amp_scale_stat*amp_turn; //*sin(2*M_PI*(1.0/6.0)*walk_local_count*0.002);
	//amp[R_TR + NCONTROL] =-amp_scale_stat*amp_turn; //*sin(2*M_PI*(1.0/6.0)*walk_local_count*0.002);
	//amp[L_AR + NCONTROL] = amp_scale_stat*amp_turn; //*sin(2*M_PI*(1.0/6.0)*walk_local_count*0.002);
	//amp[R_AR + NCONTROL] =-amp_scale_stat*amp_turn; //*sin(2*M_PI*(1.0/6.0)*walk_local_count*0.002);
	
	// upper limb control
	amp[B_TR + NCONTROL]  = amp0[B_TR];
	
	// forward leg movement
	xd[B_TFE] += amp_scale*torso_bend;
	xd[L_AFE] -= amp_scale*ankle_bend;
	xd[R_AFE] -= amp_scale*ankle_bend;
	
	//
	amp[L_HFE + NCONTROL] = amp_l_add_hip*amp_scale;
	amp[R_HFE + NCONTROL] = amp_r_add_hip*amp_scale;
	
	amp[L_AFE + NCONTROL] = 0.5*amp_l_add_ankle*amp_scale;
	amp[R_AFE + NCONTROL] = 0.5*amp_r_add_ankle*amp_scale;
	
	
	// position gain settings
	double local_grf_max = 60;
	double linear_r = (foot_force_r_filt/local_grf_max);
	double linear_l = (foot_force_l_filt/local_grf_max);
	linear_r = linear_r < 0 ? 0 : linear_r > 1 ? 1 : linear_r;
	linear_l = linear_l < 0 ? 0 : linear_l > 1 ? 1 : linear_l;
	
	gain_p[R_HFE] =   hip_gain_max*linear_r +   hip_gain_bias;
	gain_p[R_KFE] =  knee_gain_max*linear_r +  knee_gain_bias;
	gain_p[R_AFE] = ankle_gain_max*linear_r + ankle_gain_bias;
	
	gain_p[L_HFE] =   hip_gain_max*linear_l +   hip_gain_bias;
	gain_p[L_KFE] =  knee_gain_max*linear_l +  knee_gain_bias;
	gain_p[L_AFE] = ankle_gain_max*linear_l + ankle_gain_bias;
	
	update_gains();
	
	//sdt.controller_gain_pos_p[R_HFE] =   HIP_GAIN_MAX*linear_r + hip_gain_bias;
	//sdt.controller_gain_pos_p[R_KFE] =  KNEE_GAIN_MAX*linear_r + gain_bias;
	//sdt.controller_gain_pos_p[R_AFE] = ANKLE_GAIN_MAX*linear_r + ankle_gain_bias;
	
	//sdt.controller_gain_pos_p[L_HFE] =   HIP_GAIN_MAX*linear_l + hip_gain_bias;
	//sdt.controller_gain_pos_p[L_KFE] =  KNEE_GAIN_MAX*linear_l + gain_bias;
	//sdt.controller_gain_pos_p[L_AFE] = ANKLE_GAIN_MAX*linear_l + ankle_gain_bias;
	
	//sdt.controller_gain_tor_p[R_HAA] = r_haa_trq_gain;
	//sdt.controller_gain_tor_p[L_HAA] = l_haa_trq_gain;
	
	// torque gain settings
	//sdt.controller_gain_tor_p[R_KFE] = -gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[R_HFE] = -gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[R_AFE] = -gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	
	//sdt.controller_gain_tor_p[L_KFE] = gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[L_HFE] = gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	//sdt.controller_gain_tor_p[L_AFE] = gain_tor_scale*sin(phi[NOMINAL_PHASE]) + gain_tor_bias;
	
	//
	for(int i = 0; i < NCONTROL; i++){
		xd[i] += amp[i]*sin(phi[i]);
		xd[i] += amp[i + NCONTROL]*sin(phi[i + NCONTROL]);
	}
	
	// store final desired
	for(int i = 0; i < NCONTROL; i++){
		finish_xd[i] = xd[i];
	}
	
	//high(xt, xd);
}
