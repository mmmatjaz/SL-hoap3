/*============================================================================
==============================================================================

                              my_controller_misc.cpp

==============================================================================
Remarks:



============================================================================*/

#include <iostream>
#include <iomanip>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_common.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"

// local includes
#include "my_walk_task.h"
#include "my_utility.h"

void class_my_walk_task::init_parameter(void)
{
	//nominal_phase_prev = 0.0;
	for(int i = 0; i < 2*NCONTROL + 2; i++) phi[i]     = 0.0;
	for(int i = 0; i < 2*NCONTROL;     i++) phi_dot[i] = 0.0;
	
	cop_xdot_filt = 0.0;
	cop_x_d       = 0.0;
	cop_x_filt    = 0.0;
	
	//lhip_bias = 0.0;
	//rhip_bias = 0.0;
	
	//walk_local_count = 0;
	
	// reset index of state machine
	state_machine_index = REST_CONTROLLER;
	
	// reset phase information
	ncycle             = 0;
	max_cycle          = 8;
	zmp_phi            = 0.0;
	nominal_phase_diff = 0.7*PI;
	monkey_phase_diff  = 0.0;
	natural_freq       = 2*PI;
	nominal_phase_prev = 0.0;
	
	// CPG specific parameters
	amp_scale_index = 0;
	amp_scale       = 0;
	amp_scale_time  = 3.0;
	K_c             = 7.0;
	K_c_pit         = 0.0;
	torso_bend      = 0;
	ankle_bend      = 0;
	amp_l_add_hip   = 0;
	amp_r_add_hip   = 0;
	amp_l_add_ankle = 0;
	amp_r_add_ankle = 0;
	for(int i = 0; i < NCONTROL; i++){
		amp0[i] = 0;
		amp[i] = 0;
		amp[i + NCONTROL] = 0;
	}
	amp0[L_HFE] =  -5/(double)180*PI;
	amp0[L_KFE] = -10/(double)180*PI;
	amp0[L_AFE] =  -5/(double)180*PI;
	amp0[R_HFE] =   5/(double)180*PI;
	amp0[R_KFE] =  10/(double)180*PI;
	amp0[R_AFE] =   5/(double)180*PI;
	
	// reset foot state
	stance_index      = RIGHT_STANCE;
	foot_force_l_filt = 0.0;
	foot_force_r_filt = 0.0;
	foot_force_l_filt_prev = 0.0;
	foot_force_r_filt_prev = 0.0;
	
	// read default gains
	read_gains("Gains.cf", gain_p, gain_d, gain_i);
	
	// set gain
	hip_gain_max   = 200;
	knee_gain_max  = 120;
	ankle_gain_max = 100;
	
	hip_gain_bias   = 200;
	knee_gain_bias  = 400;
	ankle_gain_bias = 400;
	
	read_parameters_wrapper();
}

int class_my_walk_task::foot_switch(void)
{
	int f_switch = 0;
	
	double grf_threshold = 10;
	if(foot_force_l_filt > grf_threshold &&
	   foot_force_l_filt_prev <= grf_threshold && stance_index == RIGHT_STANCE){
		f_switch = 1;
		stance_index = LEFT_STANCE;
		l_off_flag = 0;
	}
	else if(foot_force_r_filt > grf_threshold &&
			foot_force_r_filt_prev <= grf_threshold && stance_index == LEFT_STANCE){
		f_switch = 1;
		stance_index = RIGHT_STANCE;
		r_off_flag = 0;
	}
	
	foot_force_l_filt_prev = foot_force_l_filt;
	foot_force_r_filt_prev = foot_force_r_filt;
	
	return f_switch;
}

void class_my_walk_task::detect_physical_phase(void)
{
	double sum_force, cop_x, cop_xdot;
	double zmp[4];
	const double link_pos_L_estim = -1.0, link_pos_R_estim = 1.0;
	
	sum_force = foot_force_r_filt + foot_force_l_filt;
	if(sum_force > 0.0){
		cop_x = (link_pos_L_estim*foot_force_l_filt
				 + link_pos_R_estim*foot_force_r_filt)/sum_force;
	}
	else{
		cop_x = 0.0;
	}
	
	// note: cop_x_d can be deleted?
	cop_x_filt = 0.95*cop_x_filt + 0.05*cop_x;
	cop_xdot   = (cop_x_filt - cop_x_d)/STEP_SIZE;
	cop_x_d    = cop_x_filt;
	
	cop_xdot_filt = 0.95*cop_xdot_filt + 0.05*cop_xdot;
	zmp_phi = fmod(-atan2(cop_xdot_filt, cop_x_filt) + PI, 2*PI);
	
	zmp_phi = fmod(local_time, 2*PI);
}

void class_my_walk_task::set_phase_coordination(void)
{
	for(int i = 0; i < NCONTROL; i++){
		for(int j = 0; j < 2*NCONTROL + 2; j++){
			if(j == PHYS_PHASE)        phi_diff[i][j] = nominal_phase_diff;
			else if(j == MONKEY_PHASE) phi_diff[i][j] = monkey_phase_diff;
			else                       phi_diff[i][j] = 0.0;
		}
	}
	
	
	for(int i = NCONTROL; i < 2*NCONTROL; i++){
		for(int j = 0; j < 2*NCONTROL + 2; j++){
			if(j == PHYS_PHASE)        phi_diff[i][j] = nominal_phase_diff + 0.5*M_PI;
			else if(j == MONKEY_PHASE) phi_diff[i][j] = monkey_phase_diff;
			else                       phi_diff[i][j] = 0.0;
		}
	}
}

void class_my_walk_task::set_coupling(double K_s, double K_w, double K_sm, double K_wm)
{
	for(int i = 0; i < NCONTROL; i++){
		for(int j = 0; j < 2*NCONTROL + 2; j++){
			if(j == PHYS_PHASE)        K_couple[i][j] = K_s;
			else if(j == MONKEY_PHASE) K_couple[i][j] = K_sm;
			else                       K_couple[i][j] = 0.0;
		}
	}
	
	for(int i = NCONTROL; i < 2*NCONTROL; i++){
		for(int j = 0; j < 2*NCONTROL + 2; j++){
			if(j == PHYS_PHASE)        K_couple[i][j] = K_w;
			else if(j == MONKEY_PHASE) K_couple[i][j] = K_wm;
			else                       K_couple[i][j] = 0.0;
		}
	}
}


double class_my_walk_task::min_jerk(double phase)
{
	double t[6], tf[6];
	double x_des;
	double phase_term;
	double pos[2] = {0.0, 1.0}, vel[2] = {0.0, 0.0}, acc[2] = {0.0, -1.0};
	
	phase_term = 0.5*PI;
	
	t[0] = 1.0;
	tf[0] = 1.0;
	for(int i = 0; i < 5; i++){
		t[i + 1]  = phase*t[i];
		tf[i + 1] = phase_term*tf[i];
	}
	
	x_des = pos[0] + vel[0]*t[1] + acc[0]*t[2]
		+ t[3]*((-10./tf[3])*pos[0] -(6./tf[2])*vel[0]
				- (3./tf[1])*acc[0] + (10./tf[3])*pos[1]
				- (4./tf[2])*vel[1] + (0.5/tf[1])*acc[1])
		+ t[4]*(( 15./tf[4])*pos[0] + (8./tf[3])*vel[0]
				+ (3./tf[2])*acc[0] - (15./tf[4])*pos[1]
				+ (7./tf[3])*vel[1] - (1.0/tf[2])*acc[1])
		+ t[5]*(( -6./tf[5])*pos[0] - (3./tf[4])*vel[0]
				- (1./tf[3])*acc[0] + (6./tf[5])*pos[1]
				- (3./tf[4])*vel[1] + (0.5/tf[3])*acc[1]);
	
	return x_des;
}

int class_my_walk_task::update_gains(void)
{
	// note: limiter should be required
	
	// send local gain settings to SL_task_servo
	//changePIDGains(gain_p, gain_d, gain_i);
	
	return TRUE;
}

int class_my_walk_task::translate_misc_sensor_to_local_variable(void)
{
	// gyro data
	SL_quat q;
	double *gyro_pos = my_vector(1, 4);
	double *gyro_vel = my_vector(1, 4);
	//Vector gyro_pos = my_vector(1, 4);
	//Vector gyro_vel = my_vector(1, 4);
	q.q[_Q0_] = misc_sensor[B_Q0_IMU];
	q.q[_Q1_] = misc_sensor[B_Q1_IMU];
	q.q[_Q2_] = misc_sensor[B_Q2_IMU];
	q.q[_Q3_] = misc_sensor[B_Q3_IMU];
	
	quatToEuler(&q, gyro_pos); // gyro_pos[1]: pitch, gyro_pos[2]: roll, gyro_pos[3]: yaw
	gyro_vel[1] = misc_sensor[B_AD_A_IMU]; // pitch
	gyro_vel[2] = misc_sensor[B_AD_B_IMU]; // roll
	gyro_vel[3] = misc_sensor[B_AD_G_IMU]; // yaw
	
	gyro[ROL] = gyro_pos[2];
	gyro[PIT] = gyro_pos[1];
	gyro[YAW] = gyro_pos[3];
	
	gyro_vel[ROL] = gyro_vel[2];
	gyro_vel[PIT] = gyro_vel[1];
	gyro_vel[YAW] = gyro_vel[3];
	
	// foot force sensor
	foot_force_l_filt = misc_sensor[L_CFz];
	foot_force_r_filt = misc_sensor[R_CFz];
	
	foot_force_l_filt_prev = foot_force_l_filt;
	foot_force_r_filt_prev = foot_force_r_filt;
	
	//cout << foot_force_l_filt << ", " << foot_force_r_filt << endl;
	
	return TRUE;
}

int class_my_walk_task::read_parameters_wrapper(void)
{
	cout << "class_my_walk_task::read_parameters_wrapper(void)" << endl;
	
	read_parameters(&max_cycle, "max_cycle");
	read_parameters(&natural_freq, "natural_freq");
	read_parameters(&K_c, "K_c");
	read_parameters(&K_c_pit, "K_c_pit");
	read_parameters(&torso_bend, "torso_bend");
	read_parameters(&ankle_bend, "ankle_bend");
	
	read_parameters(&amp_l_add_hip, "amp_l_add_hip");
	read_parameters(&amp_l_add_ankle, "amp_l_add_ankle");
	amp_r_add_hip = -amp_l_add_hip;
	amp_r_add_ankle = -amp_l_add_ankle;
	
	read_parameters((double *)&amp0[L_HAA], "AMP_HAA");
	read_parameters((double *)&amp0[L_AAA], "AMP_AAA");
	amp0[R_HAA] = -amp0[L_HAA];
	amp0[R_AAA] = -amp0[L_AAA];
	read_parameters((double *)&amp0[L_HFE], "AMP_HFE");
	read_parameters((double *)&amp0[L_KFE], "AMP_KFE");
	read_parameters((double *)&amp0[L_AFE], "AMP_AFE");
	amp0[R_HFE] = amp0[L_HFE];
	amp0[R_KFE] = amp0[L_KFE];
	amp0[R_AFE] = amp0[L_AFE];
	for(int i = 0; i < N_DOFS + 1; i++) amp0[i] *= PI/(double)180;
	
	read_parameters(&hip_gain_bias, "hip_gain_bias");
	read_parameters(&knee_gain_bias, "knee_gain_bias");
	read_parameters(&ankle_gain_bias, "ankle_gain_bias");
	
	return TRUE;
}

int class_my_walk_task::read_parameters(int *var, char *name)
{
	char fname[] = "cpg_params_walk.dat";
	FILE *pf = fopen(fname, "r");
	if(pf == NULL){
		cout << "ERROR: Cannot open file >" << fname << "<!" << endl;
		return FALSE;
	}
	
	if(find_keyword(pf, name) == FALSE){
		cout << "ERROR: Cannot find parameter for >" << name << "<!" << endl;
		fclose(pf);
		return FALSE;
	}
	else{
		fscanf(pf, "%d", var);
		
	}
	fclose(pf);
	
	cout << setw(16) << name << ": " << setw(16) << *var << endl;
	
	return TRUE;
}

int class_my_walk_task::read_parameters(double *var, char *name)
{
	char fname[] = "cpg_params_walk.dat";
	FILE *pf = fopen(fname, "r");
	if(pf == NULL){
		cout << "ERROR: Cannot open file >" << fname << "<!" << endl;
		return FALSE;
	}
	
	if(find_keyword(pf, name) == FALSE){
		cout << "ERROR: Cannot find parameter for >" << name << "<!" << endl;
		fclose(pf);
		return FALSE;
	}
	else{
		fscanf(pf, "%lf", var);
		
	}
	fclose(pf);
	
	cout << setw(16) << name << ": " << setw(16) << *var << endl;
	
	return TRUE;
}


