/*============================================================================
==============================================================================

                              my_go0_task.cpp
 
==============================================================================
Remarks:

      sekeleton to create the sample C++ task

============================================================================*/

#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"

// local includes
#include "my_go0_task.h"
#include "my_utility.h"

my_go0_task::my_go0_task(){
	WALKING_TASK = 0;
	SQUATTING_TASK = 1;
}

my_go0_task::~my_go0_task(){
}


//
// public functions
//
int my_go0_task::init_my_go0_walk_task(){
	cout << "This is Initializemy_go0_walk_task()" << endl;
	go0_index = WALKING_TASK;
	load_home_state("init_posture_walk.dat", N_DOFS, joint_home_state);
	return init();
}

int my_go0_task::init_my_go0_squat_task(){
	cout << "This is Initializemy_go0_squat_task()" << endl;
	go0_index = SQUATTING_TASK;
	load_home_state("init_posture_squat.dat", N_DOFS, joint_home_state);
	return init();
}

int my_go0_task::run_my_go0_walk_task(){
	return run();
}

int my_go0_task::run_my_go0_squat_task(){
	return run();
}

int my_go0_task::change_my_go0_walk_task(){
	return change();
}

int my_go0_task::change_my_go0_squat_task(){
	return change();
}

//
// private functions
//

int my_go0_task::init(){
	//
	for(int i = 1; i <= N_DOFS; i++){
		joint_start_state[i].th = joint_state[i].th;
	}
	
	//
	start_time = task_servo_time;
	
	
	return TRUE;
}

int my_go0_task::run(){
	double time = task_servo_time - start_time;
	double period = 5.0;
	
	double t, dx, c, cd, dv, cdd, da, change;
	
	t = time/period;
	t = t < 0 ? 0 : t;
	t = t > 1 ? 1 : t;
	
	c   = -15 * pow(t, 4) + 6 * pow(t, 5) + 10 * pow(t, 3);
	cd  = (-60 * pow(t, 3) + 30 * (pow(t, 4) + pow(t, 2))) / period;
	cdd = (-180 * pow(t, 2) + 120 * pow(t, 3) + 60 * t) / pow(period, 2);
	for(int i = 1; i < N_DOFS + 1; i++){
		change = (joint_home_state[i].th - joint_start_state[i].th);
		dx = c*change;
		dv = cd*change;
		da = cdd*change;
		joint_des_state[i].th = joint_start_state[i].th + dx;
		joint_des_state[i].thd = dv;
		joint_des_state[i].thdd = da;
		//inv_dyn_joint_state[i].th = joint_des_state[i].th;
		//inv_dyn_joint_state[i].thd = joint_des_state[i].thd;
		//inv_dyn_joint_state[i].thdd = joint_des_state[i].thdd;
	}
	
	if(time > period){
		setTaskByName(NO_TASK);
		cout << "My go0 task is finished!" << endl;
	}
	
	return TRUE;
}

int my_go0_task::change(){
	return TRUE;
}

