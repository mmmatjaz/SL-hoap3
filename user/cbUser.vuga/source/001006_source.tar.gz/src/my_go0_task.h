/*!=============================================================================
  ==============================================================================

  \file    my_go0_task.h

  \author  Norikazu Sugimoto
  \date    Jan. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef MY_GO0_TASK_H_
#define MY_GO0_TASK_H_

#ifndef PI
#define PI 3.14159
#endif

class my_go0_task{
	//
	// member functions
	//
  public:
	my_go0_task();
	~my_go0_task();
	
	int init_my_go0_walk_task();
	int init_my_go0_squat_task();
	
	int run_my_go0_walk_task();
	int run_my_go0_squat_task();
	
	int change_my_go0_walk_task();
	int change_my_go0_squat_task();
	
  private:
	int init();
	int run();
	int change();
	
	//
	// member variables
	//
  public:
	
  private:
	int WALKING_TASK, SQUATTING_TASK;
	int go0_index;
	
	double start_time;
	SL_DJstate joint_start_state[N_DOFS + 1];
	SL_DJstate joint_home_state[N_DOFS + 1];
};

#endif //MY_GO0_TASK_H_


