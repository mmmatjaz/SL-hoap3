/*============================================================================
==============================================================================

                              my_go0_task_wrapper.cpp
 
==============================================================================
Remarks:

  sekeleton that wrappes a "my test task" written in C++

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"

// local includes
#include "my_go0_task.h"

extern "C" {
	// global function
	void add_my_go0_task_cpp();
	
	// local functions
	static int init_my_go0_walk_task(void);
	static int run_my_go0_walk_task(void);
	static int change_my_go0_walk_task(void);
	
	static int init_my_go0_squat_task(void);
	static int run_my_go0_squat_task(void);
	static int change_my_go0_squat_task(void);
}


//////////////////////////////////////////////////////////////////////////////
static my_go0_task my_go0_task;
void add_my_go0_task_cpp(void)
{
	char task_name[200];
	strcpy(task_name, "My go0 task (walk)");
	addTask(task_name,
			init_my_go0_walk_task,
			run_my_go0_walk_task,
			change_my_go0_walk_task);
	
	strcpy(task_name, "My go0 task (squat)");
	addTask(task_name,
			init_my_go0_squat_task,
			run_my_go0_squat_task,
			change_my_go0_squat_task);
}

//
static int init_my_go0_walk_task(void)
{
	return my_go0_task.init_my_go0_walk_task();
}
static int run_my_go0_walk_task(void)
{
	return my_go0_task.run_my_go0_walk_task();
}
static int change_my_go0_walk_task(void)
{
	return my_go0_task.change_my_go0_walk_task();
}

//
static int init_my_go0_squat_task(void)
{
	return my_go0_task.init_my_go0_squat_task();
}
static int run_my_go0_squat_task(void)
{
	return my_go0_task.run_my_go0_squat_task();
}
static int change_my_go0_squat_task(void)
{
	return my_go0_task.change_my_go0_squat_task();
}
