/*============================================================================
==============================================================================

                           my_left_eye_pan_test.cpp
 
==============================================================================
Remarks:

      sekeleton to create the sample C++ task

============================================================================*/

#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_common.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"

// local includes
#include "my_left_eye_pan_test.h"

///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////
my_left_eye_pan_test::my_left_eye_pan_test()
{
}

my_left_eye_pan_test::~my_left_eye_pan_test()
{
}


///////////////////////////////////////////////////////////
//
// public functions
//
///////////////////////////////////////////////////////////

int my_left_eye_pan_test::init(void)
{
	start_time = task_servo_time;
	return TRUE;
}

int my_left_eye_pan_test::run(void)
{
	time = task_servo_time - start_time;
	
	// eye movement
	double phase = 2*PI*time/(double)2;
	joint_des_state[L_EP].th = cos(phase)*20*PI/(double)180;
	joint_des_state[L_ET].th = sin(phase)*20*PI/(double)180;
	
	joint_des_state[R_EP].th = cos(phase)*20*PI/(double)180;
	joint_des_state[R_ET].th = sin(phase)*20*PI/(double)180;
	
	return TRUE;
}

int my_left_eye_pan_test::change(void)
{
	return TRUE;
}
