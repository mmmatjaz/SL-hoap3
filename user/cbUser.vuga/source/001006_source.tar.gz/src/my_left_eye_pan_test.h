/*!=============================================================================
  ==============================================================================

  \file    my_left_eye_pan_test.h

  \author  Norikazu Sugimoto
  \date    Dec. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _MY_LEFT_EYE_PAN_TEST_H_
#define _MY_LEFT_EYE_PAN_TEST_H_

#ifndef PI
#define PI 3.14159
#endif

class my_left_eye_pan_test{
	//
	// member variables
	//
  private:
	double time, start_time;
	
  public:
	
	
	//
	// constructor & destructor
	//
  public:
	my_left_eye_pan_test();
	~my_left_eye_pan_test();
	
	//
	// member functions
	//
  private:
	
  public:
	int init(void);
	int run(void);
	int change(void);
	
};

#endif // end of _MY_LEFT_EYE_PAN_TEST_H_


