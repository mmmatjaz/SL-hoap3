/*============================================================================
==============================================================================

                         my_left_eye_pan_test_wrapper.cpp
 
==============================================================================
Remarks:

  sekeleton that wrappes a "my test task" written in C++

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"

// local includes
#include "my_left_eye_pan_test.h"

extern "C" {
	// global function
	void add_my_left_eye_pan_test_cpp();
	
	// local functions
	static int init_my_left_eye_pan_test(void);
	static int run_my_left_eye_pan_test(void);
	static int change_my_left_eye_pan_test(void);
}


//////////////////////////////////////////////////////////////////////////////
static my_left_eye_pan_test my_left_eye_pan_test;
void add_my_left_eye_pan_test_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My left eye pan test");
	addTask(task_name,
			init_my_left_eye_pan_test,
			run_my_left_eye_pan_test,
			change_my_left_eye_pan_test);
}

//
static int init_my_left_eye_pan_test(void)
{
	return my_left_eye_pan_test.init();
}
static int run_my_left_eye_pan_test(void)
{
	return my_left_eye_pan_test.run();
}
static int change_my_left_eye_pan_test(void)
{
	return my_left_eye_pan_test.change();
}
