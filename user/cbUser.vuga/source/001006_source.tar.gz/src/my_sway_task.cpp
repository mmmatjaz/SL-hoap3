/*============================================================================
==============================================================================

                              my_sway_task.cpp
 
==============================================================================
Remarks:

      sekeleton to create the sample C++ task

============================================================================*/

#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_common.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
//#include "SL_shared_memory.h"
//#include "SL_man.h"
//#include "SL_user_sensor_proc_xeno.h"

// local includes
#include "my_sway_task.h"
#include "mosaic_learning.h"
#include "my_utility.h"

///////////////////////////////////////////////////////////
//
// 
//
///////////////////////////////////////////////////////////
double gyro_roll, gyro_pitch;
void add_var(void)
{
	addVarToCollect((char *)&gyro_roll, "gyro_roll", "rad", DOUBLE, 1);
	updateDataCollectScript();
}


///////////////////////////////////////////////////////////
//
// constructor & destructor
//
///////////////////////////////////////////////////////////
my_sway_task::my_sway_task()
{
	double tmp = servo_base_rate/(double)task_servo_ratio;
	dt_global = 1/tmp;
	per_step = 5;
	dt_learning = dt_global*per_step*task_servo_ratio;
	cout << "dt global   = " << dt_global << endl;
	cout << "dt learning = " << dt_learning << endl;
}

my_sway_task::~my_sway_task(){
}

///////////////////////////////////////////////////////////
//
// private functions
//
///////////////////////////////////////////////////////////
/*
CMatrix my_sway_task::gyro_sensor(){
	SL_quat quat;
	double *gyro_pos = my_vector(1, 4);
	double *gyro_vel = my_vector(1, 4);
	//Vector gyro_pos = my_vector(1, 4);
	//Vector gyro_vel = my_vector(1, 4);
	quat.q[_Q0_] = misc_sensor[B_Q0_IMU];
	quat.q[_Q1_] = misc_sensor[B_Q1_IMU];
	quat.q[_Q2_] = misc_sensor[B_Q2_IMU];
	quat.q[_Q3_] = misc_sensor[B_Q3_IMU];
	quatToEuler(&quat, gyro_pos); // gyro_pos[1]: pitch, gyro_pos[2]: roll, gyro_pos[3]: yaw
	
	CMatrix q(6, 1);
	q(3) =  misc_sensor[B_AD_B_IMU]; // roll
	q(4) =  misc_sensor[B_AD_A_IMU]; // pitch
	q(5) = -misc_sensor[B_AD_G_IMU]; // yaw
	
	q(0) = -gyro_pos[2];
	q(1) = -gyro_pos[1];
	q(2) =  gyro_pos[3];
	
	//FILE *pf = fopen("g.dat", "a");
	//fprintf(pf, "%10.4f %10.4f %10.4f %10.4f %10.4f %10.4f\n",
	//		q(0)*180/3.14, q(1)*180/3.14, q(2)*180/3.14,
	//		q(3)*180/3.14, q(4)*180/3.14, q(5)*180/3.14);
	//fclose(pf);
	
	// q(0): roll,  lean to right is +
	// q(1): pitch, lean to front is +
	// q(2): yaw,   turn to left  is +
	// q(3): roll vel
	// q(4): pitch vel
	// q(5): yaw vel
	
	return q;
}

CMatrix my_sway_task::foot_force_sensor(int step, double time)
{
	CMatrix ret(4, 1);
	
	//printf("%10.4f %10.4f %10.4f | %10.4f %10.4f %10.4f\n",
	//	   misc_sensor[L_CFx], misc_sensor[L_CFy], misc_sensor[L_CFz],
	//	   misc_sensor[L_CTa], misc_sensor[L_CTb], misc_sensor[L_CTg]);
	//printf("%10.4f %10.4f %10.4f\n", misc_sensor[R_CFz], misc_sensor[R_CFy], misc_sensor[R_CFz]);
	
	static double pre_time = 0, pre_0 = 0, pre_1 = 0;
	if(step == 0){
		pre_time = 0;
		pre_0 = 0;
		pre_1 = 0;
	}
	
	ret(0) = -misc_sensor[L_CFx] - 36;
	ret(1) = -misc_sensor[R_CFx];
	
	double dt = (time - pre_time);
	if(dt < 1e-6 || step < 10){
		ret(2) = 0;
		ret(3) = 0;
	}
	else{
		ret(2) = (ret(0) - pre_0)/(time - pre_time);
		ret(3) = (ret(1) - pre_1)/(time - pre_time);
	}
	
	// store
	pre_time = time;
	pre_0 = ret(0);
	pre_1 = ret(1);
	
	return ret;
}
*/

///////////////////////////////////////////////////////////
//
// public functions
//
///////////////////////////////////////////////////////////

/////////////////////////////////////////
//
// go0
//
/////////////////////////////////////////

/*
int my_sway_task::init_go0(){
	
	//
	trial = 0;
	step = 0;
	step_global = 0;
	max_trial_time = 5;
	state_index = 0;
	ml.init((int)floor(max_trial_time/dt_learning) + 1, dt_learning, trial);
	
	scd();
	start_time = task_servo_time;
	
	return TRUE;
}

int my_sway_task::run_go0(){
	const double time = task_servo_time - start_time;
	
	// User controller
	if(step_global%per_step == 0){
		// state machine
		if(time < 1.5){
			CMatrix gyro = gyro_sensor();
			CMatrix ff = foot_force_sensor(step, time);
			
			stop_watch();
			bool isfirst = false;
			if(state_index == 0){
				cout << time << ": init_controller" << endl;
				isfirst = true;
				state_index++;
			}
			ml.init_controller(trial, step, time);
		}
		else{
			cout << endl;
			cout << time << ": go0 finished" << endl;
			freeze();
			stopcd();
			return FALSE;
		}
		
		step++;
	}
	
	// get desired: joint_desired(t)
	CMatrix rest_des_th = ml.get_rest_des_th();
	CMatrix j_des_th   = ml.get_desired_th();
	CMatrix j_des_thd  = ml.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].thdd = 0;
		joint_des_state[i].thd  = j_des_thd(i);
		joint_des_state[i].th   = j_des_th(i);
	}
	
	//
	step_global++;
	
	return TRUE;
}

int my_sway_task::change_go0()
{
	return TRUE;
}
*/

/////////////////////////////////////////
//
// go0 & go rest
//
/////////////////////////////////////////

int my_sway_task::init_go0(){
	go_target = GO_TARGET_0;
	return init_go();
}

int my_sway_task::init_go_rest(){
	go_target = GO_TARGET_REST;
	return init_go();
}

int my_sway_task::init_go(){
	
	//
	trial = 0;
	step = 0;
	step_global = 0;
	max_trial_time = 5;
	state_index = 0;
	ml.init((int)floor(max_trial_time/dt_learning) + 1, dt_learning, trial);
	
	scd();
	start_time = task_servo_time;
	
	return TRUE;
}

int my_sway_task::run_go(){
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	if(step_global%per_step == 0){
		// state machine
		if(time < 2){
			CMatrix gyro = gyro_sensor_wrapper();
			CMatrix ff = foot_force_sensor_wrapper(step, time);
			
			stop_watch();
			bool isfirst = false;
			if(state_index == 0){
				//cout << time << ": init_controller" << endl;
				isfirst = true;
				state_index++;
			}
			if(go_target == GO_TARGET_0){
				ml.go0_controller(trial, step, time);
			}
			else if(go_target == GO_TARGET_REST){
				ml.rest_controller(trial, step, time);
			}
		}
		else{
			cout << endl;
			cout << time << ": go0 finished" << endl;
			freeze();
			stopcd();
			return FALSE;
		}
		
		step++;
	}
	
	// get desired: joint_desired(t)
	CMatrix rest_des_th = ml.get_rest_des_th();
	CMatrix j_des_th   = ml.get_desired_th();
	CMatrix j_des_thd  = ml.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].thdd = 0;
		joint_des_state[i].thd  = j_des_thd(i);
		joint_des_state[i].th   = j_des_th(i);
	}
	
	//
	step_global++;
	
	return TRUE;
}

int my_sway_task::change_go()
{
	return TRUE;
}

/////////////////////////////////////////
//
// sway task
//
/////////////////////////////////////////
int my_sway_task::init(){
	// read index of last data as trial
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	
	//
	step = 0;
	step_global = 0;
	max_trial_time = 500;
	state_index = 0;
	isfinished = false;
	ml.init((int)floor(max_trial_time/dt_learning) + 1, dt_learning, trial);
	
	scd();
	start_time = task_servo_time;
	finish_time = 0;
	
	return TRUE;
}


int my_sway_task::run(){
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	if(step_global%per_step == 0){
		stop_watch();
		CMatrix gyro = gyro_sensor_wrapper();
		CMatrix ff = foot_force_sensor_wrapper(step, time);
		
		// state machine
		const double tmar = 5.0;
		if(time < tmar){
			ml.init_controller(trial, step, time, tmar, gyro, ff);
		}
		else if(isfinished == false){
			if(ml.sway_controller(trial, step, time - tmar, gyro, ff) == false){
				cout << "my_sway_task is done." << endl;
				ml.done(trial, step);
				isfinished = true;
				finish_time = time;
			}
			else{
				ml.trace(trial, step, time);
				
				printf("\033[2K");
				printf("t=%8.4f, %8.6f, roll=%8.4f, pitch=%8.4f, %8.4f, %8.4f", time, stop_watch()*1e-6, gyro(0)*180/PI, gyro(1)*180/PI,
					   ff(0), ff(1));
				printf("\033[%dD", 100);
				fflush(stdout);
				
				step++;
			}
		}
		else{
			if(ml.finish_controller(trial, step, time - finish_time, tmar, gyro, ff) == false){
				cout << "!!!!!!!!!!!" << endl;
				freeze();
				stopcd();
				return FALSE;
			}
		}
	}
	
	// get desired: joint_desired(t)
	CMatrix j_des_th  = ml.get_desired_th();
	CMatrix j_des_thd = ml.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].thd = j_des_thd(i);
		joint_des_state[i].th  = j_des_th(i);
	}
	
	step_global++;
	
	return TRUE;
}

int my_sway_task::change()
{
	return TRUE;
}

/////////////////////////////////////////
//
// save trace
//
/////////////////////////////////////////
int my_sway_task::init_save(){
	// read index of last data as trial
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	
	//
	step = 0;
	ml.save_trace(trial);
	saveData();
	
	return TRUE;
}


int my_sway_task::run_save(){
	freeze();
	return FALSE;
}

int my_sway_task::change_save()
{
	return TRUE;
}


/////////////////////////////////////////
//
// NN-revise task
//
/////////////////////////////////////////

//
// goto rest
//
int my_sway_task::init_NN_revise_go(){
	
	//
	trial = 0;
	step = 0;
	step_global = 0;
	max_trial_time = 5;
	state_index = 0;
	ml.init_NN_revise((int)floor(max_trial_time/dt_learning) + 1, dt_learning, trial);
	
	scd();
	start_time = task_servo_time;
	
	return TRUE;
}

int my_sway_task::run_NN_revise_go(){
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	if(step_global%per_step == 0){
		// state machine
		if(time < 2){
			CMatrix gyro = gyro_sensor_wrapper();
			CMatrix ff = foot_force_sensor_wrapper(step, time);
			
			stop_watch();
			bool isfirst = false;
			if(state_index == 0){
				//cout << time << ": init_controller" << endl;
				isfirst = true;
				state_index++;
			}
			ml.rest_controller_NN_revise(trial, step, time);
		}
		else{
			cout << endl;
			cout << time << ": go rest finished" << endl;
			freeze();
			stopcd();
			return FALSE;
		}
		
		step++;
	}
	
	// get desired: joint_desired(t)
	CMatrix rest_des_th = ml.get_rest_des_th();
	CMatrix j_des_th   = ml.get_desired_th();
	CMatrix j_des_thd  = ml.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].thdd = 0;
		joint_des_state[i].thd  = j_des_thd(i);
		joint_des_state[i].th   = j_des_th(i);
	}
	
	//
	step_global++;
	
	return TRUE;
}

int my_sway_task::change_NN_revise_go()
{
	return TRUE;
}

//
// sampling task
//
int my_sway_task::init_NN_revise_sampling(){
	// read index of last data as trial
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	
	//
	step = 0;
	step_global = 0;
	max_trial_time = 500;
	state_index = 0;
	isfinished = false;
	ml.init_NN_revise((int)floor(max_trial_time/dt_learning) + 1, dt_learning, trial);
	
	//add_var();
	
	scd();
	start_time = task_servo_time;
	finish_time = 0;
	
	return TRUE;
}

int my_sway_task::run_NN_revise_sampling(){
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	if(step_global%per_step == 0){
		stop_watch();
		CMatrix gyro = gyro_sensor_wrapper();
		CMatrix ff = foot_force_sensor_wrapper(step, time);
		ml.set_state(gyro);
		
		// state machine
		if(isfinished == false){
			if(ml.sampling_controller_NN_revise(trial, step, time, gyro, ff) == false){
				cout << "sampling_controller_NN_revise is done." << endl;
				//ml.done(trial, step);
				isfinished = true;
				finish_time = time;
			}
			else{
				ml.trace_NN_revise(trial, step, time);
				
				//printf("\033[2K");
				//printf("t=%8.4f, %8.6f, roll=%8.4f, pitch=%8.4f, %8.4f, %8.4f", time, stop_watch()*1e-6, gyro(0)*180/PI, gyro(1)*180/PI,
				//	   ff(0), ff(1));
				//printf("\033[%dD", 100);
				//fflush(stdout);
				
				step++;
			}
		}
		else{
			cout << "!!!!!!!!!!!" << endl;
			freeze();
			stopcd();
			return FALSE;
		}
	}
	
	// get desired: joint_desired(t)
	CMatrix j_des_th  = ml.get_desired_th();
	CMatrix j_des_thd = ml.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].thd = j_des_thd(i);
		joint_des_state[i].th  = j_des_th(i);
	}
	
	step_global++;
	
	return TRUE;
}

int my_sway_task::change_NN_revise_sampling()
{
	return TRUE;
}

//
// main task
//
int my_sway_task::init_NN_revise(){
	// read index of last data as trial
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	
	//
	step = 0;
	step_global = 0;
	max_trial_time = 500;
	state_index = 0;
	isfinished = false;
	ml.init_NN_revise((int)floor(max_trial_time/dt_learning) + 1, dt_learning, trial);
	
	scd();
	start_time = task_servo_time;
	finish_time = 0;
	
	return TRUE;
}


int my_sway_task::run_NN_revise(){
	const double time = (task_servo_time - start_time)*(double)task_servo_ratio;
	
	// User controller
	if(step_global%per_step == 0){
		stop_watch();
		CMatrix gyro = gyro_sensor_wrapper();
		CMatrix ff = foot_force_sensor_wrapper(step, time);
		ml.set_state(gyro);
		
		// state machine
		const double tmar = 5.0;
		if(time < tmar){
			ml.init_controller_NN_revise(trial, step, time, tmar, gyro, ff);
			if(step_global%(int)floor(1/(dt_learning)) == 0) cout << "countdown: " << tmar - round(time) << endl;
		}
		else if(isfinished == false){
			if(ml.periodic_controller_NN_revise(trial, step, time - tmar, gyro, ff) == false){
				cout << "periodic_controller_NN_revise is done." << endl;
				//ml.done(trial, step);
				isfinished = true;
				finish_time = time;
			}
			else{
				ml.trace_NN_revise(trial, step, time);
				
				printf("\033[2K");
				printf("t=%8.4f, %8.6f, roll=%8.4f, pitch=%8.4f, %8.4f, %8.4f", time, stop_watch()*1e-6, gyro(0)*180/PI, gyro(1)*180/PI,
					   ff(0), ff(1));
				printf("\033[%dD", 100);
				fflush(stdout);
				
				step++;
			}
		}
		else{
			if(ml.finish_controller_NN_revise(trial, step, time - finish_time, tmar, gyro, ff) == false){
				cout << "!!!!!!!!!!!" << endl;
				freeze();
				stopcd();
				return FALSE;
			}
		}
	}
	
	// get desired: joint_desired(t)
	CMatrix j_des_th  = ml.get_desired_th();
	CMatrix j_des_thd = ml.get_desired_thd();
	for(int i = 1; i <= N_DOFS; i++){
		joint_des_state[i].thd = j_des_thd(i);
		joint_des_state[i].th  = j_des_th(i);
	}
	
	step_global++;
	
	return TRUE;
}

int my_sway_task::change_NN_revise()
{
	return TRUE;
}


int my_sway_task::init_save_NN_revise(){
	// read index of last data as trial
	FILE *pf = fopen("./.last_data", "r");
	if(pf != NULL){
		if(fscanf(pf, "%d", &trial) == FALSE) trial = 0;
		fclose(pf);
	}
	else{
		trial = 0;
	}
	
	//
	step = 0;
	ml.save_trace_NN_revise(trial);
	saveData();
	
	return TRUE;
}


int my_sway_task::run_save_NN_revise(){
	freeze();
	return FALSE;
}

int my_sway_task::change_save_NN_revise()
{
	return TRUE;
}
