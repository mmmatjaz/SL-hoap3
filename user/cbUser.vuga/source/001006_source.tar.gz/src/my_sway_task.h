/*!=============================================================================
  ==============================================================================

  \file    my_sway_task.h

  \author  Norikazu Sugimoto
  \date    Dec. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef _MY_SWAY_TASK_H_
#define _MY_SWAY_TASK_H_

#ifndef PI
#define PI 3.14159
#endif

#include "mosaic_learning.h"
#include "my_utility.h"

enum GO_TARGET{
	GO_TARGET_0 = 0,
	GO_TARGET_REST
};

class my_sway_task{
	//
	// member variables
	//
  public:
	
  private:
	int trial, step, step_global, per_step;
	double max_trial_time, start_time, finish_time, dt_learning, dt_global, next_time;
	int state_index;
	int go_target;
	bool isfinished;
	
	double *xd, *xd_mos;
	
	class_mosaic_learning ml;
	
	//
	// member functions
	//
	
  private:
	CMatrix gyro_sensor_wrapper(void){
		CMatrix ret(6, 1);
		double tmp[6];
		gyro_sensor(tmp);
		for(int i = 0; i < 6; i++) ret(i) = tmp[i];
		return ret;
	}
	CMatrix foot_force_sensor_wrapper(int step, double time){
		CMatrix ret(4, 1);
		double tmp[4];
		foot_force_sensor(step, time, tmp);
		for(int i = 0; i < 4; i++) ret(i) = tmp[i];
		return ret;
	}
	
  public:
	my_sway_task();
	~my_sway_task();
	
	int init_go0();
	int init_go_rest();
	int init_go();
	int run_go();
	int change_go();
	
	int init();
	int run();
	int change();
	
	int init_save();
	int run_save();
	int change_save();
	
	// NN revise
	int init_NN_revise_go();
	int run_NN_revise_go();
	int change_NN_revise_go();
	
	int init_NN_revise_sampling();
	int run_NN_revise_sampling();
	int change_NN_revise_sampling();
	
	int init_NN_revise();
	int run_NN_revise();
	int change_NN_revise();
	
	int init_save_NN_revise();
	int run_save_NN_revise();
	int change_save_NN_revise();
};

#endif // end of _MY_SWAY_TASK_H_


