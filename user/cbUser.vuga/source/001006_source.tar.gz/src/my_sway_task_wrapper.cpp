/*============================================================================
==============================================================================

                              my_sway_task_wrapper.cpp
 
==============================================================================
Remarks:

  sekeleton that wrappes a "my test task" written in C++

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"

// local includes
#include "my_sway_task.h"

extern "C" {
	// global function
	void add_my_sway_task_go_cpp();
	void add_my_sway_task_cpp();
	void add_my_sway_task_save_cpp();
	void add_my_NN_revise_task_go_cpp();
	void add_my_NN_revise_task_sampling_cpp();
	void add_my_NN_revise_task_cpp();
	void add_my_NN_revise_task_save_cpp();
	
	// local functions
	static int init_my_sway_task_go0(void);
	static int init_my_sway_task_go_rest(void);
	static int run_my_sway_task_go(void);
	static int change_my_sway_task_go(void);
	
	static int init_my_sway_task(void);
	static int run_my_sway_task(void);
	static int change_my_sway_task(void);
	
	static int init_my_sway_task_save(void);
	static int run_my_sway_task_save(void);
	static int change_my_sway_task_save(void);
	
	// NN revise
	static int init_my_NN_revise_task_go(void);
	static int run_my_NN_revise_task_go(void);
	static int change_my_NN_revise_task_go(void);
	
	static int init_my_NN_revise_task_sampling(void);
	static int run_my_NN_revise_task_sampling(void);
	static int change_my_NN_revise_task_sampling(void);
	
	static int init_my_NN_revise_task(void);
	static int run_my_NN_revise_task(void);
	static int change_my_NN_revise_task(void);
	
	static int init_my_NN_revise_task_save(void);
	static int run_my_NN_revise_task_save(void);
	static int change_my_NN_revise_task_save(void);
}


//////////////////////////////////////////////////////////////////////////////
static my_sway_task my_sway_task;
void add_my_sway_task_go_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My sway task (go0)");
	addTask(task_name,
			init_my_sway_task_go0,
			run_my_sway_task_go,
			change_my_sway_task_go);
	
	strcpy(task_name, "My sway task (go reset)");
	addTask(task_name,
			init_my_sway_task_go_rest,
			run_my_sway_task_go,
			change_my_sway_task_go);
}

void add_my_sway_task_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My sway task");
	addTask(task_name,
			init_my_sway_task,
			run_my_sway_task,
			change_my_sway_task);
}

void add_my_sway_task_save_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My sway task (save)");
	addTask(task_name,
			init_my_sway_task_save,
			run_my_sway_task_save,
			change_my_sway_task_save);
}

//
void add_my_NN_revise_task_go_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My NN-revise task (go rest)");
	addTask(task_name,
			init_my_NN_revise_task_go,
			run_my_NN_revise_task_go,
			change_my_NN_revise_task_go);
}

void add_my_NN_revise_task_sampling_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My NN-revise task (sampling)");
	addTask(task_name,
			init_my_NN_revise_task_sampling,
			run_my_NN_revise_task_sampling,
			change_my_NN_revise_task_sampling);
}

void add_my_NN_revise_task_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My NN-revise task");
	addTask(task_name,
			init_my_NN_revise_task,
			run_my_NN_revise_task,
			change_my_NN_revise_task);
}

void add_my_NN_revise_task_save_cpp(void)
{
	char task_name[256];
	strcpy(task_name, "My NN-revise task (save)");
	addTask(task_name,
			init_my_NN_revise_task_save,
			run_my_NN_revise_task_save,
			change_my_NN_revise_task_save);
}

//
static int init_my_sway_task_go0(void)
{
	return my_sway_task.init_go0();
}
static int init_my_sway_task_go_rest(void)
{
	return my_sway_task.init_go_rest();
}
static int run_my_sway_task_go(void)
{
	return my_sway_task.run_go();
}
static int change_my_sway_task_go(void)
{
	return my_sway_task.change_go();
}


//
static int init_my_sway_task(void)
{
	return my_sway_task.init();
}
static int run_my_sway_task(void)
{
	return my_sway_task.run();
}
static int change_my_sway_task(void)
{
	return my_sway_task.change();
}


//
static int init_my_sway_task_save(void)
{
	return my_sway_task.init_save();
}
static int run_my_sway_task_save(void)
{
	return my_sway_task.run_save();
}
static int change_my_sway_task_save(void)
{
	return my_sway_task.change_save();
}


//
static int init_my_NN_revise_task_go(void)
{
	return my_sway_task.init_NN_revise_go();
}
static int run_my_NN_revise_task_go(void)
{
	return my_sway_task.run_NN_revise_go();
}
static int change_my_NN_revise_task_go(void)
{
	return my_sway_task.change_NN_revise_go();
}

static int init_my_NN_revise_task_sampling(void)
{
	return my_sway_task.init_NN_revise_sampling();
}
static int run_my_NN_revise_task_sampling(void)
{
	return my_sway_task.run_NN_revise_sampling();
}
static int change_my_NN_revise_task_sampling(void)
{
	return my_sway_task.change_NN_revise_sampling();
}

static int init_my_NN_revise_task(void)
{
	return my_sway_task.init_NN_revise();
}
static int run_my_NN_revise_task(void)
{
	return my_sway_task.run_NN_revise();
}
static int change_my_NN_revise_task(void)
{
	return my_sway_task.change_NN_revise();
}

static int init_my_NN_revise_task_save(void)
{
	return my_sway_task.init_save_NN_revise();
}
static int run_my_NN_revise_task_save(void)
{
	return my_sway_task.run_save_NN_revise();
}
static int change_my_NN_revise_task_save(void)
{
	return my_sway_task.change_save_NN_revise();
}



