#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>
#include <signal.h>
#include <errno.h>
#include <fcntl.h>

#include <iostream>
using namespace std;

// SL includes
#include "SL.h"
//#include "SL_common.h"
#include "SL_user.h"


//#include "SL_user_sensor_proc_xeno.h"
#include "my_utility.h"
#include "matrix.h"

void gyro_sensor(double *ret){
	SL_quat quat;
	double *gyro_pos = my_vector(1, 4);
	double *gyro_vel = my_vector(1, 4);
	
#ifdef UNIX
	vec_zero(gyro_pos);
	vec_zero(gyro_vel);
#else
	quat.q[_Q0_] = misc_sensor[B_Q0_IMU];
	quat.q[_Q1_] = misc_sensor[B_Q1_IMU];
	quat.q[_Q2_] = misc_sensor[B_Q2_IMU];
	quat.q[_Q3_] = misc_sensor[B_Q3_IMU];
	quatToEuler(&quat, gyro_pos);
	
	ret[3] =  misc_sensor[B_AD_B_IMU]; // roll
	ret[4] =  misc_sensor[B_AD_A_IMU]; // pitch
	ret[5] = -misc_sensor[B_AD_G_IMU]; // yaw
	
	ret[0] = -gyro_pos[2];
	ret[1] = -gyro_pos[1];
	ret[2] =  gyro_pos[3];
#endif // end of UNIX
	
	my_free_vector(gyro_pos, 1, 4);
	my_free_vector(gyro_vel, 1, 4);
}

void foot_force_sensor(int step, double time, double *ret)
{
	static double pre_time = 0, pre_0 = 0, pre_1 = 0;
	if(step == 0){
		pre_time = 0;
		pre_0 = 0;
		pre_1 = 0;
	}
	
#ifdef UNIX
	ret[0] = 0;
	ret[1] = 0;
#else
	ret[0] = -misc_sensor[L_CFx] - 36;
	ret[1] = -misc_sensor[R_CFx];
	
	double dt = (time - pre_time);
	if(dt < 1e-6 || step < 10){
		ret[2] = 0;
		ret[3] = 0;
	}
	else{
		ret[2] = (ret[0] - pre_0)/(time - pre_time);
		ret[3] = (ret[1] - pre_1)/(time - pre_time);
	}
#endif // end of UNIX
	
	// store
	pre_time = time;
	pre_0 = ret[0];
	pre_1 = ret[1];
}

int load_home_state(const char *fname, const int n_dofs, SL_DJstate *joint_state){
	// open file
	
	cout << "load_home_state(): loading " << fname << endl;
	FILE *fp = fopen(fname, "r");
	if(fp == NULL){
		cout << "load_home_state(): error in loading file." << endl;
		return FALSE;
	}
	
	// read parameters
	int isdisp = false;
	for(int i = 0; i < n_dofs + 1; i++){
		char joint_name[256];
		fscanf(fp, "%s %lf", joint_name, &joint_state[i].th);
		if(isdisp){
			printf("%10s = %8.4f[deg]\n", joint_name, joint_state[i].th);
		}
		joint_state[i].th *= 3.14159/(double)180;
	}
	fclose(fp);
	
	return true;
}


char read_one_key_nowait(void){
	char ret = ' ';
	struct termios term_attr, term_attr_org;
	
	tcgetattr(0, &term_attr);
	term_attr_org = term_attr; // �������������ߥʥ�°������¸
	term_attr.c_lflag &= ~(ICANON|ECHO); // ICANON��ECHO�ե�å��򥻥å�
	term_attr.c_cc[VMIN] = 1; // ����ʸ����κǾ��ɽХХ��ȿ��򣱤�
	term_attr.c_cc[VTIME] = 0; // �����Ԥ����֤�0��
	tcsetattr(0, TCSANOW, &term_attr); // �ѹ����������ߥʥ�°���򥻥å�
	fcntl(0, F_SETFL, O_NONBLOCK); // NONBLOCK�ե饰�Υ��å�
	read(0, &ret, 1);
	tcsetattr(0, TCSANOW, &term_attr_org);
	
	return ret;
}

double cost_function(CMatrix rap)
{
	//*
	CMatrix gp(3, 1);
	gp(0) =  2.248044e-02 + 0.2;
	gp(1) =  4.456188e-01 + 0.2;
	gp(2) = -2.561063e-01 + 0.2;
	double diff = pow(rap(0) - gp(0), 2) + pow(rap(1) - gp(1), 2) + pow(rap(2) - gp(2), 2);
	double cost_state = diff*1e6;
	//*/
	
	//double cost_state = cost_function(th(R_HR));
	
	/*
	cout << trans(rap);
	cout << trans(gp);
	cout << endl;
	getchar();
	*/
	
	return cost_state;
}

/*
double cost_function(double th_r_hr)
{
	double target = 30/(double)180*PI;
	double diff = th_r_hr - target;
	double cost_state = pow(diff, 2)*1e6;
	return cost_state;
}
*/

CMatrix right_arm_pos(CMatrix inp)
{
	double t0, t1, t2, t3, t4, t5, t6;
	if(inp.dim0() == N_DOFS + 1){
		t0 = inp(R_SFE);
		t1 = inp(R_SAA);
		t2 = inp(R_HR);
		t3 = inp(R_EB);
		t4 = inp(R_WR);
		t5 = inp(R_WFE);
		t6 = inp(R_WAA);
	}
	else if(inp.dim0() == 3*2){
		t0 = inp(0);
		t1 = inp(1);
		t2 = 0;
		t3 = inp(2);
		t4 = 0;
		t5 = 0;
		t6 = 0;
	}
	else{
		cout << "illegal input!" << endl;
		getchar();
		exit(1);
	}
	
	/*
	t0 = 0;
	t1 = -5/180.0*3.14;
	t2 = 0;
	t3 = 90/180.0*3.14;
	t4 = 5/180.0*3.14;
	t5 = 0;
	t6 = 0;
	*/
	
	double S0 = sin(t0), S1 = sin(t1), S2 = sin(t2), S3 = sin(t3), S4 = sin(t4), S5 = sin(t5), S6 = sin(t6);
	double C0 = cos(t0), C1 = cos(t1), C2 = cos(t2), C3 = cos(t3), C4 = cos(t4), C5 = cos(t5), C6 = cos(t6);
	
	double l3 = 10.146*2.54*0.01;
	double l5 =  9.481*2.54*0.01;
	double l7 =  8.130*2.54*0.01;
	
	CMatrix P(3, 1);
	
	P(0) = -S1*l3-(-C1*S2*S3+S1*C3)*l5-
		(-(C1*C2*S4+(C1*S2*C3+S1*S3)*C4)*S6+
		 (-(C1*C2*C4-(C1*S2*C3+S1*S3)*S4)*S5+(-C1*S2*S3+S1*C3)*C5)*C6)*l7;
	
	P(1) = S0*C1*l3-(-(S0*S1*S2+C1*C2)*S3-S0*C1*C3)*l5-
		(-((S0*S1*C2-C1*S2)*S4+((S0*S1*S2+C1*C2)*C3-S0*C1*S3)*C4)*S6+
		 (-((S0*S1*C2-C1*S2)*C4-((S0*S1*S2+C1*C2)*C3-S0*C1*S3)*S4)*S5+
		  (-(S0*S1*S2+C1*C2)*S3-S0*C1*C3)*C5)*C6)*l7;
	
	P(2) = -C1*C1*l3-(-(-C1*S1*S2+S0*C2)*S3+C1*C1*C3)*l5-
		(-((-C1*S1*C2-S0*S2)*S4+((-C1*S1*S2+S0*C2)*C3+C1*C1*S3)*C4)*S6+
		 (-((-C1*S1*C2-S0*S2)*C4-((-C1*S1*S2+S0*C2)*C3+C1*C1*S3)*S4)*S5+
		  (-(-C1*S1*S2+S0*C2)*S3+C1*C1*C3)*C5)*C6)*l7;
	return P;
}
