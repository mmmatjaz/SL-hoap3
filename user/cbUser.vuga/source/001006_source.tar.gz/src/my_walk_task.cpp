/*============================================================================
==============================================================================

                              my_walk_task.cpp
 
==============================================================================
Remarks:

============================================================================*/

#include <iostream>
using namespace std;

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"
#include "SL_task_servo.h"
#include "SL_kinematics.h"
#include "SL_dynamics.h"
#include "SL_collect_data.h"
#include "SL_shared_memory.h"
#include "SL_man.h"

// local includes
#include "my_walk_task.h"
#include "my_utility.h"

// constant variables
const double class_my_walk_task::STEP_SIZE = 0.002;

class_my_walk_task::class_my_walk_task(){
}

class_my_walk_task::~class_my_walk_task(){
}

//
// public functions
//
int class_my_walk_task::init_my_walk_task(){
	task_index = WALKING_TASK;
	load_home_state("init_posture_walk.dat", N_DOFS, joint_home_state);
	return init();
}

int class_my_walk_task::init_my_squat_task(){
	task_index = SQUATTING_TASK;
	load_home_state("init_posture_squat.dat", N_DOFS, joint_home_state);
	return init();
}

int class_my_walk_task::run_my_walk_task(){
	return run();
}

int class_my_walk_task::run_my_squat_task(){
	return run();
}

int class_my_walk_task::change_my_walk_task(){
	return change();
}

int class_my_walk_task::change_my_squat_task(){
	return change();
}


//
// private functions
//

int class_my_walk_task::init(){
	
	/*
	addVarToCollect((char *)&joint_des_state[B_TAA].th, "B_TAA_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[B_TFE].th, "B_TFE_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[B_TR ].th, "B_TR_th_des",  "rad", DOUBLE, 1);
	
	addVarToCollect((char *)&joint_des_state[R_HAA].th, "R_HAA_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[R_HFE].th, "R_HFE_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[R_KFE].th, "R_KFE_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[R_AAA].th, "R_AAA_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[R_AFE].th, "R_AFE_th_des", "rad", DOUBLE, 1);
	
	addVarToCollect((char *)&joint_des_state[L_HAA].th, "L_HAA_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[L_HFE].th, "L_HFE_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[L_KFE].th, "L_KFE_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[L_AAA].th, "L_AAA_th_des", "rad", DOUBLE, 1);
	addVarToCollect((char *)&joint_des_state[L_AFE].th, "L_AFE_th_des", "rad", DOUBLE, 1);
	
	updateDataCollectScript();
	*/
	
	//setTaskByName("My go0 task (walk)");
	//cout << "My go0 task is finished!" << endl;
	
	isask = false;
	
	start_time = task_servo_time;
	
	// reset parameters of controller
	init_parameter();
	
	// record data
	scd();
	
	return TRUE;
}

int class_my_walk_task::run(){
	double time = task_servo_time - start_time;
	double xt[N_DOFS+1], xd[N_DOFS+1];
	
	for(int i = 0; i < N_DOFS + 1; i++) xt[i] = joint_state[i].th;
	
	local_time = task_servo_time - start_time;
	translate_misc_sensor_to_local_variable();
	
	if(select_controller(xt, xd) == FALSE){
		setTaskByName(NO_TASK);
		saveData();
		cout << "My walk task is finished!" << endl;
	}
	
	for(int i = 0; i <= N_DOFS; i++) joint_des_state[i].th = xd[i];
	
	return TRUE;
}

int class_my_walk_task::change(){
	return TRUE;
}

// sub functions

int class_my_walk_task::select_controller(double *xt, double *xd)
{
	//double phase = 0.0;
	//static double phase_prev = 0.0;
	
	//phase = get_phase_1st();
	int ret_flag = state_machine();
	
	//initial_controller(xt, xd);
	//for(int i = 0; i <= N_DOFS; i++) joint_des_state[i].th = xd[i];
	//return TRUE;
	
	switch(state_machine_index){
	case INITIAL_CONTROLLER:
		//rest_controller(xt, xd);
		initial_controller(xt, xd);
		break;
		
	case FINISH_CONTROLLER:
		finish_controller(xt, xd);
		break;
		
	case REST_CONTROLLER:
		rest_controller(xt, xd);
		break;
		
	case STEPPING_CONTROLLER:
		stepping_controller(xt, xd);
		break;
		
	case WALKING_CONTROLLER:
		walking_controller(xt, xd);
		break;
		
	case LIFT_CONTROLLER:
		//lift_controller(xt, xd, controller_flag);
		break;
		
	case SQUATTING_CONTROLLER:
		//squatting_controller(xt, xd, controller_flag);
		break;
		
	default:
		break;
	}
	//phase_prev = phase;
	
	return ret_flag;
}

int class_my_walk_task::state_machine(void)
{
	int ret_flag = FALSE;
	
	switch(task_index){
	case WALKING_TASK:
		ret_flag = state_machine_walk();
		break;
	case SQUATTING_TASK:
		ret_flag = state_machine_squat();
		break;
	defalt:
		break;
	}
	
	return ret_flag;
}

int class_my_walk_task::state_machine_walk(void)
{
	const double rest_time = 5;
	const double step_phase (1.0*M_PI);
	const double walk_phase (0.5*M_PI);
	const int step_cycle = 1;
	const int walk_cycle = 4;
	
	static int isend = false;
	if(local_time > rest_time && state_machine_index == REST_CONTROLLER && get_cycle() < max_cycle){
		isend = false;
		state_machine_index = INITIAL_CONTROLLER;
		
		cout << "REST_CONTROLLER-->INITIAL_CONTROLLER" << endl;
	}
	else if(get_phase() > step_phase && get_cycle() >= step_cycle && state_machine_index == INITIAL_CONTROLLER){
		state_machine_index = STEPPING_CONTROLLER;
		printf("INITIAL_CONTROLLER-->STEP_CONTROLLER\n");
	}
	else if(get_phase() > walk_phase && get_cycle() >= walk_cycle && state_machine_index == STEPPING_CONTROLLER){
		start_walking_time = local_time;
		state_machine_index = WALKING_CONTROLLER;
		printf("STEP_CONTROLLER-->WALKING_CONTROLLER\n");
	}
	else if(get_cycle() > max_cycle && state_machine_index == WALKING_CONTROLLER){
		isend = true;
		state_machine_index = FINISH_CONTROLLER;
		printf("WALKING_CONTROLLER-->FINISH_CONTROLLER\n");
		cout << "Hit 'f' key!" << endl;
	}
	
	//*
	if(isend == true){
		if(read_one_key_nowait() == 'f'){
			isend = false;
			return false;
		}
		//pthread_t p_ask_isfinish;
		//pthread_create(&p_ask_isfinish, NULL, ask_isfinish, NULL);
		//pthread_detach(p_ask_isfinish);
	}
	
	return true;
}

int class_my_walk_task::state_machine_squat(void)
{
	const int max_cycle = 10; // tmp
	
	// start
	const double rest_time = 10;
	static double rest_countdown_time = rest_time;
	if(state_machine_index == REST_CONTROLLER){
		double tmp = rest_time - local_time;
		if(tmp < rest_countdown_time){
			cout << "count down: " << rest_countdown_time << endl;
			rest_countdown_time -= 1;
		}
	}
	
	// main
	static int isend = false;
	static double endof_squatting_time = 0;
	if(rest_time <= local_time && state_machine_index == REST_CONTROLLER){
		rest_countdown_time = rest_time;
		state_machine_index = SQUATTING_CONTROLLER;
		cout << "REST -> SQUATTING" << endl;
	}
	else if(get_cycle() > max_cycle && state_machine_index == SQUATTING_CONTROLLER){
		isend = true;
		endof_squatting_time = local_time;
		state_machine_index = FINISH_CONTROLLER;
		cout << "SQUATTING -> FINISH" << endl;
	}
	
	// finish
	
	return true;
}




