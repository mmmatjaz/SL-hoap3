/*!=============================================================================
  ==============================================================================

  \file    my_walk_task.h

  \author  Norikazu Sugimoto
  \date    Jan. 2010

  ==============================================================================
  \remarks
  
  ============================================================================*/

#ifndef MY_WALK_TASK_H_
#define MY_WALK_TASK_H_

#ifndef PI
#define PI 3.14159
#endif

// SL includes
#include "SL.h"

#include "mosaic.h"

class class_my_walk_task{
	//
	// member functions
	//
  public:
	class_my_walk_task();
	~class_my_walk_task();
	
	int init_my_walk_task();
	int init_my_squat_task();
	
	int run_my_walk_task();
	int run_my_squat_task();
	
	int change_my_walk_task();
	int change_my_squat_task();
	
  private:
	int init();
	int run();
	int change();
	
	int select_controller(double *xt, double *xd);
	int state_machine(void);
	int state_machine_walk(void);
	int state_machine_squat(void);
	
	int get_cycle(void){
		return ncycle;
	};
	double get_phase(void){
		return zmp_phi;
	};
	
	// controllers
	void initial_controller(double *xt, double *xd);
	void finish_controller(double *xt, double *xd);
	void rest_controller(double *xt, double *xd);
	void stepping_controller(double *xt, double *xd);
	void walking_controller(double *xt, double *xd);
	
	// misc functions
	void init_parameter(void);
	int foot_switch(void);
	void detect_physical_phase(void);
	void set_phase_coordination(void);
	void set_coupling(double K_s, double K_w, double K_sm, double K_wm);
	double min_jerk(double phase);
	int translate_misc_sensor_to_local_variable(void);
	int update_gains(void);
	int read_parameters_wrapper(void);
	int read_parameters(int *var, char *name);
	int read_parameters(double *var, char *name);
	
	//
	// member variables
	//
  public:
	
  private:
	int task_index;
	int state_machine_index;
	int stance_index;
	
	// flags
	int isask;
	
	// time information
	double start_time, start_walking_time, local_time;
	
	// state
	double finish_xd[N_DOFS + 1];
	SL_DJstate joint_home_state[N_DOFS + 1];
	
	// constant indexes
	enum{WALKING_TASK = 0, LIFTING_TASK, SQUATTING_TASK};
	enum{INITIAL_CONTROLLER = 0, FINISH_CONTROLLER, REST_CONTROLLER,
		 STEPPING_CONTROLLER, WALKING_CONTROLLER,
		 LIFT_CONTROLLER,
		 SQUATTING_CONTROLLER};
	enum{NCONTROL = N_DOFS + 1};
	enum{PHYS_PHASE = (2*NCONTROL)};
	enum{MONKEY_PHASE = (2*NCONTROL + 1)};
	enum{NOMINAL_PHASE = 1};
	enum{LEFT_STANCE = 0, RIGHT_STANCE};
	enum{ROL=0, PIT, YAW};
	
	// physical variables
	static const double STEP_SIZE;
	double cop_xdot_filt, cop_x_d, cop_x_filt;
	
	// phase information
	int ncycle, max_cycle;
	double zmp_phi;
	double phi[2*NCONTROL + 2], phi_dot[2*NCONTROL];
	double phi_diff[2*NCONTROL][2*NCONTROL + 2];
	double nominal_phase_diff, monkey_phase_diff;
	double natural_freq;
	double nominal_phase_prev;
	
	// CPG specific parameters
	int amp_scale_index;
	double amp_scale, amp_scale_time;
	double K_c, K_c_pit;
	double torso_bend, ankle_bend;
	double amp_l_add_hip, amp_r_add_hip;
	double amp_l_add_ankle, amp_r_add_ankle;
	double amp0[NCONTROL], amp[2*NCONTROL];
	double K_couple[2*NCONTROL][2*NCONTROL + 2];
	
	// foot switch flag
	int l_off_flag, r_off_flag;
	
	// sensor variables
	double gyro[3], gyro_vel[3];
	double foot_force_r_filt, foot_force_l_filt;
	double foot_force_r_filt_prev, foot_force_l_filt_prev;
	
	// gain settings
	double hip_gain_max, knee_gain_max, ankle_gain_max;
	double hip_gain_bias, knee_gain_bias, ankle_gain_bias;
	double gain_p[N_DOFS + 1], gain_i[N_DOFS + 1], gain_d[N_DOFS + 1];
	
	// high level balancer
	class_mosaic mosaic;
};
#endif

