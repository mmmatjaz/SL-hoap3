/*============================================================================
==============================================================================

                              my_walk_task_wrapper.cpp
 
==============================================================================
Remarks:

  sekeleton that wrappes a "my test task" written in C++

============================================================================*/

// SL system headers
#include "SL_system_headers.h"

// SL includes
#include "SL.h"
#include "SL_user.h"
#include "SL_tasks.h"

// local includes
#include "my_walk_task.h"

extern "C" {
	// global function
	void add_my_walk_task_cpp();
	
	// local functions
	static int init_my_walk_task(void);
	static int run_my_walk_task(void);
	static int change_my_walk_task(void);
	
	static int init_my_squat_task(void);
	static int run_my_squat_task(void);
	static int change_my_squat_task(void);
}


//////////////////////////////////////////////////////////////////////////////
static class_my_walk_task my_walk_task;
void add_my_walk_task_cpp(void)
{
	char task_name[200];
	strcpy(task_name, "My walk task");
	addTask(task_name,
			init_my_walk_task,
			run_my_walk_task,
			change_my_walk_task);
	
	strcpy(task_name, "My squat task");
	addTask(task_name,
			init_my_squat_task,
			run_my_squat_task,
			change_my_squat_task);
}

//
static int init_my_walk_task(void)
{
	return my_walk_task.init_my_walk_task();
}
static int run_my_walk_task(void)
{
	return my_walk_task.run_my_walk_task();
}
static int change_my_walk_task(void)
{
	return my_walk_task.change_my_walk_task();
}

//
static int init_my_squat_task(void)
{
	return my_walk_task.init_my_squat_task();
}
static int run_my_squat_task(void)
{
	return my_walk_task.run_my_squat_task();
}
static int change_my_squat_task(void)
{
	return my_walk_task.change_my_squat_task();
}

